<?php require ROOT . '/app/views/frontend/partials/header.php'; ?>

<div class="container py-5 text-center">
  <i class="ti ti-credit-card" style="font-size:56px;color:#2563EB"></i>
  <h2 class="mt-3">Menyiapkan Pembayaran...</h2>
  <p class="text-secondary">Invoice: <strong><?= htmlspecialchars($invoice) ?></strong></p>
  <p class="text-secondary small">Jika popup pembayaran tidak muncul otomatis, klik tombol di bawah.</p>
  <button id="pay-button" class="btn btn-primary rounded-pill px-4 mt-2">Bayar Sekarang</button>
</div>

<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?= htmlspecialchars($clientKey) ?>"></script>
<script>
  function payNow() {
    snap.pay('<?= htmlspecialchars($snapToken) ?>', {
      onSuccess: function(result) {
        window.location.href = '<?= BASE_URL ?>/checkout/pending?invoice=<?= urlencode($invoice) ?>';
      },
      onPending: function(result) {
        window.location.href = '<?= BASE_URL ?>/checkout/pending?invoice=<?= urlencode($invoice) ?>';
      },
      onError: function(result) {
        Swal.fire('Pembayaran Gagal', 'Silakan coba lagi.', 'error');
      },
      onClose: function() {
        // user menutup popup tanpa bayar — biarkan saja, order tetap 'pending'
      }
    });
  }
  document.getElementById('pay-button').addEventListener('click', payNow);
  window.addEventListener('load', payNow); // auto-trigger saat halaman load
</script>

<?php require ROOT . '/app/views/frontend/partials/footer.php'; ?>
