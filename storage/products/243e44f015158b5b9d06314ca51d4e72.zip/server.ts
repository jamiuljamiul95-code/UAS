import express from 'express';
import path from 'path';
import compression from 'compression';
import { createServer as createViteServer } from 'vite';

import authRoutes from './server/routes/authRoutes';
import productRoutes from './server/routes/productRoutes';
import categoryRoutes from './server/routes/categoryRoutes';
import orderRoutes from './server/routes/orderRoutes';
import userRoutes from './server/routes/userRoutes';
import profileRoutes from './server/routes/profileRoutes';
import cartRoutes from './server/routes/cartRoutes';
import checkoutRoutes from './server/routes/checkoutRoutes';
import paymentRoutes from './server/routes/paymentRoutes';
import wishlistRoutes from './server/routes/wishlistRoutes';
import notificationRoutes from './server/routes/notificationRoutes';
import { getShippingMethods, getVouchers } from './server/controllers/checkoutController';
import { authenticate } from './server/middlewares/auth.middleware';
import { errorHandler } from './server/middlewares/error.middleware';
import { requestLogger } from './server/middlewares/logger.middleware';
import { correlationIdMiddleware } from './server/middlewares/correlation.middleware';
import { corsMiddleware } from './server/config/cors';
import { securityMiddleware } from './server/config/security';
import { env } from './server/config/env';
import { logger } from './server/config/logger';

export async function createExpressApp() {
  const app = express();

  // Enable trust proxy (trust first hop) for correct IP identification behind proxies
  app.set('trust proxy', 1);

  // 1. Traceability: Correlation ID (Must run first so logs have correlation ID)
  app.use(correlationIdMiddleware);

  // 2. Logging: Request logger
  app.use(requestLogger);

  // 3. Security: CORS & Helmet
  app.use(corsMiddleware);
  app.use(securityMiddleware);

  // 4. Performance: Response Compression
  app.use(compression());

  // 5. Parsers: Configurable JSON & URL-encoded limits
  app.use(express.json({ limit: env.BODY_LIMIT }));
  app.use(express.urlencoded({ extended: true, limit: env.BODY_LIMIT }));

  // Health Check Endpoint (Registered before generic API fallbacks)
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'API is running' });
  });

  // API Routes
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
  app.use('/api/auth', authRoutes);
  app.use('/api/products', productRoutes);
  app.use('/api/categories', categoryRoutes);
  app.use('/api/orders', orderRoutes);
  app.use('/api/users', userRoutes);
  app.use('/api/profile', profileRoutes);
  app.use('/api/cart', cartRoutes);
  app.use('/api/checkout', checkoutRoutes);
  app.use('/api/payments', paymentRoutes);
  app.use('/api/wishlist', wishlistRoutes);
  app.use('/api/notifications', notificationRoutes);
  app.get('/api/shipping', authenticate, getShippingMethods);
  app.get('/api/vouchers', authenticate, getVouchers);

  // API 404 Handler (Any unmatched API request receives clean JSON response)
  app.all('/api/*', (req, res) => {
    res.status(404).json({ success: false, message: 'Route not found' });
  });

  // Global Error Handler for API
  app.use(errorHandler);

  // Vite middleware for development
  if (env.NODE_ENV === 'development') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else if (env.NODE_ENV === 'production') {
    // Serve static files in production
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  return app;
}

async function startServer() {
  const app = await createExpressApp();
  const PORT = env.PORT;

  app.listen(PORT, '0.0.0.0', () => {
    logger.info(`Server running on http://0.0.0.0:${PORT}`);
  });
}

if (env.NODE_ENV !== 'test') {
  startServer();
}

