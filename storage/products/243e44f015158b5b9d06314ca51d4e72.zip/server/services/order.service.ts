import { orderRepository } from '../repositories/order.repository';
import { AppError } from '../utils/error.util';
import { prisma } from '../config/db';
import { CreateOrderRequestDto } from '../dto/request/order.request.dto';
import { OrderResponseDto } from '../dto/response/order.response.dto';
import { notificationService } from './notification.service';

export class OrderService {
  public mapToResponseDto(order: any): OrderResponseDto {
    return {
      id: order.id,
      userId: order.userId,
      user: {
        id: order.user?.id || order.userId,
        name: order.user?.name || 'Unknown User',
        email: order.user?.email || '',
        phone: order.user?.phone || null
      },
      status: order.status,
      totalAmount: order.totalAmount,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      shippingAddress: order.shippingAddress,
      trackingResi: order.trackingResi,
      orderType: order.orderType,
      subtotal: order.subtotal,
      discountAmount: order.discountAmount,
      shippingFee: order.shippingFee,
      shippingCarrier: order.shippingCarrier,
      taxAmount: order.taxAmount,
      voucherId: order.voucherId,
      voucher: order.voucher ? {
        id: order.voucher.id,
        code: order.voucher.code,
        type: order.voucher.type,
        value: order.voucher.value,
      } : null,
      items: (order.items || []).map((item: any) => ({
        id: item.id,
        productId: item.productId,
        productName: item.product?.name || 'Unknown Product',
        product: item.product ? {
          id: item.product.id,
          name: item.product.name,
          slug: item.product.slug
        } : null,
        variantId: item.variantId,
        variantColor: item.variant?.color || null,
        variantSize: item.variant?.size || null,
        variant: item.variant ? {
          id: item.variant.id,
          size: item.variant.size,
          color: item.variant.color
        } : null,
        quantity: item.quantity,
        price: item.price
      })),
      timeline: (order.timeline || []).map((log: any) => ({
        id: log.id,
        status: log.status,
        note: log.note,
        createdAt: log.createdAt
      })),
      createdAt: order.createdAt,
      updatedAt: order.updatedAt
    };
  }

  async getOrders(
    userId: string,
    role: string,
    query: {
      page?: string | number;
      limit?: string | number;
      status?: string;
      search?: string;
      startDate?: string;
      endDate?: string;
      customerFilter?: string;
    }
  ) {
    const page = Math.max(1, parseInt(query.page?.toString() || '1', 10));
    const limit = Math.max(1, parseInt(query.limit?.toString() || '10', 10));
    const skip = (page - 1) * limit;

    const { orders, total } = await orderRepository.findOrders({
      userId,
      role,
      status: query.status,
      search: query.search,
      startDate: query.startDate,
      endDate: query.endDate,
      customerFilter: query.customerFilter,
      skip,
      take: limit,
    });

    const totalPages = Math.ceil(total / limit);

    return {
      orders: orders.map(order => this.mapToResponseDto(order)),
      pagination: {
        total,
        page,
        limit,
        totalPages,
      }
    };
  }

  async getOrderById(id: string, userId: string, role: string): Promise<OrderResponseDto> {
    const order = await orderRepository.findOrderById(id);
    if (!order) {
      throw new AppError('Order not found', 404);
    }

    // Role-based Access Control: Customers can only see their own orders.
    if (role === 'CUSTOMER' && order.userId !== userId) {
      throw new AppError('You do not have permission to view this order', 403);
    }

    return this.mapToResponseDto(order);
  }

  async createOrder(
    userId: string,
    role: string,
    data: CreateOrderRequestDto
  ): Promise<OrderResponseDto> {
    // 1. Determine status and paymentStatus based on role and orderType
    let status = 'PENDING';
    let paymentStatus = 'UNPAID';

    if (data.orderType === 'POS') {
      status = 'COMPLETED';
      paymentStatus = 'PAID';
    } else {
      status = 'PENDING';
      paymentStatus = 'UNPAID';
    }

    // 2. Retrieve Voucher details if voucherCode is passed
    let voucherId: string | null = null;
    let discountAmount = data.discountAmount || 0;
    
    if (data.voucherCode) {
      const voucher = await prisma.voucher.findUnique({
        where: { code: data.voucherCode.toUpperCase() }
      });
      if (voucher) {
        voucherId = voucher.id;
      }
    }

    // 3. Create order in database
    const order = await orderRepository.createOrder({
      userId,
      status,
      totalAmount: data.totalAmount,
      paymentMethod: data.paymentMethod,
      paymentStatus,
      orderType: data.orderType || 'ONLINE',
      subtotal: data.items.reduce((sum, item) => sum + (item.price * item.quantity), 0),
      discountAmount,
      shippingFee: data.shippingFee || 0,
      shippingCarrier: data.shippingCarrier || null,
      shippingAddress: data.shippingAddress || null,
      taxAmount: data.totalAmount * 0.1,
      voucherId,
      items: data.items,
    });

    // 4. If CUSTOMER, delete matching cart items
    if (role === 'CUSTOMER') {
      await prisma.cartItem.deleteMany({
        where: {
          cart: { userId },
          productId: { in: data.items.map(item => item.productId) }
        }
      });
    }

    return this.mapToResponseDto(order);
  }

  async updateOrderStatus(id: string, status: string, note?: string): Promise<OrderResponseDto> {
    const validStatuses = [
      'PENDING', 'WAITING_PAYMENT', 'PAID', 'PROCESSING',
      'PACKING', 'SHIPPED', 'DELIVERED', 'COMPLETED',
      'CANCELLED', 'REFUND'
    ];

    const targetStatus = status.toUpperCase();
    if (!validStatuses.includes(targetStatus)) {
      throw new AppError(`Invalid order status: ${status}`, 400);
    }

    const order = await orderRepository.updateOrderStatus(id, targetStatus, note);

    if (order?.userId) {
      const statusLabels: Record<string, string> = {
        PENDING: 'menunggu konfirmasi',
        WAITING_PAYMENT: 'menunggu pembayaran',
        PAID: 'pembayaran diterima',
        PROCESSING: 'sedang diproses',
        PACKING: 'sedang dikemas',
        SHIPPED: 'telah dikirim',
        DELIVERED: 'telah sampai tujuan',
        COMPLETED: 'selesai',
        CANCELLED: 'dibatalkan',
        REFUND: 'dalam proses refund',
      };
      const shortId = order.id.slice(0, 8);
      await notificationService.createForUser(
        order.userId,
        'Status Pesanan Diperbarui',
        `Pesanan #${shortId}... sekarang ${statusLabels[targetStatus] || targetStatus.toLowerCase()}.${note ? ` Catatan: ${note}` : ''}`,
        'ORDER_STATUS',
        order.id
      );
    }

    return this.mapToResponseDto(order);
  }

  async cancelOrder(id: string, userId?: string, note?: string): Promise<OrderResponseDto> {
    const order = await orderRepository.cancelOrder(id, userId, note);
    if (order?.userId) {
      const shortId = order.id.slice(0, 8);
      await notificationService.createForUser(
        order.userId,
        'Pesanan Dibatalkan',
        `Pesanan #${shortId}... telah dibatalkan.${note ? ` Alasan: ${note}` : ''}`,
        'ORDER_STATUS',
        order.id
      );
    }
    return this.mapToResponseDto(order);
  }
}

export const orderService = new OrderService();
