import { prisma } from '../config/db';

export class NotificationService {
  async getNotifications(userId: string) {
    const notifications = await prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    const unreadCount = await prisma.notification.count({
      where: { userId, isRead: false },
    });
    return { notifications, unreadCount };
  }

  async markAsRead(userId: string, id: string) {
    const notif = await prisma.notification.findUnique({ where: { id } });
    if (!notif || notif.userId !== userId) {
      return null;
    }
    return prisma.notification.update({
      where: { id },
      data: { isRead: true },
    });
  }

  async markAllAsRead(userId: string) {
    await prisma.notification.updateMany({
      where: { userId, isRead: false },
      data: { isRead: true },
    });
    return { success: true };
  }

  /**
   * Creates a notification for a single user. Used internally, e.g. when an
   * order's status changes.
   */
  async createForUser(userId: string, title: string, message: string, type: string = 'GENERAL', orderId?: string) {
    return prisma.notification.create({
      data: { userId, title, message, type, orderId },
    });
  }

  /**
   * Broadcasts a general announcement (e.g. promo / store info) to every
   * CUSTOMER account. Used by OWNER/ADMIN from the dashboard.
   */
  async broadcast(title: string, message: string) {
    const users = await prisma.user.findMany({
      where: { role: 'CUSTOMER' },
      select: { id: true },
    });

    if (users.length === 0) return { count: 0 };

    await prisma.notification.createMany({
      data: users.map((u) => ({
        userId: u.id,
        title,
        message,
        type: 'PROMO',
      })),
    });

    return { count: users.length };
  }
}

export const notificationService = new NotificationService();
