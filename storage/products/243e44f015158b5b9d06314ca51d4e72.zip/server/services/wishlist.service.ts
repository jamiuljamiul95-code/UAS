import { prisma } from '../config/db';
import { AppError } from '../utils/error.util';

export class WishlistService {
  async getWishlist(userId: string) {
    const items = await prisma.wishlist.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      include: {
        product: {
          include: {
            images: true,
            category: { select: { id: true, name: true, slug: true } },
          },
        },
      },
    });

    return items.map((item: { id: string; createdAt: Date; product: any }) => ({
      id: item.id,
      addedAt: item.createdAt,
      product: {
        id: item.product.id,
        name: item.product.name,
        slug: item.product.slug,
        price: item.product.price,
        discountPrice: item.product.discountPrice,
        stock: item.product.stock,
        status: item.product.status,
        category: item.product.category,
        images: item.product.images,
      },
    }));
  }

  async getWishlistProductIds(userId: string): Promise<string[]> {
    const items = await prisma.wishlist.findMany({
      where: { userId },
      select: { productId: true },
    });
    return items.map((i: { productId: string }) => i.productId);
  }

  async addToWishlist(userId: string, productId: string) {
    const product = await prisma.product.findUnique({ where: { id: productId } });
    if (!product) throw new AppError('Product not found', 404);

    const existing = await prisma.wishlist.findUnique({
      where: { userId_productId: { userId, productId } },
    });
    if (existing) return existing;

    return prisma.wishlist.create({ data: { userId, productId } });
  }

  async removeFromWishlist(userId: string, productId: string) {
    const existing = await prisma.wishlist.findUnique({
      where: { userId_productId: { userId, productId } },
    });
    if (!existing) throw new AppError('Product is not in wishlist', 404);

    return prisma.wishlist.delete({
      where: { userId_productId: { userId, productId } },
    });
  }
}

export const wishlistService = new WishlistService();
