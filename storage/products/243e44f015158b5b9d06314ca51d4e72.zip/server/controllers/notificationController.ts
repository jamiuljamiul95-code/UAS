import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { notificationService } from '../services/notification.service';
import { sendOK } from '../utils/response.util';
import { AppError } from '../utils/error.util';

export const getNotifications = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) throw new AppError('Unauthorized access: Missing user identifier', 401);
    const data = await notificationService.getNotifications(req.user.id);
    sendOK(res, 'Notifications retrieved successfully', data);
  } catch (error) {
    next(error);
  }
};

export const markNotificationAsRead = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) throw new AppError('Unauthorized access: Missing user identifier', 401);
    const { id } = req.params;
    const result = await notificationService.markAsRead(req.user.id, id);
    if (!result) throw new AppError('Notification not found', 404);
    sendOK(res, 'Notification marked as read', result);
  } catch (error) {
    next(error);
  }
};

export const markAllNotificationsAsRead = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) throw new AppError('Unauthorized access: Missing user identifier', 401);
    const result = await notificationService.markAllAsRead(req.user.id);
    sendOK(res, 'All notifications marked as read', result);
  } catch (error) {
    next(error);
  }
};

export const broadcastNotification = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { title, message } = req.body;
    if (!title || !message) throw new AppError('Title and message are required', 400);
    const result = await notificationService.broadcast(title, message);
    sendOK(res, `Notification broadcasted to ${result.count} customer(s)`, result);
  } catch (error) {
    next(error);
  }
};
