import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { wishlistService } from '../services/wishlist.service';
import { sendOK, sendCreated } from '../utils/response.util';
import { AppError } from '../utils/error.util';

export const getWishlist = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) throw new AppError('Unauthorized access: Missing user identifier', 401);
    const items = await wishlistService.getWishlist(req.user.id);
    sendOK(res, 'Wishlist retrieved successfully', items);
  } catch (error) {
    next(error);
  }
};

export const addToWishlist = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) throw new AppError('Unauthorized access: Missing user identifier', 401);
    const { productId } = req.body;
    if (!productId) throw new AppError('productId is required', 400);
    const result = await wishlistService.addToWishlist(req.user.id, productId);
    sendCreated(res, 'Product added to wishlist', result);
  } catch (error) {
    next(error);
  }
};

export const removeFromWishlist = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) throw new AppError('Unauthorized access: Missing user identifier', 401);
    const { productId } = req.params;
    await wishlistService.removeFromWishlist(req.user.id, productId);
    sendOK(res, 'Product removed from wishlist');
  } catch (error) {
    next(error);
  }
};
