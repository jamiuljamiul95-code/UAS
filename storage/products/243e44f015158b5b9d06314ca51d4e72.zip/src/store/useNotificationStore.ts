import { create } from 'zustand';
import api from '../lib/axios';
import { useAuthStore } from './useAuthStore';

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'ORDER_STATUS' | 'PROMO' | 'GENERAL';
  orderId: string | null;
  isRead: boolean;
  createdAt: string;
}

interface NotificationState {
  notifications: NotificationItem[];
  unreadCount: number;
  isLoading: boolean;

  fetchNotifications: () => Promise<void>;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,
  isLoading: false,

  fetchNotifications: async () => {
    const { isAuthenticated } = useAuthStore.getState();
    if (!isAuthenticated) {
      set({ notifications: [], unreadCount: 0 });
      return;
    }
    set({ isLoading: true });
    try {
      const response = await api.get('/notifications');
      const data = response.data?.data;
      set({
        notifications: data?.notifications || [],
        unreadCount: data?.unreadCount || 0,
        isLoading: false,
      });
    } catch (error) {
      console.error('Failed to fetch notifications', error);
      set({ isLoading: false });
    }
  },

  markAsRead: async (id: string) => {
    try {
      await api.patch(`/notifications/${id}/read`);
      set({
        notifications: get().notifications.map((n) => (n.id === id ? { ...n, isRead: true } : n)),
        unreadCount: Math.max(0, get().unreadCount - (get().notifications.find((n) => n.id === id)?.isRead ? 0 : 1)),
      });
    } catch (error) {
      console.error('Failed to mark notification as read', error);
    }
  },

  markAllAsRead: async () => {
    try {
      await api.patch('/notifications/read-all');
      set({
        notifications: get().notifications.map((n) => ({ ...n, isRead: true })),
        unreadCount: 0,
      });
    } catch (error) {
      console.error('Failed to mark all notifications as read', error);
    }
  },
}));
