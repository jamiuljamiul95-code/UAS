import { create } from 'zustand';
import api from '../lib/axios';
import { useAuthStore } from './useAuthStore';
import { useToastStore } from './useToastStore';

export interface WishlistItem {
  id: string;
  addedAt: string;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    discountPrice: number | null;
    stock: number;
    status: string;
    category?: { id: string; name: string; slug: string };
    images?: { id: string; url: string; isMain: boolean }[];
  };
}

interface WishlistState {
  items: WishlistItem[];
  productIds: Set<string>;
  isLoading: boolean;

  fetchWishlist: () => Promise<void>;
  isWishlisted: (productId: string) => boolean;
  toggleWishlist: (productId: string) => Promise<void>;
  removeFromWishlist: (productId: string) => Promise<void>;
}

export const useWishlistStore = create<WishlistState>((set, get) => ({
  items: [],
  productIds: new Set(),
  isLoading: false,

  fetchWishlist: async () => {
    const { isAuthenticated } = useAuthStore.getState();
    if (!isAuthenticated) {
      set({ items: [], productIds: new Set() });
      return;
    }
    set({ isLoading: true });
    try {
      const response = await api.get('/wishlist');
      const items: WishlistItem[] = response.data?.data || [];
      set({
        items,
        productIds: new Set(items.map((i) => i.product.id)),
        isLoading: false,
      });
    } catch (error) {
      console.error('Failed to fetch wishlist', error);
      set({ isLoading: false });
    }
  },

  isWishlisted: (productId: string) => get().productIds.has(productId),

  toggleWishlist: async (productId: string) => {
    const { isAuthenticated } = useAuthStore.getState();
    const toast = useToastStore.getState();

    if (!isAuthenticated) {
      toast.addToast('Silakan masuk untuk menyimpan produk ke wishlist', 'info');
      return;
    }

    const alreadyWishlisted = get().productIds.has(productId);

    try {
      if (alreadyWishlisted) {
        await api.delete(`/wishlist/${productId}`);
        const newIds = new Set(get().productIds);
        newIds.delete(productId);
        set({
          productIds: newIds,
          items: get().items.filter((i) => i.product.id !== productId),
        });
        toast.addToast('Dihapus dari wishlist', 'success');
      } else {
        await api.post('/wishlist', { productId });
        const newIds = new Set(get().productIds);
        newIds.add(productId);
        set({ productIds: newIds });
        toast.addToast('Ditambahkan ke wishlist', 'success');
        get().fetchWishlist();
      }
    } catch (error: any) {
      toast.addToast(error.response?.data?.message || 'Gagal memperbarui wishlist', 'error');
    }
  },

  removeFromWishlist: async (productId: string) => {
    const toast = useToastStore.getState();
    try {
      await api.delete(`/wishlist/${productId}`);
      const newIds = new Set(get().productIds);
      newIds.delete(productId);
      set({
        productIds: newIds,
        items: get().items.filter((i) => i.product.id !== productId),
      });
      toast.addToast('Dihapus dari wishlist', 'success');
    } catch (error: any) {
      toast.addToast(error.response?.data?.message || 'Gagal menghapus dari wishlist', 'error');
    }
  },
}));
