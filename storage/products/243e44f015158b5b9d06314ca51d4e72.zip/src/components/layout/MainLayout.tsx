import { useEffect, useRef, useState } from 'react';
import { Outlet, Link, NavLink, useNavigate } from 'react-router-dom';
import { ShoppingBag, LogIn, User, LogOut, ShoppingCart, Menu, X, ChevronDown, LayoutDashboard, Search, Heart, Bell, Loader2 } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { useCartStore } from '../../store/useCartStore';
import { useWishlistStore } from '../../store/useWishlistStore';
import { useNotificationStore } from '../../store/useNotificationStore';
import { Button } from '../ui/Button';
import api from '../../lib/axios';

interface SearchSuggestion {
  id: string;
  name: string;
  slug: string;
  price: number;
  discountPrice: number | null;
  images?: { url: string; isMain: boolean }[];
}

export default function MainLayout() {
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuthStore();
  const { items, fetchCart } = useCartStore();
  const { productIds: wishlistIds, fetchWishlist } = useWishlistStore();
  const { notifications, unreadCount, fetchNotifications, markAsRead, markAllAsRead } = useNotificationStore();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAccountMenuOpen, setIsAccountMenuOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchSuggestion[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const accountMenuRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  const cartItemCount = items.reduce((total, item) => total + item.quantity, 0);

  useEffect(() => {
    fetchCart();
  }, [fetchCart, isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchWishlist();
      fetchNotifications();
    }
  }, [isAuthenticated, fetchWishlist, fetchNotifications]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (accountMenuRef.current && !accountMenuRef.current.contains(event.target as Node)) {
        setIsAccountMenuOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotifOpen(false);
      }
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Debounced live product search
  useEffect(() => {
    const query = searchQuery.trim();
    if (query.length < 2) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }
    setIsSearching(true);
    const timeout = setTimeout(async () => {
      try {
        const response = await api.get('/products', {
          params: { search: query, status: 'ACTIVE', limit: 5 },
        });
        setSearchResults(response.data?.data || []);
      } catch (error) {
        console.error('Search failed', error);
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 350);
    return () => clearTimeout(timeout);
  }, [searchQuery]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim();
    if (!query) return;
    setIsSearchOpen(false);
    navigate(`/products?search=${encodeURIComponent(query)}`);
  };

  const getSuggestionImage = (p: SearchSuggestion) => {
    const main = p.images?.find((img) => img.isMain) || p.images?.[0];
    return main?.url || 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=100&q=80';
  };

  const formatRupiah = (number: number) =>
    new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(number);

  const initials = (user?.name || '?')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join('');

  const getNavLinkClass = ({ isActive }: { isActive: boolean }) =>
    `px-3 py-1.5 rounded-full text-sm font-semibold transition-colors duration-200 ${
      isActive ? 'text-blue-600 bg-blue-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
    }`;

  const timeAgo = (dateStr: string) => {
    const diffMs = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diffMs / 60000);
    if (mins < 1) return 'Baru saja';
    if (mins < 60) return `${mins} menit lalu`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours} jam lalu`;
    const days = Math.floor(hours / 24);
    return `${days} hari lalu`;
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <header className="sticky top-0 z-50 bg-white/85 backdrop-blur-md border-b border-slate-200/80 shadow-[0_1px_0_0_rgba(15,23,42,0.02)]">
        <div className="container mx-auto px-4 h-16 flex items-center gap-3 max-w-7xl">
          <Link to="/" className="flex items-center gap-2.5 font-bold text-lg tracking-tight shrink-0">
            <span className="flex items-center justify-center w-9 h-9 rounded-xl bg-blue-600 shadow-sm shadow-blue-600/30">
              <ShoppingBag className="w-4.5 h-4.5 text-white" />
            </span>
            <span className="hidden sm:inline">Luxe<span className="text-blue-600">Store</span></span>
          </Link>
          
          <nav className="hidden lg:flex gap-1 items-center shrink-0">
            <NavLink to="/" className={getNavLinkClass} end>Home</NavLink>
            <NavLink to="/products" className={getNavLinkClass}>Shop</NavLink>
            <NavLink to="/about" className={getNavLinkClass}>About</NavLink>
            <NavLink to="/contact" className={getNavLinkClass}>Contact</NavLink>
          </nav>

          {/* Search bar with live suggestions */}
          <div className="flex-1 max-w-md mx-auto relative hidden md:block" ref={searchRef}>
            <form onSubmit={handleSearchSubmit}>
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchOpen(true)}
                  placeholder="Cari produk..."
                  className="w-full h-10 pl-10 pr-4 rounded-full bg-slate-100 border border-transparent text-sm placeholder:text-slate-400 focus:bg-white focus:border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
            </form>

            {isSearchOpen && searchQuery.trim().length >= 2 && (
              <div className="absolute left-0 right-0 mt-2 bg-white rounded-2xl border border-slate-200 shadow-lg shadow-slate-900/5 overflow-hidden animate-in fade-in slide-in-from-top-1 duration-150">
                {isSearching ? (
                  <div className="p-4 flex items-center justify-center gap-2 text-slate-400 text-xs font-medium">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    Mencari...
                  </div>
                ) : searchResults.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400">
                    Tidak ada produk untuk "{searchQuery}"
                  </div>
                ) : (
                  <>
                    <div className="max-h-80 overflow-y-auto py-1.5">
                      {searchResults.map((p) => {
                        const hasDiscount = p.discountPrice != null && p.discountPrice < p.price;
                        return (
                          <Link
                            key={p.id}
                            to={`/products/${p.slug}`}
                            onClick={() => { setIsSearchOpen(false); setSearchQuery(''); }}
                            className="flex items-center gap-3 px-3.5 py-2 hover:bg-slate-50 transition-colors"
                          >
                            <img src={getSuggestionImage(p)} alt={p.name} className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0" />
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-semibold text-slate-800 truncate">{p.name}</p>
                              <div className="flex items-baseline gap-1.5">
                                <span className="text-xs font-bold text-slate-700">{formatRupiah(hasDiscount ? p.discountPrice! : p.price)}</span>
                                {hasDiscount && <span className="text-[10px] text-slate-400 line-through">{formatRupiah(p.price)}</span>}
                              </div>
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                    <button
                      onClick={handleSearchSubmit}
                      className="w-full text-center text-xs font-bold text-blue-600 py-2.5 border-t border-slate-100 hover:bg-slate-50 transition-colors cursor-pointer"
                    >
                      Lihat semua hasil untuk "{searchQuery}"
                    </button>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center gap-1 md:gap-1.5 ml-auto md:ml-0">
            {/* Wishlist */}
            <Link to="/wishlist" className="relative p-2.5 text-slate-500 hover:text-rose-500 hover:bg-slate-100 rounded-full transition-colors">
              <Heart className="w-5 h-5" />
              {isAuthenticated && wishlistIds.size > 0 && (
                <span className="absolute top-0.5 right-0.5 min-w-[18px] h-[18px] px-1 bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full ring-2 ring-white">
                  {wishlistIds.size}
                </span>
              )}
            </Link>

            {/* Notifications */}
            {isAuthenticated && (
              <div className="relative" ref={notifRef}>
                <button
                  onClick={() => setIsNotifOpen((v) => !v)}
                  className="relative p-2.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-0.5 right-0.5 min-w-[18px] h-[18px] px-1 bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center rounded-full ring-2 ring-white">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </button>

                {isNotifOpen && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl border border-slate-200 shadow-lg shadow-slate-900/5 overflow-hidden animate-in fade-in slide-in-from-top-1 duration-150">
                    <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
                      <p className="text-sm font-bold text-slate-800">Notifikasi</p>
                      {unreadCount > 0 && (
                        <button onClick={markAllAsRead} className="text-[11px] font-bold text-blue-600 hover:text-blue-700 cursor-pointer">
                          Tandai semua dibaca
                        </button>
                      )}
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="p-6 text-center text-xs text-slate-400">Belum ada notifikasi.</div>
                      ) : (
                        notifications.map((n) => (
                          <button
                            key={n.id}
                            onClick={() => markAsRead(n.id)}
                            className={`w-full text-left flex gap-3 px-4 py-3 border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors cursor-pointer ${!n.isRead ? 'bg-blue-50/50' : ''}`}
                          >
                            <span className={`mt-1 w-2 h-2 rounded-full shrink-0 ${!n.isRead ? 'bg-blue-600' : 'bg-transparent'}`} />
                            <div className="min-w-0 flex-1">
                              <p className={`text-xs leading-snug ${!n.isRead ? 'font-bold text-slate-800' : 'font-medium text-slate-600'}`}>{n.title}</p>
                              <p className="text-xs text-slate-500 leading-snug mt-0.5 line-clamp-2">{n.message}</p>
                              <p className="text-[10px] text-slate-400 mt-1 font-medium">{timeAgo(n.createdAt)}</p>
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            <Link to="/cart" className="relative p-2.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-full transition-colors">
              <ShoppingCart className="w-5 h-5" />
              {cartItemCount > 0 && (
                <span className="absolute top-0.5 right-0.5 min-w-[18px] h-[18px] px-1 bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center rounded-full ring-2 ring-white">
                  {cartItemCount}
                </span>
              )}
            </Link>

            <div className="hidden md:flex items-center">
              {isAuthenticated ? (
                <div className="relative ml-1" ref={accountMenuRef}>
                  <button
                    onClick={() => setIsAccountMenuOpen((v) => !v)}
                    className="flex items-center gap-2 pl-1.5 pr-2.5 py-1.5 rounded-full border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <span className="flex items-center justify-center w-7 h-7 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-xs font-bold shrink-0">
                      {initials}
                    </span>
                    <span className="text-sm font-semibold text-slate-700 max-w-[90px] truncate">{user?.name}</span>
                    <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isAccountMenuOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isAccountMenuOpen && (
                    <div className="absolute right-0 mt-2 w-60 bg-white rounded-2xl border border-slate-200 shadow-lg shadow-slate-900/5 py-2 animate-in fade-in slide-in-from-top-1 duration-150">
                      <div className="px-3.5 py-2.5 border-b border-slate-100">
                        <p className="text-sm font-bold text-slate-800 truncate">{user?.name}</p>
                        <p className="text-xs text-slate-400 truncate">{user?.email}</p>
                      </div>
                      <div className="py-1.5">
                        <Link
                          to={['OWNER', 'ADMIN', 'STAFF', 'CASHIER'].includes(user?.role || '') ? '/dashboard' : '/profile'}
                          onClick={() => setIsAccountMenuOpen(false)}
                          className="flex items-center gap-2.5 px-3.5 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors"
                        >
                          {['OWNER', 'ADMIN', 'STAFF', 'CASHIER'].includes(user?.role || '') ? (
                            <LayoutDashboard className="w-4 h-4 text-slate-400" />
                          ) : (
                            <User className="w-4 h-4 text-slate-400" />
                          )}
                          {['OWNER', 'ADMIN', 'STAFF', 'CASHIER'].includes(user?.role || '') ? 'Dashboard' : 'My Profile'}
                        </Link>
                        <Link
                          to="/wishlist"
                          onClick={() => setIsAccountMenuOpen(false)}
                          className="flex items-center gap-2.5 px-3.5 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors"
                        >
                          <Heart className="w-4 h-4 text-slate-400" />
                          Wishlist
                        </Link>
                      </div>
                      <div className="pt-1.5 border-t border-slate-100">
                        <button
                          onClick={() => {
                            logout();
                            setIsAccountMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm font-medium text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                        >
                          <LogOut className="w-4 h-4" />
                          Logout
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2 ml-1">
                  <Link to="/login">
                    <Button variant="ghost" size="sm" className="gap-2 rounded-full">
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/register">
                    <Button size="sm" className="rounded-full px-4 shadow-sm shadow-blue-600/20">Sign Up</Button>
                  </Link>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2.5 text-slate-500 hover:text-blue-600 hover:bg-slate-100 rounded-full transition-colors focus:outline-none"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile search bar (always visible below md breakpoint) */}
        <div className="md:hidden px-4 pb-3">
          <form onSubmit={handleSearchSubmit} className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari produk..."
              className="w-full h-10 pl-10 pr-4 rounded-full bg-slate-100 border border-transparent text-sm placeholder:text-slate-400 focus:bg-white focus:border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
            />
          </form>
          {searchQuery.trim().length >= 2 && searchResults.length > 0 && (
            <div className="mt-2 bg-white rounded-2xl border border-slate-200 shadow-lg overflow-hidden">
              {searchResults.map((p) => {
                const hasDiscount = p.discountPrice != null && p.discountPrice < p.price;
                return (
                  <Link
                    key={p.id}
                    to={`/products/${p.slug}`}
                    onClick={() => { setSearchQuery(''); setIsMobileMenuOpen(false); }}
                    className="flex items-center gap-3 px-3.5 py-2 hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0"
                  >
                    <img src={getSuggestionImage(p)} alt={p.name} className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-800 truncate">{p.name}</p>
                      <span className="text-xs font-bold text-slate-700">{formatRupiah(hasDiscount ? p.discountPrice! : p.price)}</span>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-4 animate-in fade-in duration-200">
            <nav className="flex flex-col gap-1">
              <NavLink 
                to="/" 
                end
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Home
              </NavLink>
              <NavLink 
                to="/products" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Shop
              </NavLink>
              <NavLink 
                to="/wishlist" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Wishlist
              </NavLink>
              <NavLink 
                to="/about" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                About
              </NavLink>
              <NavLink 
                to="/contact" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Contact
              </NavLink>
            </nav>
            
            <div className="pt-4 border-t border-slate-100 flex flex-col gap-2">
              {isAuthenticated ? (
                <div className="flex flex-col gap-3 px-3">
                  <div className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="flex items-center justify-center w-9 h-9 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-xs font-bold shrink-0">
                      {initials}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-slate-800 truncate">{user?.name}</p>
                      <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wide">{user?.role}</p>
                    </div>
                  </div>
                  <Link 
                    to={['OWNER', 'ADMIN', 'STAFF', 'CASHIER'].includes(user?.role || '') ? '/dashboard' : '/profile'}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="w-full"
                  >
                    <Button variant="outline" size="sm" className="w-full justify-center">
                      Dashboard / Profile
                    </Button>
                  </Link>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      logout();
                      setIsMobileMenuOpen(false);
                    }} 
                    className="w-full justify-center text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col gap-2 px-3">
                  <Link to="/login" onClick={() => setIsMobileMenuOpen(false)} className="w-full">
                    <Button variant="ghost" size="sm" className="w-full justify-center">
                      <LogIn className="w-4 h-4 mr-2" />
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/register" onClick={() => setIsMobileMenuOpen(false)} className="w-full">
                    <Button size="sm" className="w-full justify-center">
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      <main>
        <Outlet />
      </main>

      <footer className="bg-slate-900 text-slate-300 py-12 mt-20">
        <div className="container mx-auto px-4 max-w-7xl grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white font-bold text-xl mb-4 flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-blue-500" />
              LuxeStore
            </h3>
            <p className="text-sm">Premium clothing POS and E-Commerce platform for modern fashion businesses.</p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Shop</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/products" className="hover:text-white transition-colors">All Products</Link></li>
              <li><Link to="/wishlist" className="hover:text-white transition-colors">Wishlist</Link></li>
              <li><Link to="/sales" className="hover:text-white transition-colors">Sales & Offers</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link to="/faq" className="hover:text-white transition-colors">FAQ</Link></li>
              <li><Link to="/shipping" className="hover:text-white transition-colors">Shipping & Returns</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}
