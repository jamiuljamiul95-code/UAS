import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingCart, Trash2, LogIn } from 'lucide-react';
import { useWishlistStore } from '../../store/useWishlistStore';
import { useCartStore } from '../../store/useCartStore';
import { useAuthStore } from '../../store/useAuthStore';

export default function WishlistPage() {
  const { items, isLoading, fetchWishlist, removeFromWishlist } = useWishlistStore();
  const { addItem } = useCartStore();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated) fetchWishlist();
  }, [fetchWishlist, isAuthenticated]);

  const formatRupiah = (number: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(number);
  };

  const getImageUrl = (product: any) => {
    const main = product.images?.find((img: any) => img.isMain) || product.images?.[0];
    return main?.url || 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=400&q=80';
  };

  return (
    <div className="container mx-auto px-4 py-10 max-w-7xl min-h-[60vh]">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2.5">
          <Heart className="w-7 h-7 text-rose-500 fill-rose-500" />
          Wishlist Saya
        </h1>
        <p className="text-slate-500 mt-1">Produk yang kamu simpan untuk dibeli nanti.</p>
      </div>

      {!isAuthenticated ? (
        <div className="text-center py-20 border border-dashed border-slate-200 rounded-2xl bg-white">
          <LogIn className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <p className="font-semibold text-slate-700">Masuk untuk melihat wishlist kamu</p>
          <p className="text-sm text-slate-400 mt-1 mb-5">Wishlist tersimpan di akunmu, bisa diakses dari device manapun.</p>
          <Link to="/login" className="inline-block px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-full hover:bg-blue-700 transition-colors">
            Masuk Sekarang
          </Link>
        </div>
      ) : isLoading ? (
        <div className="text-center py-20 text-slate-400 text-sm">Memuat wishlist...</div>
      ) : items.length === 0 ? (
        <div className="text-center py-20 border border-dashed border-slate-200 rounded-2xl bg-white">
          <Heart className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <p className="font-semibold text-slate-700">Wishlist kamu masih kosong</p>
          <p className="text-sm text-slate-400 mt-1 mb-5">Simpan produk favoritmu dengan menekan ikon hati.</p>
          <Link to="/products" className="inline-block px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-full hover:bg-blue-700 transition-colors">
            Jelajahi Produk
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
          {items.map((item) => {
            const p = item.product;
            const hasDiscount = p.discountPrice != null && p.discountPrice < p.price;
            return (
              <div key={item.id} className="group bg-white border border-slate-150 rounded-2xl overflow-hidden hover:shadow-md transition-shadow">
                <Link to={`/products/${p.slug}`} className="block relative aspect-square bg-slate-100 overflow-hidden">
                  <img
                    src={getImageUrl(p)}
                    alt={p.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {p.stock <= 0 && (
                    <span className="absolute top-2 left-2 bg-slate-900/80 text-white text-[10px] font-bold px-2 py-1 rounded-full">
                      Stok Habis
                    </span>
                  )}
                </Link>
                <div className="p-3.5 space-y-1.5">
                  {p.category && (
                    <p className="text-[10px] font-semibold text-blue-600 uppercase tracking-wide">{p.category.name}</p>
                  )}
                  <Link to={`/products/${p.slug}`} className="block font-bold text-slate-800 text-sm leading-snug line-clamp-2 hover:text-blue-600 transition-colors">
                    {p.name}
                  </Link>
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-bold text-slate-900 text-sm">{formatRupiah(hasDiscount ? p.discountPrice! : p.price)}</span>
                    {hasDiscount && (
                      <span className="text-xs text-slate-400 line-through">{formatRupiah(p.price)}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    <button
                      onClick={() => addItem(p.id, 1, null, p)}
                      disabled={p.stock <= 0}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-blue-600 text-white text-xs font-bold py-2 rounded-full hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      Keranjang
                    </button>
                    <button
                      onClick={() => removeFromWishlist(p.id)}
                      className="p-2 rounded-full border border-slate-200 text-slate-400 hover:text-rose-600 hover:border-rose-200 hover:bg-rose-50 transition-colors cursor-pointer"
                      title="Hapus dari wishlist"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
