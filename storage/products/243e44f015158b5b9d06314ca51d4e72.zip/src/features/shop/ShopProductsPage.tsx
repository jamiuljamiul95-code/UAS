import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ShoppingBag, ArrowUpDown, Search, Heart } from 'lucide-react';
import api from '../../lib/axios';
import { Button } from '../../components/ui/Button';
import { useWishlistStore } from '../../store/useWishlistStore';
import { useAuthStore } from '../../store/useAuthStore';

interface Category {
  id: string;
  name: string;
  slug: string;
}

interface Product {
  id: string;
  name: string;
  slug: string;
  price: number;
  category: { name: string };
  images: { url: string }[];
}

export default function ShopProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryIdParam = searchParams.get('categoryId') || 'all';
  const sortByParam = searchParams.get('sortBy') || 'newest';
  const searchParam = searchParams.get('search') || '';

  const [searchInput, setSearchInput] = useState(searchParam);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const { isAuthenticated } = useAuthStore();
  const { isWishlisted, toggleWishlist, fetchWishlist } = useWishlistStore();

  useEffect(() => {
    fetchCategories();
    if (isAuthenticated) fetchWishlist();
  }, []);

  useEffect(() => {
    setSearchInput(searchParam);
  }, [searchParam]);

  useEffect(() => {
    fetchProducts();
  }, [categoryIdParam, sortByParam, searchParam]);

  const fetchCategories = async () => {
    try {
      const response = await api.get('/categories');
      if (response.data.success) {
        setCategories(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch categories', error);
    }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      let url = '/products?limit=100&status=ACTIVE';
      if (categoryIdParam && categoryIdParam !== 'all') {
        url += `&categoryId=${categoryIdParam}`;
      }
      if (searchParam) {
        url += `&search=${encodeURIComponent(searchParam)}`;
      }
      
      if (sortByParam === 'price_asc') {
        url += `&sortBy=price&sortOrder=asc`;
      } else if (sortByParam === 'price_desc') {
        url += `&sortBy=price&sortOrder=desc`;
      } else if (sortByParam === 'newest') {
        url += `&sortBy=newest`;
      }

      const response = await api.get(url);
      if (response.data.success) {
        setProducts(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCategorySelect = (id: string) => {
    const newParams = new URLSearchParams(searchParams);
    if (id === 'all') {
      newParams.delete('categoryId');
    } else {
      newParams.set('categoryId', id);
    }
    setSearchParams(newParams);
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newParams = new URLSearchParams(searchParams);
    newParams.set('sortBy', e.target.value);
    setSearchParams(newParams);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newParams = new URLSearchParams(searchParams);
    if (searchInput.trim()) {
      newParams.set('search', searchInput.trim());
    } else {
      newParams.delete('search');
    }
    setSearchParams(newParams);
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            {searchParam ? `Hasil untuk "${searchParam}"` : 'All Products'}
          </h1>
          <p className="mt-2 text-slate-500">Discover our latest collection of premium clothing.</p>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <form onSubmit={handleSearchSubmit} className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Cari produk..."
              className="w-full h-10 pl-9 pr-3 rounded-md border border-slate-200 text-sm focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-shadow"
            />
          </form>

          {/* Sort filter */}
          <div className="flex items-center gap-2 shrink-0">
            <label htmlFor="sortBy" className="text-sm font-medium text-slate-700 hidden lg:flex items-center gap-1">
              <ArrowUpDown className="w-4 h-4 text-slate-400" />
              Sort by:
            </label>
            <select 
              id="sortBy"
              value={sortByParam}
              onChange={handleSortChange}
              className="border border-slate-200 rounded-md px-3 py-2 text-sm bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-shadow"
            >
              <option value="newest">Newest Arrivals</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Category Filtering Horizontal Navigation */}
      <div className="mb-10 flex gap-2 overflow-x-auto pb-3 scrollbar-none">
        <button
          onClick={() => handleCategorySelect('all')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
            categoryIdParam === 'all'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300'
          }`}
        >
          All Categories
        </button>
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => handleCategorySelect(category.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
              categoryIdParam === category.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="group relative">
              <div className="aspect-h-4 aspect-w-3 bg-slate-100 rounded-lg overflow-hidden h-80 animate-pulse">
                <div className="w-full h-full bg-slate-200"></div>
              </div>
            </div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-24 text-slate-500">
          <ShoppingBag className="w-12 h-12 mx-auto text-slate-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-900">No products found</h3>
          <p>We are currently restocking our inventory for this category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <Link key={product.id} to={`/products/${product.slug}`} className="group relative block">
              <div className="aspect-h-4 aspect-w-3 bg-slate-100 rounded-lg overflow-hidden h-80 mb-4 relative">
                {product.images?.[0] ? (
                  <img 
                    src={product.images[0].url} 
                    alt={product.name} 
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-300">
                    <ShoppingBag className="w-12 h-12" />
                  </div>
                )}
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    toggleWishlist(product.id);
                  }}
                  className="absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 backdrop-blur flex items-center justify-center shadow-sm hover:bg-white transition-colors cursor-pointer z-10"
                  title="Simpan ke wishlist"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted(product.id) ? 'text-rose-500 fill-rose-500' : 'text-slate-500'}`} />
                </button>
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Button variant="outline" className="bg-white/90 text-slate-900 hover:bg-white border-none">
                    View Details
                  </Button>
                </div>
              </div>
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-sm font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                    {product.name}
                  </h3>
                  <p className="mt-1 text-sm text-slate-500">{product.category?.name}</p>
                </div>
                <p className="text-sm font-medium text-slate-900">${product.price.toFixed(2)}</p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
