import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingBag, ChevronRight, Heart } from 'lucide-react';
import api from '../../lib/axios';
import { Button } from '../../components/ui/Button';
import { useCartStore } from '../../store/useCartStore';
import { useWishlistStore } from '../../store/useWishlistStore';
import { useAuthStore } from '../../store/useAuthStore';

interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  category: { name: string };
  images: { url: string }[];
  variants: { id: string; size: string; color: string; stock: number }[];
}

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const { addItem } = useCartStore();
  const { isWishlisted, toggleWishlist, fetchWishlist } = useWishlistStore();
  const { isAuthenticated } = useAuthStore();

  useEffect(() => {
    if (isAuthenticated) fetchWishlist();
  }, [isAuthenticated, fetchWishlist]);

  useEffect(() => {
    fetchProduct();
  }, [slug]);

  const fetchProduct = async () => {
    try {
      const response = await api.get(`/products/${slug}`);
      if (response.data.success) {
        setProduct(response.data.data);
        // Pre-select first available size/color if variants exist
        const variants = response.data.data.variants;
        if (variants && variants.length > 0) {
          if (variants[0].size) setSelectedSize(variants[0].size);
          if (variants[0].color) setSelectedColor(variants[0].color);
        }
      }
    } catch (error) {
      console.error('Failed to fetch product details', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!product) return;
    
    // Find the correct variant based on selected size & color
    const matchedVariant = product.variants.find(
      (v) =>
        (!selectedSize || v.size === selectedSize) &&
        (!selectedColor || v.color === selectedColor)
    );
    
    try {
      await addItem(product.id, 1, matchedVariant?.id || null, product);
    } catch (err) {
      console.error('Failed to add item to bag:', err);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-7xl animate-pulse">
        <div className="h-8 bg-slate-200 w-48 rounded mb-8"></div>
        <div className="flex flex-col md:flex-row gap-12">
          <div className="w-full md:w-1/2 h-[500px] bg-slate-200 rounded-xl"></div>
          <div className="w-full md:w-1/2 space-y-6">
            <div className="h-10 bg-slate-200 w-3/4 rounded"></div>
            <div className="h-6 bg-slate-200 w-1/4 rounded"></div>
            <div className="h-32 bg-slate-200 w-full rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <Link to="/products">
          <Button variant="outline">Back to Products</Button>
        </Link>
      </div>
    );
  }

  // Extract unique sizes and colors
  const sizes = Array.from(new Set(product.variants?.map(v => v.size).filter(Boolean) || []));
  const colors = Array.from(new Set(product.variants?.map(v => v.color).filter(Boolean) || []));

  // Find current active variant & stock
  const matchedVariant = product.variants?.find(
    (v) =>
      (!selectedSize || v.size === selectedSize) &&
      (!selectedColor || v.color === selectedColor)
  );

  const currentStock = matchedVariant ? matchedVariant.stock : (product as any).stock || 0;

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      {/* Breadcrumbs */}
      <nav className="flex items-center text-sm text-slate-500 mb-8">
        <Link to="/" className="hover:text-blue-600">Home</Link>
        <ChevronRight className="w-4 h-4 mx-2" />
        <Link to="/products" className="hover:text-blue-600">Products</Link>
        <ChevronRight className="w-4 h-4 mx-2" />
        <span className="text-slate-900">{product.name}</span>
      </nav>

      <div className="flex flex-col md:flex-row gap-12">
        {/* Images */}
        <div className="w-full md:w-1/2 flex flex-col gap-4">
          <div className="aspect-h-1 aspect-w-1 bg-slate-100 rounded-2xl overflow-hidden shadow-sm border border-slate-200">
            {product.images?.[0] ? (
              <img src={product.images[0].url} alt={product.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-[500px] flex items-center justify-center text-slate-300">
                <ShoppingBag className="w-24 h-24" />
              </div>
            )}
          </div>
          {/* Thumbnails placeholder */}
          <div className="grid grid-cols-4 gap-4">
            {product.images?.slice(1, 5).map((img, i) => (
              <div key={i} className="aspect-square bg-slate-100 rounded-lg overflow-hidden border border-slate-200 cursor-pointer hover:border-blue-500 transition-colors">
                <img src={img.url} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="w-full md:w-1/2 flex flex-col">
          <div className="mb-6 border-b border-slate-200 pb-6">
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-slate-900 mb-2">{product.name}</h1>
            <p className="text-xl font-medium text-slate-900">${product.price.toFixed(2)}</p>
            <p className={`text-sm mt-2 font-medium ${currentStock > 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {currentStock > 0 ? `In Stock (${currentStock} items left)` : 'Out of Stock'}
            </p>
          </div>

          <div className="prose prose-slate mb-8 text-slate-600">
            <p>{product.description}</p>
          </div>

          <div className="space-y-6 mb-8 flex-1">
            {colors.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-slate-900 mb-3">Color</h3>
                <div className="flex gap-2">
                  {colors.map(color => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 border rounded-md text-sm font-medium transition-colors ${
                        selectedColor === color 
                          ? 'border-blue-600 bg-blue-50 text-blue-700' 
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {sizes.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-slate-900 mb-3">Size</h3>
                <div className="flex flex-wrap gap-2">
                  {sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`w-12 h-12 flex items-center justify-center border rounded-md text-sm font-medium transition-colors ${
                        selectedSize === size 
                          ? 'border-slate-900 bg-slate-900 text-white' 
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="pt-6 border-t border-slate-200 flex gap-4">
            <Button 
              size="lg" 
              className="flex-1 text-lg py-6" 
              disabled={currentStock <= 0}
              onClick={handleAddToCart}
            >
              {currentStock > 0 ? 'Add to Bag' : 'Out of Stock'}
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="px-6 gap-2"
              onClick={() => product && toggleWishlist(product.id)}
            >
              <Heart className={`w-4.5 h-4.5 ${product && isWishlisted(product.id) ? 'text-rose-500 fill-rose-500' : ''}`} />
              {product && isWishlisted(product.id) ? 'Tersimpan' : 'Wishlist'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
