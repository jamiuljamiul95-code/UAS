import helmet from 'helmet';
import { env } from './env';

export const securityMiddleware = helmet({
  contentSecurityPolicy: env.NODE_ENV === 'production' ? {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"], // Support Vite bundles and client-side execution
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"], // Support Google Fonts and CSS-in-JS/Tailwind
      fontSrc: ["'self'", "data:", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:", "https:", "referrer"],
      connectSrc: ["'self'", "https:", "wss:"], // Allow API connections and web socket integrations
      objectSrc: ["'none'"],
      upgradeInsecureRequests: [],
    },
  } : false, // CSP is disabled in development to prevent interfering with Vite HMR/styles loading
  crossOriginEmbedderPolicy: false, // Ensures third-party media and content can load
  crossOriginOpenerPolicy: { policy: 'same-origin' },
  crossOriginResourcePolicy: { policy: 'cross-origin' }, // Allows client apps to fetch API resources
  dnsPrefetchControl: { allow: false },
  frameguard: { action: 'deny' }, // Prevents clickjacking attacks
  hidePoweredBy: true, // Removes the X-Powered-By header
  hsts: {
    maxAge: 31536000, // 1 year HSTS policy
    includeSubDomains: true,
    preload: true,
  },
  ieNoOpen: true,
  noSniff: true, // Prevents MIME-sniffing
  originAgentCluster: true,
  permittedCrossDomainPolicies: { permittedPolicies: 'none' },
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  xssFilter: true, // Enables legacy XSS protections
});
