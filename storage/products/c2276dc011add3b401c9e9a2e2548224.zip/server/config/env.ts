import dotenv from 'dotenv';
import { z } from 'zod';

// Load environment variables from .env file
dotenv.config();

const envSchema = z.object({
  DATABASE_URL: z.string().min(1, 'DATABASE_URL environment variable is required'),
  JWT_SECRET: z.string().min(8, 'JWT_SECRET must be at least 8 characters long'),
  JWT_EXPIRES_IN: z.string().default('1d'),
  PORT: z.preprocess(
    (val) => (val ? Number(val) : 3000),
    z.number().int().positive().default(3000)
  ),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  ENABLE_REQUEST_LOGGING: z.preprocess(
    (val) => val === undefined ? true : val === 'true',
    z.boolean()
  ).default(true),
  CORS_ALLOWED_ORIGINS: z.string().default('http://localhost:3000,http://127.0.0.1:3000'),
  BODY_LIMIT: z.string().default('1mb'),
});

const parseEnv = () => {
  const parsed = envSchema.safeParse(process.env);
  if (!parsed.success) {
    console.error('❌ Invalid environment variables configuration:');
    parsed.error.issues.forEach((issue) => {
      console.error(`  - ${issue.path.join('.')}: ${issue.message}`);
    });
    throw new Error('Environment variable validation failed. Please check your .env file.');
  }
  return parsed.data;
};

export const env = parseEnv();
