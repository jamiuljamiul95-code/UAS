import cors, { CorsOptions } from 'cors';
import { env } from './env';

const whitelist = env.CORS_ALLOWED_ORIGINS.split(',').map((o) => o.trim());

// Ensure local development hosts are included in whitelist checks
const baseWhitelist = [...whitelist];
if (!baseWhitelist.some((item) => item.includes('localhost'))) {
  baseWhitelist.push('localhost');
}
if (env.NODE_ENV !== 'production' && !baseWhitelist.some((item) => item.includes('run.app'))) {
  baseWhitelist.push('run.app');
}

export const corsOptions: CorsOptions = {
  origin: (origin, callback) => {
    // Allow requests with no origin (e.g. server-to-server, curl, tools, or mobile apps)
    if (!origin) {
      return callback(null, true);
    }

    const isAllowed = baseWhitelist.some((allowed) => {
      // Smart localhost matching (handles any port or sub-protocol)
      if (allowed === 'localhost') {
        const isLocalhost = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(origin);
        if (isLocalhost) return true;
      }

      // Smart run.app matching (handles GCP Cloud Run/AI Studio development previews with nested region subdomains)
      if (allowed === 'run.app') {
        const isRunApp = /^https?:\/\/([a-zA-Z0-9-.]+\.)?run\.app$/i.test(origin);
        if (isRunApp) return true;
      }

      // Smart vercel.app matching (handles nested branch/deployment subdomains and main domain)
      if (allowed === 'vercel.app') {
        const isVercel = /^https?:\/\/([a-zA-Z0-9-.]+\.)?vercel\.app$/i.test(origin);
        if (isVercel) return true;
      }

      // Custom wildcard pattern matching (e.g., *.yourdomain.com)
      if (allowed.includes('*')) {
        const regexPattern = '^' + allowed.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$';
        const regex = new RegExp(regexPattern, 'i');
        return regex.test(origin);
      }

      return allowed.toLowerCase() === origin.toLowerCase();
    });

    if (isAllowed) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Request-ID'],
};

export const corsMiddleware = cors(corsOptions);
