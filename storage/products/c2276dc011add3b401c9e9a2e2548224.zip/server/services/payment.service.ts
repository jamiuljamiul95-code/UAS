import { paymentRepository } from '../repositories/payment.repository';
import { orderRepository } from '../repositories/order.repository';
import { AppError } from '../utils/error.util';
import { prisma } from '../config/db';

export class PaymentService {
  async getPayments(
    userId: string,
    role: string,
    query: {
      page?: string | number;
      limit?: string | number;
      status?: string;
      method?: string;
      search?: string;
      startDate?: string;
      endDate?: string;
    }
  ) {
    const page = Math.max(1, parseInt(query.page?.toString() || '1', 10));
    const limit = Math.max(1, parseInt(query.limit?.toString() || '10', 10));
    const skip = (page - 1) * limit;

    const { payments, total } = await paymentRepository.findPayments({
      userId,
      role,
      status: query.status,
      method: query.method,
      search: query.search,
      startDate: query.startDate,
      endDate: query.endDate,
      skip,
      take: limit,
    });

    const totalPages = Math.ceil(total / limit);

    return {
      payments,
      pagination: {
        total,
        page,
        limit,
        totalPages,
      }
    };
  }

  async getPaymentById(id: string, userId: string, role: string) {
    const payment = await paymentRepository.findPaymentById(id);
    if (!payment) {
      throw new AppError('Pembayaran tidak ditemukan', 404);
    }

    // RBAC: Customers can only see their own payments
    if (role === 'CUSTOMER' && payment.userId !== userId) {
      throw new AppError('Anda tidak memiliki akses untuk melihat pembayaran ini', 403);
    }

    return payment;
  }

  async createPayment(
    userId: string,
    role: string,
    data: {
      orderId: string;
      amount: number;
      paymentMethod: string;
      proofOfPayment?: string;
      note?: string;
    }
  ) {
    // 1. Find order
    const order = await orderRepository.findOrderById(data.orderId);
    if (!order) {
      throw new AppError('Pesanan tidak ditemukan', 404);
    }

    // 2. Validate Order ownership if CUSTOMER
    if (role === 'CUSTOMER' && order.userId !== userId) {
      throw new AppError('Pesanan ini bukan milik Anda', 403);
    }

    // 3. Validate Order status is not already paid
    if (order.paymentStatus === 'PAID') {
      throw new AppError('Pesanan ini sudah lunas', 400);
    }

    // 4. Validate Amount
    if (data.amount <= 0) {
      throw new AppError('Jumlah pembayaran harus lebih besar dari 0', 400);
    }

    // 5. Supported Payment Methods
    const supportedMethods = ['TRANSFER', 'BANK_TRANSFER', 'QRIS', 'E-WALLET', 'EWALLET', 'CASH', 'COD'];
    const methodUpper = data.paymentMethod.toUpperCase();
    if (!supportedMethods.includes(methodUpper)) {
      throw new AppError(`Metode pembayaran tidak didukung: ${data.paymentMethod}`, 400);
    }

    // Determine initial status based on whether proof is supplied
    let status = 'PENDING';
    if (data.proofOfPayment) {
      status = 'WAITING_VERIFICATION';
    } else if (methodUpper === 'CASH' || methodUpper === 'COD') {
      // In-person payments are pending until paid (often verified directly by cashier/staff)
      status = 'PENDING';
    }

    // 6. Save payment
    const payment = await paymentRepository.createPayment({
      orderId: data.orderId,
      userId: order.userId, // use order user ID
      amount: data.amount,
      paymentMethod: methodUpper,
      status,
      proofOfPayment: data.proofOfPayment,
      note: data.note,
    });

    return payment;
  }

  async uploadProofAndSubmit(id: string, userId: string, role: string, proofOfPayment: string, note?: string) {
    const payment = await paymentRepository.findPaymentById(id);
    if (!payment) {
      throw new AppError('Pembayaran tidak ditemukan', 404);
    }

    // Validate ownership if CUSTOMER
    if (role === 'CUSTOMER' && payment.userId !== userId) {
      throw new AppError('Anda tidak memiliki akses ke pembayaran ini', 403);
    }

    if (payment.status === 'PAID') {
      throw new AppError('Pembayaran ini sudah terverifikasi lunas', 400);
    }

    // Save proof and transition status to WAITING_VERIFICATION
    const updatedPayment = await paymentRepository.updatePaymentStatus(id, 'WAITING_VERIFICATION', note || 'Bukti pembayaran diunggah oleh pelanggan.');

    // Also update proofOfPayment field
    const finalPayment = await prisma?.payment.update({
      where: { id },
      data: { proofOfPayment }
    });

    return { ...updatedPayment, proofOfPayment };
  }

  async approvePayment(id: string, note?: string) {
    const payment = await paymentRepository.findPaymentById(id);
    if (!payment) {
      throw new AppError('Pembayaran tidak ditemukan', 404);
    }

    if (payment.status === 'PAID') {
      throw new AppError('Pembayaran ini sudah lunas', 400);
    }

    // Approve the payment, which automatically updates Order to PAID/PAID via Repository transaction
    const updatedPayment = await paymentRepository.updatePaymentStatus(id, 'PAID', note || 'Disetujui oleh Admin/Staff.');
    return updatedPayment;
  }

  async rejectPayment(id: string, note?: string) {
    const payment = await paymentRepository.findPaymentById(id);
    if (!payment) {
      throw new AppError('Pembayaran tidak ditemukan', 404);
    }

    if (payment.status === 'PAID') {
      throw new AppError('Tidak dapat menolak pembayaran yang sudah lunas', 400);
    }

    // Reject the payment, updates status to REJECTED and order status appropriately
    const updatedPayment = await paymentRepository.updatePaymentStatus(id, 'REJECTED', note || 'Ditolak oleh Admin/Staff.');
    return updatedPayment;
  }
}

export const paymentService = new PaymentService();
