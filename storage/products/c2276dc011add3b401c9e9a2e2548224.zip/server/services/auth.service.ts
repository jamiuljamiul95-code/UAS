import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { userRepository } from '../repositories/user.repository';
import { RegisterRequestDto, LoginRequestDto } from '../dto/request/auth.request.dto';
import { LoginResponseDto, UserResponseDto } from '../dto/response/auth.response.dto';
import { AppError } from '../utils/error.util';
import { env } from '../config/env';

export class AuthService {
  async register(data: RegisterRequestDto): Promise<UserResponseDto> {
    const existingUser = await userRepository.exists(data.email);
    if (existingUser) {
      throw new AppError('Email is already registered', 400);
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);
    const userCount = await userRepository.count();
    const role = userCount === 0 ? 'OWNER' : 'CUSTOMER';

    const user = await userRepository.create({
      name: data.name,
      email: data.email,
      password: hashedPassword,
      phone: data.phone,
      role,
    });

    return {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    };
  }

  async login(data: LoginRequestDto): Promise<LoginResponseDto> {
    const user = await userRepository.findByEmail(data.email);
    if (!user) {
      throw new AppError('Invalid credentials', 401);
    }

    const isMatch = await bcrypt.compare(data.password, user.password);
    if (!isMatch) {
      throw new AppError('Invalid credentials', 401);
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      env.JWT_SECRET,
      { expiresIn: env.JWT_EXPIRES_IN as jwt.SignOptions['expiresIn'] }
    );

    return {
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    };
  }

  async getProfile(userId: string): Promise<Partial<import('@prisma/client').User>> {
    const user = await userRepository.findById(userId);
    if (!user) {
      throw new AppError('User not found', 404);
    }
    return user;
  }
}

export const authService = new AuthService();
