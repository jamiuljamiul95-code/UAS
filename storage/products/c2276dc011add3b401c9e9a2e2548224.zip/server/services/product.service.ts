import { Prisma } from '@prisma/client';
import { productRepository } from '../repositories/product.repository';
import { CreateProductRequestDto, UpdateProductRequestDto, SearchProductRequestDto } from '../dto/request/product.request.dto';
import { ProductResponseDto } from '../dto/response/product.response.dto';
import { AppError } from '../utils/error.util';
import { ProductWithDetails } from '../interfaces/product.repository.interface';

export class ProductService {
  async getProducts(query: SearchProductRequestDto): Promise<{ products: ProductResponseDto[], meta: any }> {
    const page = parseInt(query.page || '1', 10);
    const limit = parseInt(query.limit || '10', 10);
    const skip = (page - 1) * limit;

    const where: Prisma.ProductWhereInput = {};

    if (query.search) {
      where.OR = [
        { name: { contains: query.search } },
        { description: { contains: query.search } },
        { sku: { contains: query.search } },
      ];
    }

    if (query.categoryId && query.categoryId !== 'all') {
      where.categoryId = query.categoryId;
    }

    if (query.status && query.status !== 'all') {
      where.status = query.status;
    }

    if (query.stock && query.stock !== 'all') {
      if (query.stock === 'instock') {
        where.stock = { gt: 0 };
      } else if (query.stock === 'outofstock') {
        where.stock = { equals: 0 };
      }
    }

    const orderBy: Prisma.ProductOrderByWithRelationInput = {};
    if (query.sortBy) {
      const isDesc = query.sortOrder === 'desc';
      if (query.sortBy === 'newest') {
        orderBy.createdAt = 'desc';
      } else if (query.sortBy === 'oldest') {
        orderBy.createdAt = 'asc';
      } else if (query.sortBy === 'price') {
        orderBy.price = isDesc ? 'desc' : 'asc';
      } else if (query.sortBy === 'name') {
        orderBy.name = isDesc ? 'desc' : 'asc';
      } else if (query.sortBy === 'stock') {
        orderBy.stock = isDesc ? 'desc' : 'asc';
      } else {
        orderBy[query.sortBy as keyof Prisma.ProductOrderByWithRelationInput] = isDesc ? 'desc' : 'asc';
      }
    } else {
      orderBy.createdAt = 'desc';
    }

    const [products, totalItems] = await Promise.all([
      productRepository.findMany({
        where,
        skip,
        take: limit,
        orderBy,
      }),
      productRepository.count({ where }),
    ]);

    return {
      products: products.map(p => this.mapToDto(p)),
      meta: {
        page,
        limit,
        totalItems,
        totalPages: Math.ceil(totalItems / limit),
      },
    };
  }

  async getProductById(id: string): Promise<ProductResponseDto> {
    const product = await productRepository.findById(id);
    if (!product) {
      throw new AppError('Product not found', 404);
    }
    return this.mapToDto(product);
  }

  async getProductBySlug(slug: string): Promise<ProductResponseDto> {
    const product = await productRepository.findBySlug(slug);
    if (!product) {
      throw new AppError('Product not found', 404);
    }
    return this.mapToDto(product);
  }

  async createProduct(data: CreateProductRequestDto): Promise<ProductResponseDto> {
    const existingSlug = await productRepository.findBySlug(data.slug);
    if (existingSlug) {
      throw new AppError('Product slug already exists', 400);
    }

    const existingSku = await productRepository.findBySku(data.sku);
    if (existingSku) {
      throw new AppError('Product SKU already exists', 400);
    }

    const product = await productRepository.create({
      name: data.name,
      slug: data.slug,
      description: data.description,
      price: data.price,
      discountPrice: data.discountPrice ?? null,
      weight: data.weight ?? null,
      status: data.status || 'ACTIVE',
      stock: data.stock,
      sku: data.sku,
      category: { connect: { id: data.categoryId } },
      images: data.images?.length ? {
        create: data.images.map((url, idx) => ({
          url,
          isMain: idx === 0,
        })),
      } : undefined,
      variants: data.variants?.length ? {
        create: data.variants.map(v => ({
          color: v.color || null,
          size: v.size || null,
          stock: v.stock,
          sku: v.sku || null,
        })),
      } : undefined,
    });

    return this.mapToDto(product);
  }

  async updateProduct(id: string, data: UpdateProductRequestDto): Promise<ProductResponseDto> {
    const product = await productRepository.findById(id);
    if (!product) {
      throw new AppError('Product not found', 404);
    }

    if (data.slug && data.slug !== product.slug) {
      const existingSlug = await productRepository.findBySlug(data.slug);
      if (existingSlug) {
        throw new AppError('Product slug already exists', 400);
      }
    }

    if (data.sku && data.sku !== product.sku) {
      const existingSku = await productRepository.findBySku(data.sku);
      if (existingSku) {
        throw new AppError('Product SKU already exists', 400);
      }
    }

    const updateData: Prisma.ProductUpdateInput = {
      name: data.name,
      slug: data.slug,
      description: data.description,
      price: data.price,
      discountPrice: data.discountPrice !== undefined ? data.discountPrice : undefined,
      weight: data.weight !== undefined ? data.weight : undefined,
      status: data.status,
      stock: data.stock,
      sku: data.sku,
    };

    if (data.categoryId) {
      updateData.category = { connect: { id: data.categoryId } };
    }

    if (data.images !== undefined) {
      updateData.images = {
        deleteMany: {},
        create: data.images.map((url, idx) => ({
          url,
          isMain: idx === 0,
        })),
      };
    }

    if (data.variants !== undefined) {
      updateData.variants = {
        deleteMany: {},
        create: data.variants.map(v => ({
          color: v.color || null,
          size: v.size || null,
          stock: v.stock,
          sku: v.sku || null,
        })),
      };
    }

    const updatedProduct = await productRepository.update(id, updateData);
    return this.mapToDto(updatedProduct);
  }

  async deleteProduct(id: string): Promise<void> {
    const product = await productRepository.findById(id);
    if (!product) {
      throw new AppError('Product not found', 404);
    }

    const hasOrderItems = await productRepository.hasOrderItems(id);
    if (hasOrderItems) {
      throw new AppError('This product has transaction history.', 400);
    }

    await productRepository.delete(id);
  }

  private mapToDto(product: ProductWithDetails): ProductResponseDto {
    return {
      id: product.id,
      name: product.name,
      slug: product.slug,
      description: product.description,
      price: product.price,
      discountPrice: product.discountPrice ?? null,
      weight: product.weight ?? null,
      status: product.status,
      stock: product.stock,
      sku: product.sku,
      categoryId: product.categoryId,
      category: product.category ? {
        id: product.category.id,
        name: product.category.name,
        slug: product.category.slug,
      } : undefined,
      images: product.images?.map(img => ({
        id: img.id,
        url: img.url,
        isMain: img.isMain,
      })) || [],
      variants: product.variants?.map(v => ({
        id: v.id,
        color: v.color,
        size: v.size,
        stock: v.stock,
        sku: v.sku,
      })) || [],
      createdAt: product.createdAt,
      updatedAt: product.updatedAt,
    };
  }
}

export const productService = new ProductService();
