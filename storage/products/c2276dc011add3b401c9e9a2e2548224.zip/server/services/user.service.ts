import bcrypt from 'bcrypt';
import { userRepository, addressRepository } from '../repositories/user.repository';
import { SearchUserRequestDto, CreateUserRequestDto, UpdateUserRequestDto, UpdateProfileRequestDto, AddressRequestDto } from '../dto/request/user.request.dto';
import { UserResponseDto, UserDetailResponseDto, AddressResponseDto } from '../dto/response/user.response.dto';
import { AppError } from '../utils/error.util';
import { Prisma, User, Address } from '@prisma/client';

export class UserService {
  private mapUserToDto(user: User): UserResponseDto {
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      phone: user.phone,
      status: user.status,
      avatar: user.avatar,
      dob: user.dob,
      gender: user.gender,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };
  }

  private mapAddressToDto(address: Address): AddressResponseDto {
    return {
      id: address.id,
      userId: address.userId,
      title: address.title,
      recipientName: address.recipientName,
      phone: address.phone,
      province: address.province,
      city: address.city,
      district: address.district,
      postalCode: address.postalCode,
      address: address.address,
      notes: address.notes,
      isDefault: address.isDefault,
      createdAt: address.createdAt,
      updatedAt: address.updatedAt,
    };
  }

  async getUsers(query: SearchUserRequestDto): Promise<{ users: UserResponseDto[], meta: any }> {
    const page = parseInt(query.page || '1', 10);
    const limit = parseInt(query.limit || '10', 10);
    const skip = (page - 1) * limit;

    const where: Prisma.UserWhereInput = {};

    // 1. Search filter
    if (query.search) {
      where.OR = [
        { name: { contains: query.search } },
        { email: { contains: query.search } },
        { phone: { contains: query.search } },
      ];
    }

    // 2. Filter by Role
    if (query.role && query.role !== 'all') {
      where.role = query.role;
    }

    // 3. Filter by Status
    if (query.status && query.status !== 'all') {
      where.status = query.status;
    }

    // 4. Filter by Registration Date
    if (query.startDate || query.endDate) {
      where.createdAt = {};
      if (query.startDate) {
        where.createdAt.gte = new Date(query.startDate);
      }
      if (query.endDate) {
        // Ensure date search matches full end date day
        const endOfDay = new Date(query.endDate);
        endOfDay.setHours(23, 59, 59, 999);
        where.createdAt.lte = endOfDay;
      }
    }

    // 5. Sorting
    const orderBy: Prisma.UserOrderByWithRelationInput = {};
    const sortOrder = query.sortOrder === 'asc' ? 'asc' : 'desc';

    if (query.sortBy) {
      if (query.sortBy === 'name') {
        orderBy.name = sortOrder;
      } else if (query.sortBy === 'email') {
        orderBy.email = sortOrder;
      } else if (query.sortBy === 'newest') {
        orderBy.createdAt = 'desc';
      } else if (query.sortBy === 'oldest') {
        orderBy.createdAt = 'asc';
      } else {
        orderBy[query.sortBy as keyof Prisma.UserOrderByWithRelationInput] = sortOrder;
      }
    } else {
      orderBy.createdAt = 'desc';
    }

    const [users, totalItems] = await Promise.all([
      userRepository.findMany({
        where,
        orderBy,
        skip,
        take: limit,
      }),
      userRepository.count(where),
    ]);

    const totalPages = Math.ceil(totalItems / limit);

    return {
      users: users.map(user => this.mapUserToDto(user)),
      meta: {
        page,
        limit,
        totalItems,
        totalPages,
      }
    };
  }

  async getUserById(id: string): Promise<UserDetailResponseDto> {
    const user = await userRepository.findById(id);
    if (!user) {
      throw new AppError('User not found', 404);
    }

    const [addresses, stats] = await Promise.all([
      addressRepository.findManyByUserId(id),
      userRepository.getUserOrderStats(id),
    ]);

    return {
      ...this.mapUserToDto(user),
      addresses: addresses.map(addr => this.mapAddressToDto(addr)),
      orderCount: stats.orderCount,
      totalSpent: stats.totalSpent,
    };
  }

  async createUser(data: CreateUserRequestDto): Promise<UserResponseDto> {
    // Check email uniqueness
    const existingEmail = await userRepository.findByEmail(data.email);
    if (existingEmail) {
      throw new AppError('Email is already registered', 400);
    }

    // Check phone uniqueness if provided
    if (data.phone) {
      const existingPhone = await userRepository.findByPhone(data.phone);
      if (existingPhone) {
        throw new AppError('Phone number is already registered', 400);
      }
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);

    const user = await userRepository.create({
      name: data.name,
      email: data.email,
      password: hashedPassword,
      phone: data.phone || null,
      role: data.role || 'CUSTOMER',
      status: data.status || 'ACTIVE',
      avatar: data.avatar || null,
      dob: data.dob || null,
      gender: data.gender || null,
    });

    return this.mapUserToDto(user);
  }

  async updateUser(id: string, data: UpdateUserRequestDto): Promise<UserResponseDto> {
    const user = await userRepository.findById(id);
    if (!user) {
      throw new AppError('User not found', 404);
    }

    // Email uniqueness check
    if (data.email && data.email !== user.email) {
      const existingEmail = await userRepository.findByEmail(data.email);
      if (existingEmail) {
        throw new AppError('Email is already registered', 400);
      }
    }

    // Phone uniqueness check
    if (data.phone && data.phone !== user.phone) {
      const existingPhone = await userRepository.findByPhone(data.phone);
      if (existingPhone) {
        throw new AppError('Phone number is already registered', 400);
      }
    }

    const updateData: Prisma.UserUpdateInput = {
      name: data.name,
      email: data.email,
      phone: data.phone !== undefined ? data.phone : undefined,
      role: data.role,
      status: data.status,
      avatar: data.avatar !== undefined ? data.avatar : undefined,
      dob: data.dob !== undefined ? data.dob : undefined,
      gender: data.gender !== undefined ? data.gender : undefined,
    };

    if (data.password) {
      updateData.password = await bcrypt.hash(data.password, 10);
    }

    const updatedUser = await userRepository.update(id, updateData);
    return this.mapUserToDto(updatedUser);
  }

  async deleteUser(id: string, requestingUserId: string): Promise<void> {
    if (id === requestingUserId) {
      throw new AppError('You cannot delete your own account', 400);
    }

    const user = await userRepository.findById(id);
    if (!user) {
      throw new AppError('User not found', 404);
    }

    const hasOrders = await userRepository.hasOrders(id);
    if (hasOrders) {
      throw new AppError('This customer has transaction history.', 400);
    }

    await userRepository.delete(id);
  }

  async updateUserStatus(id: string, status: string): Promise<UserResponseDto> {
    const user = await userRepository.findById(id);
    if (!user) {
      throw new AppError('User not found', 404);
    }

    if (status !== 'ACTIVE' && status !== 'INACTIVE') {
      throw new AppError('Invalid status value', 400);
    }

    const updatedUser = await userRepository.update(id, { status });
    return this.mapUserToDto(updatedUser);
  }

  async updateProfile(userId: string, data: UpdateProfileRequestDto): Promise<UserResponseDto> {
    const user = await userRepository.findById(userId);
    if (!user) {
      throw new AppError('User not found', 404);
    }

    if (data.email && data.email !== user.email) {
      const existingEmail = await userRepository.findByEmail(data.email);
      if (existingEmail) {
        throw new AppError('Email is already registered', 400);
      }
    }

    if (data.phone && data.phone !== user.phone) {
      const existingPhone = await userRepository.findByPhone(data.phone);
      if (existingPhone) {
        throw new AppError('Phone number is already registered', 400);
      }
    }

    const updateData: Prisma.UserUpdateInput = {
      name: data.name,
      email: data.email,
      phone: data.phone !== undefined ? data.phone : undefined,
      avatar: data.avatar !== undefined ? data.avatar : undefined,
      dob: data.dob !== undefined ? data.dob : undefined,
      gender: data.gender !== undefined ? data.gender : undefined,
    };

    if (data.password) {
      updateData.password = await bcrypt.hash(data.password, 10);
    }

    const updatedUser = await userRepository.update(userId, updateData);
    return this.mapUserToDto(updatedUser);
  }

  // Address operations
  async getAddresses(userId: string): Promise<AddressResponseDto[]> {
    const addresses = await addressRepository.findManyByUserId(userId);
    return addresses.map(addr => this.mapAddressToDto(addr));
  }

  async createAddress(userId: string, data: AddressRequestDto): Promise<AddressResponseDto> {
    const existing = await addressRepository.findManyByUserId(userId);
    const isFirst = existing.length === 0;

    let setAsDefault = data.isDefault;
    if (isFirst) {
      setAsDefault = true;
    }

    if (setAsDefault) {
      await addressRepository.unsetDefaultAddresses(userId);
    }

    const address = await addressRepository.create({
      userId,
      title: data.title || 'Alamat',
      recipientName: data.recipientName,
      phone: data.phone,
      province: data.province,
      city: data.city,
      district: data.district,
      postalCode: data.postalCode,
      address: data.address,
      notes: data.notes || null,
      isDefault: setAsDefault,
    });

    return this.mapAddressToDto(address);
  }

  async updateAddress(userId: string, addressId: string, data: Partial<AddressRequestDto>): Promise<AddressResponseDto> {
    const address = await addressRepository.findById(addressId);
    if (!address || address.userId !== userId) {
      throw new AppError('Address not found', 404);
    }

    if (data.isDefault) {
      await addressRepository.unsetDefaultAddresses(userId);
    }

    const updated = await addressRepository.update(addressId, {
      title: data.title,
      recipientName: data.recipientName,
      phone: data.phone,
      province: data.province,
      city: data.city,
      district: data.district,
      postalCode: data.postalCode,
      address: data.address,
      notes: data.notes === undefined ? undefined : (data.notes || null),
      isDefault: data.isDefault,
    });

    return this.mapAddressToDto(updated);
  }

  async deleteAddress(userId: string, addressId: string): Promise<void> {
    const address = await addressRepository.findById(addressId);
    if (!address || address.userId !== userId) {
      throw new AppError('Address not found', 404);
    }

    const wasDefault = address.isDefault;

    await addressRepository.delete(addressId);

    // If we deleted the default address, let's make another default if possible
    if (wasDefault) {
      const remaining = await addressRepository.findManyByUserId(userId);
      if (remaining.length > 0) {
        await addressRepository.update(remaining[0].id, { isDefault: true });
      }
    }
  }
}

export const userService = new UserService();
