import { checkoutRepository } from '../repositories/checkout.repository';
import { cartRepository } from '../repositories/cart.repository';
import { prisma } from '../config/db';
import { AppError } from '../utils/error.util';
import { Voucher, Order, OrderItem, Address } from '@prisma/client';

export interface ShippingMethod {
  carrier: string;
  name: string;
  cost: number;
  etd: string;
}

export const SHIPPING_METHODS: ShippingMethod[] = [
  { carrier: 'JNE', name: 'JNE Reguler', cost: 15000, etd: '2-3 Hari' },
  { carrier: 'J&T', name: 'J&T Express', cost: 12000, etd: '1-2 Hari' },
  { carrier: 'SiCepat', name: 'SiCepat Reguler', cost: 10000, etd: '1-2 Hari' },
  { carrier: 'POS', name: 'POS Kilat Khusus', cost: 14000, etd: '3-4 Hari' },
  { carrier: 'Pickup', name: 'Ambil Sendiri', cost: 0, etd: 'Hari yang sama (Sore)' },
];

export class CheckoutService {
  async getShippingMethods(): Promise<ShippingMethod[]> {
    return SHIPPING_METHODS;
  }

  async getVouchers(): Promise<Voucher[]> {
    return checkoutRepository.findActiveVouchers();
  }

  async previewCheckout(
    userId: string,
    data: {
      addressId?: string;
      shippingCarrier?: string;
      voucherCode?: string;
    }
  ) {
    // 1. Get Cart Items
    const cart = await cartRepository.findCartByUserId(userId);
    if (!cart || cart.items.length === 0) {
      throw new AppError('Your shopping cart is empty', 400);
    }

    // Filter only selected items
    const selectedItems = cart.items.filter(item => item.selected);
    if (selectedItems.length === 0) {
      throw new AppError('No items selected for checkout', 400);
    }

    // 2. Validate Stock and Item Active status
    const itemsPreview = [];
    let subtotal = 0;
    const stockErrors: string[] = [];

    for (const item of selectedItems) {
      const product = item.product;
      const isProductActive = product.status === 'ACTIVE';
      let availableStock = product.stock;
      let hasEnoughStock = true;

      if (item.variantId && item.variant) {
        availableStock = item.variant.stock;
      }

      if (!isProductActive) {
        hasEnoughStock = false;
        stockErrors.push(`Product "${product.name}" is no longer active and available for purchase.`);
      } else if (availableStock < item.quantity) {
        hasEnoughStock = false;
        stockErrors.push(
          `Insufficient stock for "${product.name}"${item.variant ? ` (${item.variant.size || ''} ${item.variant.color || ''})` : ''}. Requested: ${item.quantity}, Available: ${availableStock}`
        );
      }

      const price = product.discountPrice !== null && product.discountPrice < product.price 
        ? product.discountPrice 
        : product.price;

      const itemSubtotal = price * item.quantity;
      if (hasEnoughStock) {
        subtotal += itemSubtotal;
      }

      itemsPreview.push({
        cartItemId: item.id,
        productId: product.id,
        name: product.name,
        slug: product.slug,
        categoryName: (product as any).category?.name || 'General',
        imageUrl: product.images?.[0]?.url || '/assets/placeholder-product.png',
        variantId: item.variantId,
        variantName: item.variant ? `${item.variant.size || ''} ${item.variant.color || ''}`.trim() : null,
        quantity: item.quantity,
        originalPrice: product.price,
        discountPrice: product.discountPrice,
        price,
        subtotal: itemSubtotal,
        isAvailable: isProductActive && availableStock > 0,
        hasEnoughStock,
        availableStock,
      });
    }

    // 3. Address Preview
    let address: Address | null = null;
    if (data.addressId) {
      address = await prisma.address.findFirst({
        where: { id: data.addressId, userId }
      });
      if (!address) {
        throw new AppError('Selected delivery address not found', 404);
      }
    } else {
      // Find default address
      address = await prisma.address.findFirst({
        where: { userId, isDefault: true }
      });
      // Fallback to any address
      if (!address) {
        address = await prisma.address.findFirst({
          where: { userId }
        });
      }
    }

    // 4. Shipping Fee Calculation
    let shippingFee = 0;
    let selectedShipping = null;
    if (data.shippingCarrier) {
      selectedShipping = SHIPPING_METHODS.find(
        m => m.carrier.toLowerCase() === data.shippingCarrier?.toLowerCase()
      );
      if (!selectedShipping) {
        throw new AppError(`Invalid shipping carrier: ${data.shippingCarrier}`, 400);
      }
      shippingFee = selectedShipping.cost;
    }

    // 5. Voucher Discount Calculation
    let discountAmount = 0;
    let appliedVoucher = null;
    let voucherError = null;

    if (data.voucherCode) {
      try {
        const voucher = await checkoutRepository.findVoucherByCode(data.voucherCode);
        if (!voucher) {
          throw new AppError('Voucher code does not exist', 400);
        }

        const now = new Date();
        if (voucher.status !== 'ACTIVE' || (voucher.expiryDate && voucher.expiryDate < now)) {
          throw new AppError('Voucher has expired or is inactive', 400);
        }

        if (voucher.quota > 0 && voucher.usedCount >= voucher.quota) {
          throw new AppError('Voucher quota has run out', 400);
        }

        if (subtotal < voucher.minPurchase) {
          throw new AppError(`Voucher requires a minimum purchase of Rp${voucher.minPurchase.toLocaleString('id-ID')}`, 400);
        }

        const usageCount = await checkoutRepository.getUserVoucherUsageCount(userId, voucher.id);
        if (usageCount > 0) {
          throw new AppError('You have already redeemed this voucher', 400);
        }

        if (voucher.type === 'NOMINAL') {
          discountAmount = voucher.value;
        } else if (voucher.type === 'PERCENT') {
          discountAmount = (subtotal * voucher.value) / 100;
        }

        // Clip discount to subtotal
        if (discountAmount > subtotal) {
          discountAmount = subtotal;
        }

        appliedVoucher = {
          id: voucher.id,
          code: voucher.code,
          type: voucher.type,
          value: voucher.value,
          discountAmount,
        };
      } catch (err: any) {
        voucherError = err.message || 'Voucher cannot be applied';
      }
    }

    // 6. Tax Calculation (Indonesia PPN: 11% of net subtotal)
    const netSubtotal = Math.max(0, subtotal - discountAmount);
    const taxAmount = Math.round(netSubtotal * 0.11); // Indonesian standard PPN 11%

    // 7. Grand Total
    const grandTotal = netSubtotal + shippingFee + taxAmount;

    return {
      items: itemsPreview,
      summary: {
        subtotal,
        discountAmount,
        shippingFee,
        taxAmount,
        grandTotal,
      },
      address,
      shipping: selectedShipping,
      voucher: appliedVoucher,
      voucherError,
      stockErrors,
      isValid: stockErrors.length === 0,
    };
  }

  async executeCheckout(
    userId: string,
    data: {
      addressId: string;
      shippingCarrier: string;
      voucherCode?: string;
      paymentMethod: string;
    }
  ) {
    // 1. Get Address
    const address = await prisma.address.findFirst({
      where: { id: data.addressId, userId }
    });
    if (!address) {
      throw new AppError('Selected shipping address not found', 400);
    }

    // 2. Validate shipping carrier
    const shippingMethod = SHIPPING_METHODS.find(
      m => m.carrier.toLowerCase() === data.shippingCarrier.toLowerCase()
    );
    if (!shippingMethod) {
      throw new AppError(`Invalid shipping carrier selection: ${data.shippingCarrier}`, 400);
    }

    // 3. Build Preview first to perform full stock and voucher validations
    const preview = await this.previewCheckout(userId, {
      addressId: data.addressId,
      shippingCarrier: data.shippingCarrier,
      voucherCode: data.voucherCode,
    });

    if (!preview.isValid) {
      throw new AppError(
        `Checkout failed: Stock changes occurred. ${preview.stockErrors.join(' ')}`,
        400
      );
    }

    if (data.voucherCode && preview.voucherError) {
      throw new AppError(`Voucher error: ${preview.voucherError}`, 400);
    }

    // 4. Transform items for insertion
    const orderItems = preview.items.map(item => ({
      productId: item.productId,
      variantId: item.variantId,
      quantity: item.quantity,
      price: item.price,
    }));

    const cartItemIdsToDelete = preview.items.map(item => item.cartItemId);

    // 5. Execute creation within a Prisma Transaction
    const order = await checkoutRepository.createOrderTransaction({
      userId,
      address,
      shippingCarrier: shippingMethod.name,
      shippingFee: shippingMethod.cost,
      voucherCode: data.voucherCode,
      subtotal: preview.summary.subtotal,
      discountAmount: preview.summary.discountAmount,
      taxAmount: preview.summary.taxAmount,
      totalAmount: preview.summary.grandTotal,
      paymentMethod: data.paymentMethod,
      orderType: 'ONLINE',
      items: orderItems,
      cartItemIdsToDelete,
    });

    return order;
  }
}

export const checkoutService = new CheckoutService();
