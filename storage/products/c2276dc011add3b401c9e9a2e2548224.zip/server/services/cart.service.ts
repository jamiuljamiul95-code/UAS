import { cartRepository } from '../repositories/cart.repository';
import { productRepository } from '../repositories/product.repository';
import { AddToCartRequestDto, UpdateCartItemRequestDto, SelectCartItemsRequestDto } from '../dto/request/cart.request.dto';
import { CartResponseDto, CartItemResponseDto, CartSummaryResponseDto } from '../dto/response/cart.response.dto';
import { AppError } from '../utils/error.util';
import { CartWithDetails, CartItemWithDetails } from '../interfaces/cart.repository.interface';

export class CartService {
  private cartRepository = cartRepository;
  private productRepository = productRepository;

  /**
   * Retrieves or creates a cart for the user and maps it to a responsive DTO.
   * Performs automatic stock adjustments if the requested quantity exceeds current stock.
   */
  async getCart(userId: string): Promise<CartResponseDto> {
    let cart = await this.cartRepository.findCartByUserId(userId);
    if (!cart) {
      cart = await this.cartRepository.createCart(userId);
    }

    // Auto-correct quantities in database if stock has changed
    let hasChanges = false;
    for (const item of cart.items) {
      const availableStock = item.variantId ? (item.variant?.stock ?? 0) : item.product.stock;
      const isActive = item.product.status === 'ACTIVE';

      if (!isActive) {
        continue;
      }

      if (availableStock > 0 && item.quantity > availableStock) {
        // Auto-correct quantity down to available stock limit
        await this.cartRepository.updateCartItemQuantity(item.id, availableStock);
        item.quantity = availableStock;
        hasChanges = true;
      }
    }

    // Re-fetch cart if quantities were auto-corrected
    if (hasChanges) {
      cart = await this.cartRepository.findCartByUserId(userId) || cart;
    }

    return this.mapToCartResponseDto(cart);
  }

  /**
   * Adds an item to the user's shopping cart.
   * Increments quantity if item already exists for the same product + variant combo.
   */
  async addToCart(userId: string, data: AddToCartRequestDto): Promise<CartResponseDto> {
    let cart = await this.cartRepository.findCartByUserId(userId);
    if (!cart) {
      cart = await this.cartRepository.createCart(userId);
    }

    // 1. Verify product exists
    const product = await this.productRepository.findById(data.productId);
    if (!product) {
      throw new AppError('Product not found', 404);
    }

    // 2. Validate product status is ACTIVE
    if (product.status !== 'ACTIVE') {
      throw new AppError('This product is currently inactive or draft and cannot be added to the cart', 400);
    }

    // 3. Verify variant if variantId is provided
    let availableStock = product.stock;
    if (data.variantId) {
      const variant = product.variants.find(v => v.id === data.variantId);
      if (!variant) {
        throw new AppError('Product variant not found', 404);
      }
      availableStock = variant.stock;
    }

    // 4. Check if item already exists in the cart
    const existingItem = await this.cartRepository.findCartItem(cart.id, data.productId, data.variantId || null);

    const targetQuantity = existingItem ? (existingItem.quantity + data.quantity) : data.quantity;

    // 5. Stock Validation
    if (availableStock <= 0) {
      throw new AppError('This product variant is currently out of stock', 400);
    }

    if (targetQuantity > availableStock) {
      throw new AppError(
        `Cannot add requested quantity. Only ${availableStock} items are available in stock. Your cart already has ${existingItem?.quantity ?? 0}.`,
        400
      );
    }

    // 6. Add or update quantity
    if (existingItem) {
      await this.cartRepository.updateCartItemQuantity(existingItem.id, targetQuantity);
    } else {
      await this.cartRepository.addCartItem(cart.id, data.productId, data.variantId || null, data.quantity);
    }

    // Return full updated cart
    return this.getCart(userId);
  }

  /**
   * Updates the quantity of an item already in the cart.
   */
  async updateCartItemQuantity(userId: string, itemId: string, data: UpdateCartItemRequestDto): Promise<CartResponseDto> {
    const item = await this.cartRepository.findCartItemById(itemId);
    if (!item) {
      throw new AppError('Cart item not found', 404);
    }

    // Ensure cart belongs to the requesting user
    const cart = await this.cartRepository.findCartByUserId(userId);
    if (!cart || item.cartId !== cart.id) {
      throw new AppError('Unauthorized access to this cart item', 403);
    }

    const isActive = item.product.status === 'ACTIVE';
    if (!isActive) {
      throw new AppError('This product is inactive and cannot be updated', 400);
    }

    const availableStock = item.variantId ? (item.variant?.stock ?? 0) : item.product.stock;

    if (data.quantity > availableStock) {
      throw new AppError(`Cannot set quantity to ${data.quantity}. Only ${availableStock} items are available in stock.`, 400);
    }

    await this.cartRepository.updateCartItemQuantity(itemId, data.quantity);

    return this.getCart(userId);
  }

  /**
   * Deletes a cart item.
   */
  async deleteCartItem(userId: string, itemId: string): Promise<CartResponseDto> {
    const item = await this.cartRepository.findCartItemById(itemId);
    if (!item) {
      throw new AppError('Cart item not found', 404);
    }

    const cart = await this.cartRepository.findCartByUserId(userId);
    if (!cart || item.cartId !== cart.id) {
      throw new AppError('Unauthorized access to this cart item', 403);
    }

    await this.cartRepository.deleteCartItem(itemId);

    return this.getCart(userId);
  }

  /**
   * Clears all items in the user's cart.
   */
  async clearCart(userId: string): Promise<CartResponseDto> {
    const cart = await this.cartRepository.findCartByUserId(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    await this.cartRepository.clearCart(cart.id);

    return this.getCart(userId);
  }

  /**
   * Updates selection status (selected/unselected) of cart items.
   */
  async selectCartItems(userId: string, data: SelectCartItemsRequestDto): Promise<CartResponseDto> {
    const cart = await this.cartRepository.findCartByUserId(userId);
    if (!cart) {
      throw new AppError('Cart not found', 404);
    }

    if (data.all) {
      await this.cartRepository.updateAllCartItemsSelection(cart.id, data.selected);
    } else if (data.ids && data.ids.length > 0) {
      await this.cartRepository.updateCartItemsSelectionBulk(cart.id, data.ids, data.selected);
    } else if (data.id) {
      const item = await this.cartRepository.findCartItemById(data.id);
      if (!item || item.cartId !== cart.id) {
        throw new AppError('Cart item not found in your cart', 404);
      }
      await this.cartRepository.updateCartItemSelection(data.id, data.selected);
    } else {
      throw new AppError('At least one of id, ids, or all must be provided', 400);
    }

    return this.getCart(userId);
  }

  /**
   * Maps Prisma database entity to structured DTO response, calculating discounts and subtotals.
   */
  private mapToCartResponseDto(cart: CartWithDetails): CartResponseDto {
    const items: CartItemResponseDto[] = cart.items.map((item) => {
      const originalPrice = item.product.price;
      const discountPrice = item.product.discountPrice;
      const price = discountPrice !== null && discountPrice < originalPrice ? discountPrice : originalPrice;
      
      const quantity = item.quantity;
      const subtotal = price * quantity;
      const originalSubtotal = originalPrice * quantity;
      const savings = originalSubtotal - subtotal;

      const availableStock = item.variantId ? (item.variant?.stock ?? 0) : item.product.stock;
      const isActive = item.product.status === 'ACTIVE';
      const hasEnoughStock = quantity <= availableStock && availableStock > 0;

      // Format variant name
      let variantName: string | null = null;
      let sku = item.product.sku;
      if (item.variant) {
        const parts: string[] = [];
        if (item.variant.color) parts.push(`Color: ${item.variant.color}`);
        if (item.variant.size) parts.push(`Size: ${item.variant.size}`);
        variantName = parts.length > 0 ? parts.join(', ') : 'Default Variant';
        if (item.variant.sku) sku = item.variant.sku;
      }

      // Main image URL resolution
      const mainImage = item.product.images.find(img => img.isMain) || item.product.images[0];
      const imageUrl = mainImage ? mainImage.url : '/assets/placeholder-product.png';

      return {
        id: item.id,
        productId: item.productId,
        name: item.product.name,
        slug: item.product.slug,
        categoryName: item.product.category?.name || 'Uncategorized',
        imageUrl,
        variantId: item.variantId,
        variantName,
        sku,
        originalPrice,
        discountPrice,
        price,
        quantity,
        subtotal,
        originalSubtotal,
        savings,
        selected: item.selected,
        availableStock,
        hasEnoughStock,
        isActive,
      };
    });

    // Summary calculations
    let totalItemsCount = 0;
    let totalUniqueItems = items.length;
    let selectedItemsCount = 0;
    let selectedUniqueItems = 0;
    
    let originalSubtotal = 0;
    let subtotal = 0;

    for (const item of items) {
      totalItemsCount += item.quantity;
      
      if (item.selected && item.isActive && item.hasEnoughStock) {
        selectedItemsCount += item.quantity;
        selectedUniqueItems += 1;
        originalSubtotal += item.originalSubtotal;
        subtotal += item.subtotal;
      }
    }

    const totalDiscount = originalSubtotal - subtotal;
    const totalPayment = subtotal;

    const summary: CartSummaryResponseDto = {
      totalItemsCount,
      totalUniqueItems,
      selectedItemsCount,
      selectedUniqueItems,
      originalSubtotal,
      subtotal,
      totalDiscount,
      totalPayment,
    };

    return {
      id: cart.id,
      userId: cart.userId,
      items,
      summary,
    };
  }
}

export const cartService = new CartService();
