import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { paymentService } from '../services/payment.service';
import { sendOK, sendCreated } from '../utils/response.util';
import { AppError } from '../utils/error.util';
import { createPaymentSchema, verifyPaymentSchema } from '../validators/payment.validator';

export const getPayments = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;

    if (!userId || !role) {
      throw new AppError('Authentication required', 401);
    }

    const { payments, pagination } = await paymentService.getPayments(userId, role, req.query);
    sendOK(res, 'Daftar pembayaran berhasil diambil', payments, pagination);
  } catch (error) {
    next(error);
  }
};

export const getPaymentById = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;
    const { id } = req.params;

    if (!userId || !role) {
      throw new AppError('Authentication required', 401);
    }

    const payment = await paymentService.getPaymentById(id, userId, role);
    sendOK(res, 'Detail pembayaran berhasil diambil', payment);
  } catch (error) {
    next(error);
  }
};

export const createPayment = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;

    if (!userId || !role) {
      throw new AppError('Authentication required', 401);
    }

    // Validate body using Zod
    const validatedData = createPaymentSchema.parse(req.body);

    const payment = await paymentService.createPayment(userId, role, validatedData);
    sendCreated(res, 'Pembayaran berhasil dibuat', payment);
  } catch (error) {
    next(error);
  }
};

export const uploadProofOfPayment = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    if (!req.file) {
      throw new AppError('File bukti pembayaran wajib diunggah!', 400);
    }

    // Store relative URL path
    const fileUrl = `/uploads/payments/${req.file.filename}`;

    sendOK(res, 'Bukti pembayaran berhasil diunggah', { url: fileUrl });
  } catch (error) {
    next(error);
  }
};

export const approvePayment = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const role = req.user?.role;

    if (role !== 'OWNER' && role !== 'ADMIN' && role !== 'STAFF') {
      throw new AppError('Akses ditolak: Hanya admin yang dapat menyetujui pembayaran', 403);
    }

    const { id } = req.params;
    const validatedBody = verifyPaymentSchema.parse(req.body);

    const payment = await paymentService.approvePayment(id, validatedBody.note);
    sendOK(res, 'Pembayaran berhasil disetujui dan diverifikasi', payment);
  } catch (error) {
    next(error);
  }
};

export const rejectPayment = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const role = req.user?.role;

    if (role !== 'OWNER' && role !== 'ADMIN' && role !== 'STAFF') {
      throw new AppError('Akses ditolak: Hanya admin yang dapat menolak pembayaran', 403);
    }

    const { id } = req.params;
    const validatedBody = verifyPaymentSchema.parse(req.body);

    const payment = await paymentService.rejectPayment(id, validatedBody.note);
    sendOK(res, 'Pembayaran berhasil ditolak', payment);
  } catch (error) {
    next(error);
  }
};
