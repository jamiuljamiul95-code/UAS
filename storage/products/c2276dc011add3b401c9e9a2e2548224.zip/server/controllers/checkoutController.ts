import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { checkoutService } from '../services/checkout.service';
import { orderService } from '../services/order.service';
import { sendOK, sendCreated } from '../utils/response.util';
import { AppError } from '../utils/error.util';

export const getShippingMethods = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const shipping = await checkoutService.getShippingMethods();
    sendOK(res, 'Shipping methods retrieved successfully', shipping);
  } catch (error) {
    next(error);
  }
};

export const getVouchers = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const vouchers = await checkoutService.getVouchers();
    sendOK(res, 'Vouchers retrieved successfully', vouchers);
  } catch (error) {
    next(error);
  }
};

export const previewCheckout = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }

    const preview = await checkoutService.previewCheckout(userId, req.body);
    sendOK(res, 'Checkout preview generated successfully', preview);
  } catch (error) {
    next(error);
  }
};

export const executeCheckout = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }

    const order = await checkoutService.executeCheckout(userId, req.body);
    const mappedOrder = orderService.mapToResponseDto(order);
    sendCreated(res, 'Checkout order completed successfully', mappedOrder);
  } catch (error) {
    next(error);
  }
};
