import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth.service';
import { sendCreated, sendOK } from '../utils/response.util';
import { AppError } from '../utils/error.util';
import { AuthRequest } from '../interfaces/auth.interface';

export const register = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const data = await authService.register(req.body);
    sendCreated(res, 'User registered successfully', data);
  } catch (error) {
    next(error);
  }
};

export const login = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const data = await authService.login(req.body);
    sendOK(res, 'Login successful', data);
  } catch (error) {
    next(error);
  }
};

export const getProfile = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Not authenticated', 401);
    }

    const data = await authService.getProfile(userId);
    sendOK(res, 'Profile retrieved', data);
  } catch (error) {
    next(error);
  }
};
