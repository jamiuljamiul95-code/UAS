import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { userService } from '../services/user.service';
import { sendOK, sendCreated, sendNoContent } from '../utils/response.util';
import { AppError } from '../utils/error.util';

// 1. Get List of Users / Customers (Admin/Owner only)
export const getUsers = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { users, meta } = await userService.getUsers(req.query);
    sendOK(res, 'Users retrieved successfully', users, meta);
  } catch (error) {
    next(error);
  }
};

// 2. Get Single User / Customer Detail (Admin/Owner only)
export const getUserById = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const user = await userService.getUserById(id);
    sendOK(res, 'User detail retrieved successfully', user);
  } catch (error) {
    next(error);
  }
};

// 3. Create a User (Admin/Owner only)
export const createUser = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const user = await userService.createUser(req.body);
    sendCreated(res, 'User created successfully', user);
  } catch (error) {
    next(error);
  }
};

// 4. Update a User (Admin/Owner only)
export const updateUser = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const user = await userService.updateUser(id, req.body);
    sendOK(res, 'User updated successfully', user);
  } catch (error) {
    next(error);
  }
};

// 5. Delete a User (Admin/Owner only, only if they have no order history)
export const deleteUser = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const requestingUserId = req.user?.id;
    if (!requestingUserId) {
      throw new AppError('Authentication context required', 401);
    }
    await userService.deleteUser(id, requestingUserId);
    sendOK(res, 'User deleted successfully');
  } catch (error) {
    next(error);
  }
};

// 6. Update User Status (Admin/Owner only)
export const updateUserStatus = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const user = await userService.updateUserStatus(id, status);
    sendOK(res, 'User status updated successfully', user);
  } catch (error) {
    next(error);
  }
};

// 7. Get Current Logged-In User Profile
export const getProfile = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }
    const profile = await userService.getUserById(userId);
    sendOK(res, 'Profile retrieved successfully', profile);
  } catch (error) {
    next(error);
  }
};

// 8. Update Current Logged-In User Profile
export const updateProfile = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }
    const profile = await userService.updateProfile(userId, req.body);
    sendOK(res, 'Profile updated successfully', profile);
  } catch (error) {
    next(error);
  }
};

// --- Address Controllers ---

// 9. Get Addresses of Logged-In User
export const getAddresses = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }
    const addresses = await userService.getAddresses(userId);
    sendOK(res, 'Addresses retrieved successfully', addresses);
  } catch (error) {
    next(error);
  }
};

// 10. Create Address for Logged-In User
export const createAddress = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }
    const address = await userService.createAddress(userId, req.body);
    sendCreated(res, 'Address created successfully', address);
  } catch (error) {
    next(error);
  }
};

// 11. Update Address of Logged-In User
export const updateAddress = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }
    const { addressId } = req.params;
    const address = await userService.updateAddress(userId, addressId, req.body);
    sendOK(res, 'Address updated successfully', address);
  } catch (error) {
    next(error);
  }
};

// 12. Delete Address of Logged-In User
export const deleteAddress = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }
    const { addressId } = req.params;
    await userService.deleteAddress(userId, addressId);
    sendNoContent(res);
  } catch (error) {
    next(error);
  }
};
