import { Request, Response, NextFunction } from 'express';
import { productService } from '../services/product.service';
import { sendCreated, sendOK } from '../utils/response.util';

export const getProducts = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { products, meta } = await productService.getProducts(req.query);
    sendOK(res, 'Products retrieved successfully', products, meta);
  } catch (error) {
    next(error);
  }
};

export const getProductById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
    let data;
    if (isUuid) {
      data = await productService.getProductById(id);
    } else {
      data = await productService.getProductBySlug(id);
    }
    sendOK(res, 'Product retrieved successfully', data);
  } catch (error) {
    next(error);
  }
};

export const getProductBySlug = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { slug } = req.params;
    const data = await productService.getProductBySlug(slug);
    sendOK(res, 'Product retrieved successfully', data);
  } catch (error) {
    next(error);
  }
};

export const createProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const data = await productService.createProduct(req.body);
    sendCreated(res, 'Product created successfully', data);
  } catch (error) {
    next(error);
  }
};

export const updateProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    const data = await productService.updateProduct(id, req.body);
    sendOK(res, 'Product updated successfully', data);
  } catch (error) {
    next(error);
  }
};

export const deleteProduct = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { id } = req.params;
    await productService.deleteProduct(id);
    sendOK(res, 'Product deleted successfully');
  } catch (error) {
    next(error);
  }
};

