import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { cartService } from '../services/cart.service';
import { sendOK } from '../utils/response.util';
import { AppError } from '../utils/error.util';

/**
 * Retrieves the current user's shopping cart and summary.
 */
export const getCart = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) {
      throw new AppError('Unauthorized access: Missing user identifier', 401);
    }
    const cart = await cartService.getCart(req.user.id);
    sendOK(res, 'Shopping cart retrieved successfully', cart);
  } catch (error) {
    next(error);
  }
};

/**
 * Adds a new item to the user's cart or increments the quantity if it exists.
 */
export const addToCart = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) {
      throw new AppError('Unauthorized access: Missing user identifier', 401);
    }
    const cart = await cartService.addToCart(req.user.id, req.body);
    sendOK(res, 'Item successfully added to shopping cart', cart);
  } catch (error) {
    next(error);
  }
};

/**
 * Updates the quantity of a specific item in the cart.
 */
export const updateCartItem = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) {
      throw new AppError('Unauthorized access: Missing user identifier', 401);
    }
    const { id } = req.params;
    const cart = await cartService.updateCartItemQuantity(req.user.id, id, req.body);
    sendOK(res, 'Cart item quantity updated successfully', cart);
  } catch (error) {
    next(error);
  }
};

/**
 * Deletes a specific item from the cart.
 */
export const deleteCartItem = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) {
      throw new AppError('Unauthorized access: Missing user identifier', 401);
    }
    const { id } = req.params;
    const cart = await cartService.deleteCartItem(req.user.id, id);
    sendOK(res, 'Item removed from shopping cart successfully', cart);
  } catch (error) {
    next(error);
  }
};

/**
 * Clears all items in the user's shopping cart.
 */
export const clearCart = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) {
      throw new AppError('Unauthorized access: Missing user identifier', 401);
    }
    const cart = await cartService.clearCart(req.user.id);
    sendOK(res, 'Shopping cart cleared successfully', cart);
  } catch (error) {
    next(error);
  }
};

/**
 * Patches selection states of items in the cart (individual, bulk, or select all).
 */
export const selectCartItems = async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
  try {
    if (!req.user?.id) {
      throw new AppError('Unauthorized access: Missing user identifier', 401);
    }
    const cart = await cartService.selectCartItems(req.user.id, req.body);
    sendOK(res, 'Cart items selection status updated successfully', cart);
  } catch (error) {
    next(error);
  }
};
