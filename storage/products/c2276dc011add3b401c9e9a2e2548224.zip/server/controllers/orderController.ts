import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { orderService } from '../services/order.service';
import { sendOK, sendCreated } from '../utils/response.util';
import { AppError } from '../utils/error.util';

export const getOrders = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;

    if (!userId || !role) {
      throw new AppError('Authentication required', 401);
    }

    const { orders, pagination } = await orderService.getOrders(userId, role, req.query);
    sendOK(res, 'Orders retrieved successfully', orders, pagination);
  } catch (error) {
    next(error);
  }
};

export const getOrderById = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;
    const { id } = req.params;

    if (!userId || !role) {
      throw new AppError('Authentication required', 401);
    }

    const order = await orderService.getOrderById(id, userId, role);
    sendOK(res, 'Order details retrieved successfully', order);
  } catch (error) {
    next(error);
  }
};

export const updateOrderStatus = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const role = req.user?.role;
    const { id } = req.params;
    const { status, note } = req.body;

    // Security RBAC: Only OWNER, ADMIN, or STAFF can update order status
    if (role !== 'OWNER' && role !== 'ADMIN' && role !== 'STAFF') {
      throw new AppError('Forbidden: Only administrative users can update order status', 403);
    }

    const order = await orderService.updateOrderStatus(id, status, note);
    sendOK(res, `Order status successfully updated to ${status}`, order);
  } catch (error) {
    next(error);
  }
};

export const cancelOrder = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;
    const { id } = req.params;
    const { note } = req.body;

    if (!userId || !role) {
      throw new AppError('Authentication required', 401);
    }

    // If customer, we restrict cancellation within service. If admin/staff/owner, no user-specific ownership restriction.
    const restrictToUserId = role === 'CUSTOMER' ? userId : undefined;

    const order = await orderService.cancelOrder(id, restrictToUserId, note || 'Order cancelled.');
    sendOK(res, 'Order cancelled successfully', order);
  } catch (error) {
    next(error);
  }
};

export const getCustomerOrders = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      throw new AppError('Authentication required', 401);
    }

    // Force CUSTOMER role for this specific customer history query
    const { orders, pagination } = await orderService.getOrders(userId, 'CUSTOMER', req.query);
    sendOK(res, 'Customer orders retrieved successfully', orders, pagination);
  } catch (error) {
    next(error);
  }
};

export const createOrder = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;

    if (!userId || !role) {
      throw new AppError('Authentication required', 401);
    }

    const order = await orderService.createOrder(userId, role, req.body);
    sendCreated(res, 'Order created successfully', order);
  } catch (error) {
    next(error);
  }
};

