import { Request, Response } from 'express';
import { prisma } from '../config/db';
import { logger } from '../config/logger';

export const getCategories = async (req: Request, res: Response): Promise<void> => {
  try {
    const categories = await prisma.category.findMany({
      orderBy: { name: 'asc' },
    });
    res.status(200).json({ success: true, data: categories });
  } catch (error) {
    logger.error({ error }, 'Get categories error');
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const createCategory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { name, slug } = req.body;
    
    const existing = await prisma.category.findUnique({ where: { slug } });
    if (existing) {
      res.status(400).json({ success: false, message: 'Category slug already exists' });
      return;
    }

    const category = await prisma.category.create({
      data: { name, slug }
    });

    res.status(201).json({ success: true, data: category, message: 'Category created successfully' });
  } catch (error) {
    logger.error({ error }, 'Create category error');
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const updateCategory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { name, slug } = req.body;

    const existingCategory = await prisma.category.findUnique({ where: { id } });
    if (!existingCategory) {
      res.status(404).json({ success: false, message: 'Category not found' });
      return;
    }

    if (slug) {
      const slugConflict = await prisma.category.findFirst({
        where: {
          slug,
          id: { not: id },
        },
      });
      if (slugConflict) {
        res.status(400).json({ success: false, message: 'Category slug already exists' });
        return;
      }
    }

    const updatedCategory = await prisma.category.update({
      where: { id },
      data: { name, slug },
    });

    res.status(200).json({ success: true, data: updatedCategory, message: 'Category updated successfully' });
  } catch (error) {
    logger.error({ error }, 'Update category error');
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const deleteCategory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const existingCategory = await prisma.category.findUnique({ where: { id } });
    if (!existingCategory) {
      res.status(404).json({ success: false, message: 'Category not found' });
      return;
    }

    // Check if any products are associated with this category
    const associatedProducts = await prisma.product.count({
      where: { categoryId: id },
    });

    if (associatedProducts > 0) {
      res.status(400).json({
        success: false,
        message: `Cannot delete category: it is currently assigned to ${associatedProducts} product(s).`,
      });
      return;
    }

    await prisma.category.delete({ where: { id } });

    res.status(200).json({ success: true, message: 'Category deleted successfully' });
  } catch (error) {
    logger.error({ error }, 'Delete category error');
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
};
