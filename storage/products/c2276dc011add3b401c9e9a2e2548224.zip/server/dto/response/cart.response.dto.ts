export interface CartItemResponseDto {
  id: string;
  productId: string;
  name: string;
  slug: string;
  categoryName: string;
  imageUrl: string;
  variantId: string | null;
  variantName: string | null;
  sku: string;
  originalPrice: number;
  discountPrice: number | null;
  price: number; // Final unit price (discountPrice if available, otherwise originalPrice)
  quantity: number;
  subtotal: number; // price * quantity
  originalSubtotal: number; // originalPrice * quantity
  savings: number; // originalSubtotal - subtotal
  selected: boolean;
  availableStock: number;
  hasEnoughStock: boolean;
  isActive: boolean;
}

export interface CartSummaryResponseDto {
  totalItemsCount: number; // Sum of quantities of all items
  totalUniqueItems: number; // Unique items in cart
  selectedItemsCount: number; // Sum of quantities of selected items
  selectedUniqueItems: number; // Unique selected items
  originalSubtotal: number; // Sum of original price * quantity of selected items
  subtotal: number; // Sum of final price * quantity of selected items
  totalDiscount: number; // Savings of selected items (originalSubtotal - subtotal)
  totalPayment: number; // Subtotal (the actual payment required for selected items)
}

export interface CartResponseDto {
  id: string;
  userId: string;
  items: CartItemResponseDto[];
  summary: CartSummaryResponseDto;
}
