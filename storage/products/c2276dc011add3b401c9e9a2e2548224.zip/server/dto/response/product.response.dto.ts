export interface ProductResponseDto {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  discountPrice: number | null;
  weight: number | null;
  status: string;
  stock: number;
  sku: string;
  categoryId: string;
  category?: {
    id: string;
    name: string;
    slug: string;
  };
  images?: {
    id: string;
    url: string;
    isMain: boolean;
  }[];
  variants?: {
    id: string;
    color: string | null;
    size: string | null;
    stock: number;
    sku: string | null;
  }[];
  createdAt: Date;
  updatedAt: Date;
}

export interface ProductListResponseDto {
  products: ProductResponseDto[];
}
