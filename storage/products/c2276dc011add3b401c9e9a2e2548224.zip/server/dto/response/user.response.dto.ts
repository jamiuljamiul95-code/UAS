export interface AddressResponseDto {
  id: string;
  userId: string;
  title: string;
  recipientName: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  postalCode: string;
  address: string;
  notes: string | null;
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserResponseDto {
  id: string;
  name: string;
  email: string;
  role: string;
  phone: string | null;
  status: string;
  avatar: string | null;
  dob: string | null;
  gender: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserDetailResponseDto extends UserResponseDto {
  addresses: AddressResponseDto[];
  orderCount: number;
  totalSpent: number;
}
