export interface OrderItemResponseDto {
  id: string;
  productId: string;
  productName: string;
  variantId: string | null;
  variantColor: string | null;
  variantSize: string | null;
  quantity: number;
  price: number;
}

export interface OrderResponseDto {
  id: string;
  userId: string;
  user: {
    id: string;
    name: string;
  };
  status: string;
  totalAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  shippingAddress: string | null;
  trackingResi: string | null;
  orderType: string;
  subtotal: number;
  discountAmount: number;
  shippingFee: number;
  shippingCarrier: string | null;
  taxAmount: number;
  voucherId: string | null;
  voucher?: {
    id: string;
    code: string;
    type: string;
    value: number;
  } | null;
  items: OrderItemResponseDto[];
  createdAt: Date;
  updatedAt: Date;
}
