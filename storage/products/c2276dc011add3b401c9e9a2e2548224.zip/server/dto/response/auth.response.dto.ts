export interface UserResponseDto {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface LoginResponseDto {
  token: string;
  user: UserResponseDto;
}
