import { z } from 'zod';
import { createUserSchema, updateUserSchema, updateProfileSchema, addressSchema } from '../../validators/user.validator';

export type CreateUserRequestDto = z.infer<typeof createUserSchema>;
export type UpdateUserRequestDto = z.infer<typeof updateUserSchema>;
export type UpdateProfileRequestDto = z.infer<typeof updateProfileSchema>;
export type AddressRequestDto = z.infer<typeof addressSchema>;

export interface SearchUserRequestDto {
  page?: string;
  limit?: string;
  search?: string;
  role?: string;
  status?: string;
  startDate?: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}
