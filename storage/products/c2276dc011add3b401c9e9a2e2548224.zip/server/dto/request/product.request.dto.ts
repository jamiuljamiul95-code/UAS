import { z } from 'zod';
import { createProductSchema, updateProductSchema } from '../../validators/product.validator';

export type CreateProductRequestDto = z.infer<typeof createProductSchema>;
export type UpdateProductRequestDto = z.infer<typeof updateProductSchema>;

export interface SearchProductRequestDto {
  page?: string;
  limit?: string;
  search?: string;
  categoryId?: string;
  status?: string;
  stock?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}
