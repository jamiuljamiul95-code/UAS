import { z } from 'zod';
import { createOrderSchema } from '../../validators/order.validator';

export type CreateOrderRequestDto = z.infer<typeof createOrderSchema>;

export interface SearchOrderRequestDto {
  page?: string;
  limit?: string;
  status?: string;
  search?: string;
  startDate?: string;
  endDate?: string;
  customerFilter?: string;
}
