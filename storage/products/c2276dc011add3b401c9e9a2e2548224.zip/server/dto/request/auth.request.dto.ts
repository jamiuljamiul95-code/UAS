import { z } from 'zod';
import { registerSchema, loginSchema } from '../../validators/auth.validator';

export type RegisterRequestDto = z.infer<typeof registerSchema>;
export type LoginRequestDto = z.infer<typeof loginSchema>;
