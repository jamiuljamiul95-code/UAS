import { z } from 'zod';
import { addToCartSchema, updateCartItemSchema, selectCartItemsSchema } from '../../validators/cart.validator';

export type AddToCartRequestDto = z.infer<typeof addToCartSchema>;
export type UpdateCartItemRequestDto = z.infer<typeof updateCartItemSchema>;
export type SelectCartItemsRequestDto = z.infer<typeof selectCartItemsSchema>;
