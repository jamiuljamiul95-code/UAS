import { Response } from 'express';

interface SuccessResponse<T> {
  success: true;
  message: string;
  data?: T;
  meta?: unknown;
}

export const sendSuccess = <T>(
  res: Response,
  statusCode: number,
  message: string,
  data?: T,
  meta?: unknown
): void => {
  const response: SuccessResponse<T> = {
    success: true,
    message,
  };

  if (data !== undefined) {
    response.data = data;
  }
  
  if (meta !== undefined) {
    response.meta = meta;
  }

  res.status(statusCode).json(response);
};

export const sendCreated = <T>(res: Response, message: string, data?: T): void => {
  sendSuccess(res, 201, message, data);
};

export const sendOK = <T>(res: Response, message: string, data?: T, meta?: unknown): void => {
  sendSuccess(res, 200, message, data, meta);
};

export const sendNoContent = (res: Response): void => {
  res.status(204).send();
};
