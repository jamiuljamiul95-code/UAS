import { Payment, Order, User } from '@prisma/client';

export interface FindPaymentsParams {
  userId?: string;
  role?: string;
  status?: string;
  method?: string;
  search?: string; // paymentId, orderId, customer name
  startDate?: string;
  endDate?: string;
  skip: number;
  take: number;
}

export type PaymentWithDetails = Payment & {
  order: Order;
  user: {
    id: string;
    name: string;
    email: string;
    phone: string | null;
  };
};

export interface IPaymentRepository {
  findPayments(params: FindPaymentsParams): Promise<{ payments: any[]; total: number }>;
  findPaymentById(id: string): Promise<any | null>;
  createPayment(data: {
    orderId: string;
    userId: string;
    amount: number;
    paymentMethod: string;
    status: string;
    proofOfPayment?: string;
    note?: string;
  }): Promise<any>;
  updatePaymentStatus(id: string, status: string, note?: string): Promise<any>;
}
