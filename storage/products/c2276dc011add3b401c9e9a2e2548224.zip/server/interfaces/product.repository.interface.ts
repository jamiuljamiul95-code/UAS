import { Prisma, Product, ProductImage, ProductVariant, Category } from '@prisma/client';

export type ProductWithDetails = Product & {
  category: Category;
  images: ProductImage[];
  variants: ProductVariant[];
};

export interface IProductRepository {
  findById(id: string): Promise<ProductWithDetails | null>;
  findBySlug(slug: string): Promise<ProductWithDetails | null>;
  findBySku(sku: string): Promise<Product | null>;
  create(data: Prisma.ProductCreateInput): Promise<ProductWithDetails>;
  update(id: string, data: Prisma.ProductUpdateInput): Promise<ProductWithDetails>;
  delete(id: string): Promise<Product>;
  findMany(args?: Prisma.ProductFindManyArgs): Promise<ProductWithDetails[]>;
  count(args?: Prisma.ProductCountArgs): Promise<number>;
  exists(id: string): Promise<boolean>;
  hasOrderItems(id: string): Promise<boolean>;
}
