import { Order, OrderItem, OrderTimeline } from '@prisma/client';

export interface FindOrdersParams {
  userId?: string;
  role?: string;
  status?: string;
  search?: string; // orderId, customer name, email
  startDate?: string;
  endDate?: string;
  customerFilter?: string; // specific customer ID/name/email filter
  skip: number;
  take: number;
}

export interface IOrderRepository {
  findOrders(params: FindOrdersParams): Promise<{ orders: any[]; total: number }>;
  findOrderById(id: string): Promise<any | null>;
  updateOrderStatus(id: string, status: string, note?: string): Promise<any>;
  cancelOrder(id: string, userId?: string, note?: string): Promise<any>;
  createOrder(data: {
    userId: string;
    status: string;
    totalAmount: number;
    paymentMethod: string;
    paymentStatus: string;
    orderType: string;
    subtotal: number;
    discountAmount: number;
    shippingFee: number;
    shippingCarrier?: string | null;
    shippingAddress?: string | null;
    taxAmount: number;
    voucherId?: string | null;
    items: {
      productId: string;
      variantId?: string | null;
      quantity: number;
      price: number;
    }[];
  }): Promise<any>;
}
