import { Voucher, Order, OrderItem, Address } from '@prisma/client';

export interface ICheckoutRepository {
  findVoucherByCode(code: string): Promise<Voucher | null>;
  findActiveVouchers(): Promise<Voucher[]>;
  getUserVoucherUsageCount(userId: string, voucherId: string): Promise<number>;
  createOrderTransaction(data: {
    userId: string;
    address: Address;
    shippingCarrier: string;
    shippingFee: number;
    voucherCode?: string;
    subtotal: number;
    discountAmount: number;
    taxAmount: number;
    totalAmount: number;
    paymentMethod: string;
    orderType: string;
    items: Array<{
      productId: string;
      variantId: string | null;
      quantity: number;
      price: number;
    }>;
    cartItemIdsToDelete: string[];
  }): Promise<Order & { items: OrderItem[] }>;
}
