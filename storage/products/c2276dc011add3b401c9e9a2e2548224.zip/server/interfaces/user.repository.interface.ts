import { Prisma, User } from '@prisma/client';

export interface IUserRepository {
  findById(id: string): Promise<Partial<User> | null>;
  findByEmail(email: string): Promise<User | null>;
  create(data: Prisma.UserCreateInput): Promise<User>;
  update(id: string, data: Prisma.UserUpdateInput): Promise<User>;
  delete(id: string): Promise<User>;
  count(): Promise<number>;
  findMany(args?: Prisma.UserFindManyArgs): Promise<Partial<User>[]>;
  exists(email: string): Promise<boolean>;
}
