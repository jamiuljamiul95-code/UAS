import { Cart, CartItem, Product, ProductImage, ProductVariant, Category } from '@prisma/client';

export type CartItemWithDetails = CartItem & {
  product: Product & {
    category: Category;
    images: ProductImage[];
    variants: ProductVariant[];
  };
  variant: ProductVariant | null;
};

export type CartWithDetails = Cart & {
  items: CartItemWithDetails[];
};

export interface ICartRepository {
  findCartByUserId(userId: string): Promise<CartWithDetails | null>;
  createCart(userId: string): Promise<CartWithDetails>;
  findCartItemById(id: string): Promise<CartItemWithDetails | null>;
  findCartItem(cartId: string, productId: string, variantId: string | null): Promise<CartItemWithDetails | null>;
  addCartItem(cartId: string, productId: string, variantId: string | null, quantity: number): Promise<CartItemWithDetails>;
  updateCartItemQuantity(id: string, quantity: number): Promise<CartItemWithDetails>;
  deleteCartItem(id: string): Promise<CartItem>;
  clearCart(cartId: string): Promise<void>;
  updateCartItemSelection(id: string, selected: boolean): Promise<CartItemWithDetails>;
  updateCartItemsSelectionBulk(cartId: string, itemIds: string[], selected: boolean): Promise<void>;
  updateAllCartItemsSelection(cartId: string, selected: boolean): Promise<void>;
}
