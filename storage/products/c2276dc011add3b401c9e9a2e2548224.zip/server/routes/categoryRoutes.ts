import { Router } from 'express';
import { getCategories, createCategory, updateCategory, deleteCategory } from '../controllers/categoryController';
import { authenticate } from '../middlewares/auth.middleware';
import { authorizeRoles } from '../middlewares/role.middleware';
import { validate } from '../middlewares/validate.middleware';
import { createCategorySchema, updateCategorySchema } from '../validators/category.validator';

const router = Router();

router.get('/', getCategories);
router.post(
  '/',
  authenticate,
  authorizeRoles('OWNER', 'ADMIN', 'STAFF'),
  validate(createCategorySchema),
  createCategory
);
router.put(
  '/:id',
  authenticate,
  authorizeRoles('OWNER', 'ADMIN', 'STAFF'),
  validate(updateCategorySchema),
  updateCategory
);
router.delete(
  '/:id',
  authenticate,
  authorizeRoles('OWNER', 'ADMIN', 'STAFF'),
  deleteCategory
);

export default router;
