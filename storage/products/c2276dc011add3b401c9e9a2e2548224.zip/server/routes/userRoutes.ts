import { Router } from 'express';
import { getUsers, getUserById, createUser, updateUser, deleteUser, updateUserStatus } from '../controllers/userController';
import { authenticate } from '../middlewares/auth.middleware';
import { authorizeRoles } from '../middlewares/role.middleware';
import { validate } from '../middlewares/validate.middleware';
import { createUserSchema, updateUserSchema } from '../validators/user.validator';

const router = Router();

// All routes here are restricted to OWNER and ADMIN roles
router.use(authenticate);
router.use(authorizeRoles('OWNER', 'ADMIN'));

router.get('/', getUsers);
router.post('/', validate(createUserSchema), createUser);
router.get('/:id', getUserById);
router.put('/:id', validate(updateUserSchema), updateUser);
router.patch('/:id/status', updateUserStatus);
router.delete('/:id', deleteUser);

export default router;
