import { Router } from 'express';
import { authenticate } from '../middlewares/auth.middleware';
import { validate } from '../middlewares/validate.middleware';
import {
  getShippingMethods,
  getVouchers,
  previewCheckout,
  executeCheckout,
} from '../controllers/checkoutController';
import {
  checkoutPreviewSchema,
  checkoutExecuteSchema,
} from '../validators/checkout.validator';

const router = Router();

// Apply auth middleware to all checkout routes
router.use(authenticate);

// Main Checkout APIs
router.get('/', previewCheckout); // GET /api/checkout (runs default preview)
router.post('/', validate(checkoutExecuteSchema), executeCheckout); // POST /api/checkout (submits checkout order)
router.post('/preview', validate(checkoutPreviewSchema), previewCheckout); // POST /api/checkout/preview (custom preview calculations)

// Extra lookup endpoints
router.get('/shipping', getShippingMethods); // GET /api/checkout/shipping (or mapped globally)
router.get('/vouchers', getVouchers); // GET /api/checkout/vouchers (or mapped globally)

export default router;
