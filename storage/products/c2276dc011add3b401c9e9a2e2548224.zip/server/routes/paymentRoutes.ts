import { Router } from 'express';
import { 
  getPayments, 
  getPaymentById, 
  createPayment, 
  uploadProofOfPayment, 
  approvePayment, 
  rejectPayment 
} from '../controllers/paymentController';
import { authenticate } from '../middlewares/auth.middleware';
import { uploadProofMiddleware } from '../middlewares/upload.middleware';

const router = Router();

// Secure all payment endpoints
router.use(authenticate);

// List and create payments
router.get('/', getPayments);
router.get('/:id', getPaymentById);
router.post('/', createPayment);

// Proof of payment upload
router.post('/upload', uploadProofMiddleware.single('file'), uploadProofOfPayment);

// Verification routes
router.patch('/:id/approve', approvePayment);
router.patch('/:id/reject', rejectPayment);

export default router;
