import { Router } from 'express';
import { getProfile, updateProfile, getAddresses, createAddress, updateAddress, deleteAddress } from '../controllers/userController';
import { authenticate } from '../middlewares/auth.middleware';
import { validate } from '../middlewares/validate.middleware';
import { updateProfileSchema, addressSchema } from '../validators/user.validator';

const router = Router();

router.use(authenticate);

router.get('/', getProfile);
router.put('/', validate(updateProfileSchema), updateProfile);

// Address Management inside profile
router.get('/addresses', getAddresses);
router.post('/addresses', validate(addressSchema), createAddress);
router.put('/addresses/:addressId', validate(addressSchema), updateAddress);
router.delete('/addresses/:addressId', deleteAddress);

export default router;
