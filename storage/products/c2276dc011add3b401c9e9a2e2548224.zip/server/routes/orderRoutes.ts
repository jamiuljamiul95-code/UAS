import { Router } from 'express';
import { authenticate } from '../middlewares/auth.middleware';
import { authorizeRoles } from '../middlewares/role.middleware';
import { validate } from '../middlewares/validate.middleware';
import {
  getOrders,
  getCustomerOrders,
  getOrderById,
  updateOrderStatus,
  cancelOrder,
  createOrder,
} from '../controllers/orderController';
import {
  createOrderSchema,
  updateOrderStatusSchema,
  cancelOrderSchema,
} from '../validators/order.validator';

const router = Router();

// Apply auth middleware globally to all order routes
router.use(authenticate);

// 1. Get List of Orders
// GET /api/orders (Returns orders. Customers get their own, admin gets all. Supports page, limit, status, search, date filters)
router.get('/', getOrders);

// 2. Create Order (Accessible to CUSTOMER for checkout, and administrative roles for POS)
// POST /api/orders
router.post('/', validate(createOrderSchema), createOrder);

// 2. Get Customer specific history explicitly
// GET /api/orders/customer (Retrieves only the authenticated customer's orders)
router.get('/customer', getCustomerOrders);

// 3. Get Single Order Detail
// GET /api/orders/:id (Retrieves detailed view of order. Subject to ownership check for customers)
router.get('/:id', getOrderById);

// 4. Update Order Status
// PATCH /api/orders/:id/status (Admin/Staff only. Changes status and registers timeline log)
router.patch(
  '/:id/status',
  authorizeRoles('OWNER', 'ADMIN', 'STAFF'),
  validate(updateOrderStatusSchema),
  updateOrderStatus
);

// 5. Cancel Order
// PATCH /api/orders/:id/cancel (User can cancel if un-processed. Admin can cancel any time. Restores stocks)
router.patch(
  '/:id/cancel',
  validate(cancelOrderSchema),
  cancelOrder
);

export default router;
