import { Router } from 'express';
import { getCart, addToCart, updateCartItem, deleteCartItem, clearCart, selectCartItems } from '../controllers/cartController';
import { authenticate } from '../middlewares/auth.middleware';
import { validate } from '../middlewares/validate.middleware';
import { addToCartSchema, updateCartItemSchema, selectCartItemsSchema } from '../validators/cart.validator';

const router = Router();

// All shopping cart operations require authentication
router.use(authenticate);

router.get('/', getCart);
router.post('/', validate(addToCartSchema), addToCart);
router.put('/:id', validate(updateCartItemSchema), updateCartItem);
router.delete('/:id', deleteCartItem);
router.delete('/', clearCart);
router.patch('/select', validate(selectCartItemsSchema), selectCartItems);

export default router;
