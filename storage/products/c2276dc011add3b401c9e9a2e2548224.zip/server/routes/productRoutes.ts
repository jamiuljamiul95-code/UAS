import { Router } from 'express';
import { getProducts, getProductById, getProductBySlug, createProduct, updateProduct, deleteProduct } from '../controllers/productController';
import { authenticate } from '../middlewares/auth.middleware';
import { authorizeRoles } from '../middlewares/role.middleware';
import { validate } from '../middlewares/validate.middleware';
import { createProductSchema, updateProductSchema } from '../validators/product.validator';

const router = Router();

router.get('/', getProducts);
router.post('/', authenticate, authorizeRoles('OWNER', 'ADMIN', 'STAFF'), validate(createProductSchema), createProduct);
router.get('/slug/:slug', getProductBySlug);
router.get('/:id', getProductById);
router.put('/:id', authenticate, authorizeRoles('OWNER', 'ADMIN', 'STAFF'), validate(updateProductSchema), updateProduct);
router.delete('/:id', authenticate, authorizeRoles('OWNER', 'ADMIN', 'STAFF'), deleteProduct);

export default router;
