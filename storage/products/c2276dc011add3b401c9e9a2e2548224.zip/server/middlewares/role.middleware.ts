import { Response, NextFunction } from 'express';
import { AuthRequest } from '../interfaces/auth.interface';
import { AppError } from '../utils/error.util';

export const authorizeRoles = (...allowedRoles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return next(new AppError('Access denied: insufficient permissions', 403));
    }
    next();
  };
};
