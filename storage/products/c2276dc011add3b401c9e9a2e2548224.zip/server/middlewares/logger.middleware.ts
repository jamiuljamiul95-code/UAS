import { Response, NextFunction } from 'express';
import { logger } from '../config/logger';
import { env } from '../config/env';
import { ExtendedRequest } from './correlation.middleware';

export const requestLogger = (req: ExtendedRequest, res: Response, next: NextFunction): void => {
  if (!env.ENABLE_REQUEST_LOGGING) {
    return next();
  }

  const start = Date.now();
  const { method, originalUrl, ip } = req;
  const userAgent = req.get('user-agent') || 'unknown';
  const requestId = req.id;

  res.on('finish', () => {
    const duration = Date.now() - start;
    const statusCode = res.statusCode;

    const logData = {
      requestId,
      method,
      url: originalUrl,
      status: statusCode,
      duration: `${duration}ms`,
      ip,
      userAgent,
    };

    const message = `[${requestId}] ${method} ${originalUrl} ${statusCode} - ${duration}ms`;


    if (statusCode >= 500) {
      logger.error(logData, message);
    } else if (statusCode >= 400) {
      logger.warn(logData, message);
    } else {
      logger.info(logData, message);
    }
  });

  next();
};
