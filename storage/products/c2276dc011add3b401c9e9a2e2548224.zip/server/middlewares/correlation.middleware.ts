import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';

export interface ExtendedRequest extends Request {
  id?: string;
}

export const correlationIdMiddleware = (req: ExtendedRequest, res: Response, next: NextFunction): void => {
  const correlationHeader = req.get('X-Request-ID') || req.get('X-Correlation-ID');
  const requestId = correlationHeader || crypto.randomUUID();

  // Attach request ID to the request object
  req.id = requestId;

  // Set response header so client can trace this request
  res.setHeader('X-Request-ID', requestId);

  next();
};
