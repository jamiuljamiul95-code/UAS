import { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/error.util';
import { ZodError } from 'zod';
import { Prisma } from '@prisma/client';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { logger } from '../config/logger';

export const errorHandler = (
  err: Error | AppError,
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  let statusCode = 500;
  let message = 'Internal server error';
  let errors: unknown[] = [];


  if (err instanceof AppError) {
    statusCode = err.statusCode;
    message = err.message;
    errors = err.errors || [];
  } else if (err instanceof ZodError) {
    statusCode = 400;
    message = 'Validation failed';
    errors = err.issues.map((e) => ({ field: e.path.join('.'), message: e.message }));
  } else if (err instanceof Prisma.PrismaClientKnownRequestError) {
    statusCode = 400;
    message = 'Database request error';
    if (err.code === 'P2002') {
      statusCode = 409;
      message = 'Unique constraint failed';
    }
  } else if (err instanceof jwt.TokenExpiredError) {
    statusCode = 401;
    message = 'Token expired';
  } else if (err instanceof jwt.JsonWebTokenError) {
    statusCode = 401;
    message = 'Invalid token';
  } else {
    // Log unexpected errors
    logger.error({ err }, 'Unhandled Error');
  }

  const response: Record<string, unknown> = {
    success: false,
    message,
  };

  if (errors.length > 0) {
    response.errors = errors;
  }
  
  if (env.NODE_ENV !== 'production' && !(err instanceof AppError)) {
    response.stack = (err as Error).stack;
  }


  res.status(statusCode).json(response);
};
