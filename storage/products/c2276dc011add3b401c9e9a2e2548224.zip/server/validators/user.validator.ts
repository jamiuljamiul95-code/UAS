import { z } from 'zod';

export const createUserSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  phone: z.string().min(8, 'Phone number must be at least 8 digits').nullable().optional(),
  role: z.enum(['OWNER', 'ADMIN', 'STAFF', 'CASHIER', 'CUSTOMER']).default('CUSTOMER'),
  status: z.enum(['ACTIVE', 'INACTIVE']).default('ACTIVE'),
  avatar: z.string().url('Invalid avatar URL').or(z.string().regex(/^data:image\//)).nullable().optional(),
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date of birth must be in YYYY-MM-DD format').nullable().optional(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']).nullable().optional(),
});

export const updateUserSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters').optional(),
  email: z.string().email('Invalid email address').optional(),
  password: z.string().min(6, 'Password must be at least 6 characters').optional(),
  phone: z.string().min(8, 'Phone number must be at least 8 digits').nullable().optional(),
  role: z.enum(['OWNER', 'ADMIN', 'STAFF', 'CASHIER', 'CUSTOMER']).optional(),
  status: z.enum(['ACTIVE', 'INACTIVE']).optional(),
  avatar: z.string().url('Invalid avatar URL').or(z.string().regex(/^data:image\//)).or(z.string().min(1)).nullable().optional(),
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date of birth must be in YYYY-MM-DD format').or(z.string().length(0)).nullable().optional(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']).or(z.string().length(0)).nullable().optional(),
});

export const updateProfileSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters').optional(),
  email: z.string().email('Invalid email address').optional(),
  phone: z.string().min(8, 'Phone number must be at least 8 digits').nullable().optional(),
  avatar: z.string().nullable().optional(),
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date of birth must be in YYYY-MM-DD format').or(z.string().length(0)).nullable().optional(),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']).or(z.string().length(0)).nullable().optional(),
  password: z.string().min(6, 'Password must be at least 6 characters').optional(),
});

export const addressSchema = z.object({
  title: z.string().min(2, 'Title must be at least 2 characters').default('Alamat'),
  recipientName: z.string().min(2, 'Recipient name must be at least 2 characters'),
  phone: z.string().min(8, 'Phone number must be at least 8 digits'),
  province: z.string().min(2, 'Province must be at least 2 characters'),
  city: z.string().min(2, 'City must be at least 2 characters'),
  district: z.string().min(2, 'District must be at least 2 characters'),
  postalCode: z.string().min(3, 'Postal code must be at least 3 characters'),
  address: z.string().min(5, 'Full address must be at least 5 characters'),
  notes: z.string().nullable().optional(),
  isDefault: z.boolean().default(false),
});
