import { z } from 'zod';

export const createOrderSchema = z.object({
  items: z.array(z.object({
    productId: z.string().uuid('Product ID must be a valid UUID'),
    variantId: z.string().uuid('Variant ID must be a valid UUID').nullable().optional(),
    quantity: z.number().int().min(1, 'Quantity must be at least 1'),
    price: z.number().min(0, 'Price must be a positive number'),
  })).min(1, 'Order must contain at least one item'),
  totalAmount: z.number().min(0, 'Total amount must be a positive number'),
  paymentMethod: z.enum(['CASH', 'QRIS', 'TRANSFER', 'COD'], {
    message: 'Payment method must be CASH, QRIS, TRANSFER, or COD',
  }),
  orderType: z.enum(['ONLINE', 'POS']).default('ONLINE'),
  shippingAddress: z.string().optional(),
  shippingCarrier: z.string().optional(),
  shippingFee: z.number().optional(),
  discountAmount: z.number().optional(),
  voucherCode: z.string().optional(),
});

export const updateOrderStatusSchema = z.object({
  status: z.enum([
    'PENDING',
    'WAITING_PAYMENT',
    'PAID',
    'PROCESSING',
    'PACKING',
    'SHIPPED',
    'DELIVERED',
    'COMPLETED',
    'CANCELLED',
    'REFUND'
  ], {
    message: 'Status must be one of: PENDING, WAITING_PAYMENT, PAID, PROCESSING, PACKING, SHIPPED, DELIVERED, COMPLETED, CANCELLED, REFUND',
  }),
  note: z.string().trim().optional(),
});

export const cancelOrderSchema = z.object({
  note: z.string().trim().optional(),
});
