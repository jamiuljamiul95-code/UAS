import { z } from 'zod';

export const createPaymentSchema = z.object({
  orderId: z.string().uuid({ message: 'Invalid Order ID format' }),
  amount: z.number().positive({ message: 'Amount must be greater than 0' }),
  paymentMethod: z.enum(['BANK_TRANSFER', 'TRANSFER', 'QRIS', 'E-WALLET', 'EWALLET', 'CASH', 'COD']),
  proofOfPayment: z.string().trim().optional(),
  note: z.string().trim().optional(),
});

export const verifyPaymentSchema = z.object({
  note: z.string().trim().optional(),
});
