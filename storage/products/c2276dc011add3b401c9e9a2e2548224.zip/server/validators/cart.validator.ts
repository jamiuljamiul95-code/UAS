import { z } from 'zod';

export const addToCartSchema = z.object({
  productId: z.string().uuid({ message: 'Product ID must be a valid UUID' }),
  variantId: z.string().uuid({ message: 'Variant ID must be a valid UUID' }).nullable().optional(),
  quantity: z.number().int({ message: 'Quantity must be an integer' }).positive({ message: 'Quantity must be at least 1' }),
});

export const updateCartItemSchema = z.object({
  quantity: z.number().int({ message: 'Quantity must be an integer' }).positive({ message: 'Quantity must be at least 1' }),
});

export const selectCartItemsSchema = z.object({
  id: z.string().uuid({ message: 'Item ID must be a valid UUID' }).optional(),
  ids: z.array(z.string().uuid({ message: 'Each item ID must be a valid UUID' })).optional(),
  selected: z.boolean(),
  all: z.boolean().optional(),
});
