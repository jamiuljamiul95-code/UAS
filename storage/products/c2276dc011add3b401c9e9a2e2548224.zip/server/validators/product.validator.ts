import { z } from 'zod';

export const createProductSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  slug: z.string().min(3, 'Slug must be at least 3 characters').regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  price: z.number().min(0, 'Price must be a positive number'),
  discountPrice: z.number().min(0, 'Discount price must be a positive number').nullable().optional(),
  weight: z.number().min(0, 'Weight must be a positive number').nullable().optional(),
  status: z.enum(['ACTIVE', 'INACTIVE', 'DRAFT']).default('ACTIVE'),
  stock: z.number().int().min(0, 'Stock must be a positive integer').default(0),
  sku: z.string().min(3, 'SKU must be at least 3 characters'),
  categoryId: z.string().uuid('Invalid category ID'),
  images: z.array(z.string().url('Invalid image URL')).optional(),
  variants: z.array(
    z.object({
      color: z.string().nullable().optional(),
      size: z.string().nullable().optional(),
      stock: z.number().int().min(0, 'Variant stock must be a positive integer').default(0),
      sku: z.string().nullable().optional(),
    })
  ).optional(),
});

export const updateProductSchema = createProductSchema.partial();

