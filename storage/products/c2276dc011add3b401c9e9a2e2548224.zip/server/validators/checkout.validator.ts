import { z } from 'zod';

export const checkoutPreviewSchema = z.object({
  addressId: z.string().uuid('Address ID must be a valid UUID').optional(),
  shippingCarrier: z.string().min(1, 'Shipping carrier is required').optional(),
  voucherCode: z.string().trim().toUpperCase().optional(),
});

export const checkoutExecuteSchema = z.object({
  addressId: z.string().uuid('Shipping address selection is required'),
  shippingCarrier: z.string().min(1, 'Shipping carrier selection is required'),
  voucherCode: z.string().trim().toUpperCase().optional(),
  paymentMethod: z.enum(['QRIS', 'TRANSFER', 'COD'], {
    message: 'Payment method must be either QRIS, TRANSFER, or COD',
  }),
});
