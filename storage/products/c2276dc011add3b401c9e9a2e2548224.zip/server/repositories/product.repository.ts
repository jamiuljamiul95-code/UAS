import { prisma } from '../config/db';
import { Prisma, Product } from '@prisma/client';
import { IProductRepository, ProductWithDetails } from '../interfaces/product.repository.interface';

export class ProductRepository implements IProductRepository {
  private includeDetails = {
    category: true,
    images: true,
    variants: true,
  };

  async findById(id: string): Promise<ProductWithDetails | null> {
    return prisma.product.findUnique({
      where: { id },
      include: this.includeDetails,
    }) as Promise<ProductWithDetails | null>;
  }

  async findBySlug(slug: string): Promise<ProductWithDetails | null> {
    return prisma.product.findUnique({
      where: { slug },
      include: this.includeDetails,
    }) as Promise<ProductWithDetails | null>;
  }

  async findBySku(sku: string): Promise<Product | null> {
    return prisma.product.findUnique({ where: { sku } });
  }

  async create(data: Prisma.ProductCreateInput): Promise<ProductWithDetails> {
    return prisma.product.create({
      data,
      include: this.includeDetails,
    }) as Promise<ProductWithDetails>;
  }

  async update(id: string, data: Prisma.ProductUpdateInput): Promise<ProductWithDetails> {
    return prisma.product.update({
      where: { id },
      data,
      include: this.includeDetails,
    }) as Promise<ProductWithDetails>;
  }

  async delete(id: string): Promise<Product> {
    return prisma.product.delete({ where: { id } });
  }

  async findMany(args?: Prisma.ProductFindManyArgs): Promise<ProductWithDetails[]> {
    return prisma.product.findMany({
      ...args,
      include: this.includeDetails,
    }) as Promise<ProductWithDetails[]>;
  }

  async count(args?: Prisma.ProductCountArgs): Promise<number> {
    return prisma.product.count(args);
  }

  async exists(id: string): Promise<boolean> {
    const count = await prisma.product.count({ where: { id } });
    return count > 0;
  }

  async hasOrderItems(id: string): Promise<boolean> {
    const count = await prisma.orderItem.count({ where: { productId: id } });
    return count > 0;
  }
}

export const productRepository = new ProductRepository();
