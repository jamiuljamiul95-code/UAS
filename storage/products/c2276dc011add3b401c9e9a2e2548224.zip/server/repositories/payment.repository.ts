import { prisma } from '../config/db';
import { Payment } from '@prisma/client';
import { IPaymentRepository, FindPaymentsParams } from '../interfaces/payment.repository.interface';
import { AppError } from '../utils/error.util';

export class PaymentRepository implements IPaymentRepository {
  async findPayments(params: FindPaymentsParams): Promise<{ payments: any[]; total: number }> {
    const where: any = {};

    // 1. RBAC constraints
    if (params.role === 'CUSTOMER' && params.userId) {
      where.userId = params.userId;
    }

    // 2. Status filter
    if (params.status) {
      where.status = params.status.toUpperCase();
    }

    // 3. Method filter
    if (params.method) {
      where.paymentMethod = params.method.toUpperCase();
    }

    // 4. Date range filter
    if (params.startDate || params.endDate) {
      where.createdAt = {};
      if (params.startDate) {
        where.createdAt.gte = new Date(params.startDate);
      }
      if (params.endDate) {
        const end = new Date(params.endDate);
        end.setHours(23, 59, 59, 999);
        where.createdAt.lte = end;
      }
    }

    // 5. Global Search
    if (params.search) {
      const searchStr = params.search.trim();
      where.OR = [
        { id: { contains: searchStr } },
        { orderId: { contains: searchStr } },
        { user: { name: { contains: searchStr } } },
        { user: { email: { contains: searchStr } } }
      ];
    }

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        include: {
          user: {
            select: { id: true, name: true, email: true, phone: true }
          },
          order: {
            include: {
              items: {
                include: {
                  product: {
                    select: { id: true, name: true, slug: true }
                  }
                }
              }
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: params.skip,
        take: params.take,
      }),
      prisma.payment.count({ where })
    ]);

    return { payments, total };
  }

  async findPaymentById(id: string): Promise<any | null> {
    return prisma.payment.findUnique({
      where: { id },
      include: {
        user: {
          select: { id: true, name: true, email: true, phone: true }
        },
        order: {
          include: {
            items: {
              include: {
                product: {
                  select: { id: true, name: true, slug: true }
                }
              }
            },
            timeline: {
              orderBy: { createdAt: 'asc' }
            }
          }
        }
      }
    });
  }

  async createPayment(data: {
    orderId: string;
    userId: string;
    amount: number;
    paymentMethod: string;
    status: string;
    proofOfPayment?: string;
    note?: string;
  }): Promise<any> {
    return prisma.$transaction(async (tx) => {
      // Create the payment record
      const payment = await tx.payment.create({
        data: {
          orderId: data.orderId,
          userId: data.userId,
          amount: data.amount,
          paymentMethod: data.paymentMethod.toUpperCase(),
          status: data.status,
          proofOfPayment: data.proofOfPayment,
          note: data.note,
        },
        include: {
          user: {
            select: { id: true, name: true, email: true, phone: true }
          },
          order: true
        }
      });

      // Update Order's status if necessary
      // If status is WAITING_VERIFICATION, we should update the Order timeline log as well!
      let orderStatusNote = `Pembayaran baru dibuat dengan metode ${data.paymentMethod}.`;
      if (data.status === 'WAITING_VERIFICATION') {
        orderStatusNote = `Customer mengunggah bukti pembayaran via ${data.paymentMethod}. Menunggu verifikasi admin.`;
        
        await tx.order.update({
          where: { id: data.orderId },
          data: {
            status: 'WAITING_PAYMENT'
          }
        });
      }

      await tx.orderTimeline.create({
        data: {
          orderId: data.orderId,
          status: 'WAITING_PAYMENT',
          note: orderStatusNote,
        }
      });

      return payment;
    });
  }

  async updatePaymentStatus(id: string, status: string, note?: string): Promise<any> {
    const targetStatus = status.toUpperCase();

    return prisma.$transaction(async (tx) => {
      const payment = await tx.payment.findUnique({
        where: { id },
        include: { order: true }
      });

      if (!payment) {
        throw new AppError('Payment not found', 404);
      }

      const prevStatus = payment.status;

      // Update the payment record
      const updatedPayment = await tx.payment.update({
        where: { id },
        data: {
          status: targetStatus,
          note: note || `Payment status updated from ${prevStatus} to ${targetStatus}`,
        },
        include: {
          user: {
            select: { id: true, name: true, email: true, phone: true }
          },
          order: {
            include: {
              items: {
                include: {
                  product: {
                    select: { id: true, name: true, slug: true }
                  }
                }
              }
            }
          }
        }
      });

      // Synchronize order status
      if (targetStatus === 'PAID') {
        // Order becomes PAID, paymentStatus is PAID, create timeline entry
        await tx.order.update({
          where: { id: payment.orderId },
          data: {
            status: 'PAID',
            paymentStatus: 'PAID'
          }
        });

        await tx.orderTimeline.create({
          data: {
            orderId: payment.orderId,
            status: 'PAID',
            note: note || `Pembayaran disetujui (ID: ${payment.id}). Status pesanan berubah menjadi PAID.`,
          }
        });
      } else if (targetStatus === 'REJECTED') {
        // Order remains/reverts to WAITING_PAYMENT or remains PENDING. Let's make it WAITING_PAYMENT.
        await tx.order.update({
          where: { id: payment.orderId },
          data: {
            paymentStatus: 'UNPAID'
          }
        });

        await tx.orderTimeline.create({
          data: {
            orderId: payment.orderId,
            status: 'WAITING_PAYMENT',
            note: note || `Pembayaran ditolak (ID: ${payment.id}). Menunggu pembayaran ulang.`,
          }
        });
      } else if (targetStatus === 'REFUNDED') {
        // Order becomes REFUND (from orderController) / REFUNDED
        await tx.order.update({
          where: { id: payment.orderId },
          data: {
            status: 'REFUND',
            paymentStatus: 'REFUNDED'
          }
        });

        await tx.orderTimeline.create({
          data: {
            orderId: payment.orderId,
            status: 'REFUND',
            note: note || `Pembayaran direfund (ID: ${payment.id}). Status pesanan berubah menjadi REFUND.`,
          }
        });
      }

      return updatedPayment;
    });
  }
}

export const paymentRepository = new PaymentRepository();
