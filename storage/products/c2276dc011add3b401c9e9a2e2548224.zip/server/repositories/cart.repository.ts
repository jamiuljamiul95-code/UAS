import { prisma } from '../config/db';
import { Cart, CartItem } from '@prisma/client';
import { ICartRepository, CartWithDetails, CartItemWithDetails } from '../interfaces/cart.repository.interface';

export class CartRepository implements ICartRepository {
  private includeDetails = {
    items: {
      include: {
        product: {
          include: {
            category: true,
            images: true,
            variants: true,
          }
        },
        variant: true,
      }
    }
  };

  private includeItemDetails = {
    product: {
      include: {
        category: true,
        images: true,
        variants: true,
      }
    },
    variant: true,
  };

  async findCartByUserId(userId: string): Promise<CartWithDetails | null> {
    return prisma.cart.findUnique({
      where: { userId },
      include: this.includeDetails,
    }) as Promise<CartWithDetails | null>;
  }

  async createCart(userId: string): Promise<CartWithDetails> {
    return prisma.cart.create({
      data: { userId },
      include: this.includeDetails,
    }) as Promise<CartWithDetails>;
  }

  async findCartItemById(id: string): Promise<CartItemWithDetails | null> {
    return prisma.cartItem.findUnique({
      where: { id },
      include: this.includeItemDetails,
    }) as Promise<CartItemWithDetails | null>;
  }

  async findCartItem(cartId: string, productId: string, variantId: string | null): Promise<CartItemWithDetails | null> {
    return prisma.cartItem.findFirst({
      where: {
        cartId,
        productId,
        variantId: variantId || null,
      },
      include: this.includeItemDetails,
    }) as Promise<CartItemWithDetails | null>;
  }

  async addCartItem(cartId: string, productId: string, variantId: string | null, quantity: number): Promise<CartItemWithDetails> {
    return prisma.cartItem.create({
      data: {
        cartId,
        productId,
        variantId: variantId || null,
        quantity,
      },
      include: this.includeItemDetails,
    }) as Promise<CartItemWithDetails>;
  }

  async updateCartItemQuantity(id: string, quantity: number): Promise<CartItemWithDetails> {
    return prisma.cartItem.update({
      where: { id },
      data: { quantity },
      include: this.includeItemDetails,
    }) as Promise<CartItemWithDetails>;
  }

  async deleteCartItem(id: string): Promise<CartItem> {
    return prisma.cartItem.delete({
      where: { id },
    });
  }

  async clearCart(cartId: string): Promise<void> {
    await prisma.cartItem.deleteMany({
      where: { cartId },
    });
  }

  async updateCartItemSelection(id: string, selected: boolean): Promise<CartItemWithDetails> {
    return prisma.cartItem.update({
      where: { id },
      data: { selected },
      include: this.includeItemDetails,
    }) as Promise<CartItemWithDetails>;
  }

  async updateCartItemsSelectionBulk(cartId: string, itemIds: string[], selected: boolean): Promise<void> {
    await prisma.cartItem.updateMany({
      where: {
        cartId,
        id: { in: itemIds },
      },
      data: { selected },
    });
  }

  async updateAllCartItemsSelection(cartId: string, selected: boolean): Promise<void> {
    await prisma.cartItem.updateMany({
      where: { cartId },
      data: { selected },
    });
  }
}

export const cartRepository = new CartRepository();
