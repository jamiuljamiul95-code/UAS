import { prisma } from '../config/db';
import { Voucher, Order, OrderItem, Address, Prisma } from '@prisma/client';
import { ICheckoutRepository } from '../interfaces/checkout.repository.interface';
import { AppError } from '../utils/error.util';

export class CheckoutRepository implements ICheckoutRepository {
  
  async findVoucherByCode(code: string): Promise<Voucher | null> {
    await this.ensureDefaultVouchersSeeded();
    return prisma.voucher.findUnique({
      where: { code: code.toUpperCase() },
    });
  }

  async findActiveVouchers(): Promise<Voucher[]> {
    await this.ensureDefaultVouchersSeeded();
    const now = new Date();
    return prisma.voucher.findMany({
      where: {
        status: 'ACTIVE',
        OR: [
          { expiryDate: null },
          { expiryDate: { gte: now } }
        ]
      }
    });
  }

  async getUserVoucherUsageCount(userId: string, voucherId: string): Promise<number> {
    return prisma.voucherUsage.count({
      where: {
        userId,
        voucherId,
      }
    });
  }

  // Ensures we have initial vouchers seeded in SQLite so checkout features work instantly
  private async ensureDefaultVouchersSeeded(): Promise<void> {
    const count = await prisma.voucher.count();
    if (count === 0) {
      const expiryFuture = new Date();
      expiryFuture.setFullYear(expiryFuture.getFullYear() + 2); // 2 years from now

      const expiryPast = new Date();
      expiryPast.setFullYear(expiryPast.getFullYear() - 1); // 1 year in the past

      await prisma.voucher.createMany({
        data: [
          {
            code: 'HEMAT50',
            type: 'NOMINAL',
            value: 50000,
            minPurchase: 200000,
            quota: 100,
            usedCount: 0,
            expiryDate: expiryFuture,
            status: 'ACTIVE',
          },
          {
            code: 'DISKON10',
            type: 'PERCENT',
            value: 10,
            minPurchase: 100000,
            quota: 200,
            usedCount: 0,
            expiryDate: expiryFuture,
            status: 'ACTIVE',
          },
          {
            code: 'CRAZYDEAL',
            type: 'NOMINAL',
            value: 15000,
            minPurchase: 0,
            quota: 50,
            usedCount: 0,
            expiryDate: expiryFuture,
            status: 'ACTIVE',
          },
          {
            code: 'EXPIRED50',
            type: 'NOMINAL',
            value: 50000,
            minPurchase: 0,
            quota: 10,
            usedCount: 0,
            expiryDate: expiryPast,
            status: 'ACTIVE',
          },
        ],
      });
    }
  }

  async createOrderTransaction(data: {
    userId: string;
    address: Address;
    shippingCarrier: string;
    shippingFee: number;
    voucherCode?: string;
    subtotal: number;
    discountAmount: number;
    taxAmount: number;
    totalAmount: number;
    paymentMethod: string;
    orderType: string;
    items: Array<{
      productId: string;
      variantId: string | null;
      quantity: number;
      price: number;
    }>;
    cartItemIdsToDelete: string[];
  }): Promise<Order & { items: OrderItem[] }> {
    
    // Execute all database updates atomically using Prisma's transaction mechanism
    return prisma.$transaction(async (tx) => {
      
      // 1. Stock Validation and decrement for each product/variant
      for (const item of data.items) {
        if (item.variantId) {
          // If product variant is specified, fetch and update variant stock
          const variant = await tx.productVariant.findUnique({
            where: { id: item.variantId },
            include: { product: true }
          });
          
          if (!variant) {
            throw new AppError(`Variant not found`, 404);
          }
          
          if (variant.product.status !== 'ACTIVE') {
            throw new AppError(`Product "${variant.product.name}" is no longer active`, 400);
          }

          if (variant.stock < item.quantity) {
            throw new AppError(`Insufficient stock for ${variant.product.name} (${variant.size || ''} ${variant.color || ''}). Requested ${item.quantity}, available ${variant.stock}`, 400);
          }

          // Decrement stock in product variant
          await tx.productVariant.update({
            where: { id: item.variantId },
            data: { stock: { decrement: item.quantity } }
          });

          // Also optionally decrement total base product stock for consistency
          await tx.product.update({
            where: { id: item.productId },
            data: { stock: { decrement: item.quantity } }
          });
        } else {
          // No variant, update the base product stock
          const product = await tx.product.findUnique({
            where: { id: item.productId }
          });

          if (!product) {
            throw new AppError(`Product not found`, 404);
          }

          if (product.status !== 'ACTIVE') {
            throw new AppError(`Product "${product.name}" is no longer active`, 400);
          }

          if (product.stock < item.quantity) {
            throw new AppError(`Insufficient stock for ${product.name}. Requested ${item.quantity}, available ${product.stock}`, 400);
          }

          // Decrement stock in base product
          await tx.product.update({
            where: { id: item.productId },
            data: { stock: { decrement: item.quantity } }
          });
        }
      }

      // 2. Voucher validation and lock-in (if voucher code is supplied)
      let voucherId: string | null = null;
      if (data.voucherCode) {
        const voucher = await tx.voucher.findUnique({
          where: { code: data.voucherCode.toUpperCase() }
        });

        if (!voucher) {
          throw new AppError(`Voucher code "${data.voucherCode}" is invalid`, 400);
        }

        const now = new Date();
        if (voucher.status !== 'ACTIVE' || (voucher.expiryDate && voucher.expiryDate < now)) {
          throw new AppError('Voucher has expired or is inactive', 400);
        }

        if (voucher.quota > 0 && voucher.usedCount >= voucher.quota) {
          throw new AppError('Voucher quota has been fully redeemed', 400);
        }

        // Verify single user usage constraint
        const usageCount = await tx.voucherUsage.count({
          where: {
            userId: data.userId,
            voucherId: voucher.id,
          }
        });

        if (usageCount > 0) {
          throw new AppError('You have already used this voucher code', 400);
        }

        // Increment used counter
        await tx.voucher.update({
          where: { id: voucher.id },
          data: { usedCount: { increment: 1 } }
        });

        voucherId = voucher.id;
      }

      // Formulate full shipping address string
      const addr = data.address;
      const formattedAddress = `${addr.recipientName} | ${addr.phone}\n${addr.address}, ${addr.district}, ${addr.city}, ${addr.province}, ${addr.postalCode}${addr.notes ? `\nCatatan: ${addr.notes}` : ''}`;

      // 3. Create Order
      const order = await tx.order.create({
        data: {
          userId: data.userId,
          status: 'PENDING',
          paymentMethod: data.paymentMethod,
          paymentStatus: 'UNPAID',
          shippingAddress: formattedAddress,
          orderType: data.orderType,
          subtotal: data.subtotal,
          discountAmount: data.discountAmount,
          shippingFee: data.shippingFee,
          shippingCarrier: data.shippingCarrier,
          taxAmount: data.taxAmount,
          totalAmount: data.totalAmount,
          voucherId: voucherId,
          items: {
            create: data.items.map(item => ({
              productId: item.productId,
              variantId: item.variantId,
              quantity: item.quantity,
              price: item.price
            }))
          }
        },
        include: {
          items: true
        }
      });

      // 4. Record Voucher Usage
      if (voucherId) {
        await tx.voucherUsage.create({
          data: {
            userId: data.userId,
            voucherId: voucherId,
            orderId: order.id
          }
        });
      }

      // 5. Remove items from Cart (Delete selected checkout items)
      if (data.cartItemIdsToDelete.length > 0) {
        await tx.cartItem.deleteMany({
          where: {
            id: { in: data.cartItemIdsToDelete }
          }
        });
      }

      return order;
    });
  }
}

export const checkoutRepository = new CheckoutRepository();
