import { prisma } from '../config/db';
import { Prisma, User, Address } from '@prisma/client';
import { IUserRepository } from '../interfaces/user.repository.interface';

export class UserRepository implements IUserRepository {
  async findByEmail(email: string): Promise<User | null> {
    return prisma.user.findUnique({ where: { email } });
  }

  async findByPhone(phone: string): Promise<User | null> {
    return prisma.user.findFirst({ where: { phone } });
  }

  async findById(id: string): Promise<User | null> {
    return prisma.user.findUnique({
      where: { id },
    });
  }

  async count(where?: Prisma.UserWhereInput): Promise<number> {
    return prisma.user.count({ where });
  }

  async create(data: Prisma.UserCreateInput): Promise<User> {
    return prisma.user.create({ data });
  }

  async update(id: string, data: Prisma.UserUpdateInput): Promise<User> {
    return prisma.user.update({ where: { id }, data });
  }

  async delete(id: string): Promise<User> {
    return prisma.user.delete({ where: { id } });
  }

  async findMany(args?: Prisma.UserFindManyArgs): Promise<User[]> {
    return prisma.user.findMany(args);
  }

  async exists(email: string): Promise<boolean> {
    const count = await prisma.user.count({ where: { email } });
    return count > 0;
  }

  async hasOrders(userId: string): Promise<boolean> {
    const count = await prisma.order.count({ where: { userId } });
    return count > 0;
  }

  async getUserOrderStats(userId: string): Promise<{ orderCount: number; totalSpent: number }> {
    const orderCount = await prisma.order.count({ where: { userId } });
    const orders = await prisma.order.findMany({
      where: { userId, paymentStatus: 'PAID' },
      select: { totalAmount: true }
    });
    const totalSpent = orders.reduce((sum, o) => sum + o.totalAmount, 0);
    return { orderCount, totalSpent };
  }
}

export class AddressRepository {
  async findById(id: string): Promise<Address | null> {
    return prisma.address.findUnique({ where: { id } });
  }

  async findManyByUserId(userId: string): Promise<Address[]> {
    return prisma.address.findMany({
      where: { userId },
      orderBy: { isDefault: 'desc' }
    });
  }

  async create(data: Prisma.AddressUncheckedCreateInput): Promise<Address> {
    return prisma.address.create({ data });
  }

  async update(id: string, data: Prisma.AddressUpdateInput): Promise<Address> {
    return prisma.address.update({ where: { id }, data });
  }

  async delete(id: string): Promise<Address> {
    return prisma.address.delete({ where: { id } });
  }

  async unsetDefaultAddresses(userId: string): Promise<void> {
    await prisma.address.updateMany({
      where: { userId, isDefault: true },
      data: { isDefault: false }
    });
  }
}

export const userRepository = new UserRepository();
export const addressRepository = new AddressRepository();
