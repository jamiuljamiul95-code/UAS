import { prisma } from '../config/db';
import { Order, OrderItem, OrderTimeline } from '@prisma/client';
import { IOrderRepository, FindOrdersParams } from '../interfaces/order.repository.interface';
import { AppError } from '../utils/error.util';

export class OrderRepository implements IOrderRepository {
  async findOrders(params: FindOrdersParams): Promise<{ orders: any[]; total: number }> {
    const where: any = {};

    // 1. Role boundaries
    if (params.role === 'CUSTOMER' && params.userId) {
      where.userId = params.userId;
    } else if (params.customerFilter) {
      // Admin filtering for a specific customer (ID, name, or email)
      const cf = params.customerFilter.trim();
      where.OR = [
        { userId: cf },
        { user: { name: { contains: cf } } },
        { user: { email: { contains: cf } } }
      ];
    }

    // 2. Status filter
    if (params.status) {
      where.status = params.status.toUpperCase();
    }

    // 3. Date range filter
    if (params.startDate || params.endDate) {
      where.createdAt = {};
      if (params.startDate) {
        where.createdAt.gte = new Date(params.startDate);
      }
      if (params.endDate) {
        const end = new Date(params.endDate);
        end.setHours(23, 59, 59, 999);
        where.createdAt.lte = end;
      }
    }

    // 4. Global Search
    if (params.search) {
      const searchStr = params.search.trim();
      const searchConditions = [
        { id: { contains: searchStr } },
        { user: { name: { contains: searchStr } } },
        { user: { email: { contains: searchStr } } }
      ];

      if (where.OR) {
        // If we already have a customerFilter or OR clause, we intersect it
        where.AND = [
          { OR: where.OR },
          { OR: searchConditions }
        ];
        delete where.OR;
      } else {
        where.OR = searchConditions;
      }
    }

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          user: {
            select: { id: true, name: true, email: true, phone: true }
          },
          items: {
            include: {
              product: {
                select: { id: true, name: true, slug: true, categoryId: true }
              },
              variant: true
            }
          },
          timeline: {
            orderBy: { createdAt: 'asc' }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: params.skip,
        take: params.take,
      }),
      prisma.order.count({ where })
    ]);

    return { orders, total };
  }

  async findOrderById(id: string): Promise<any | null> {
    return prisma.order.findUnique({
      where: { id },
      include: {
        user: {
          select: { id: true, name: true, email: true, phone: true }
        },
        items: {
          include: {
            product: true,
            variant: true
          }
        },
        timeline: {
          orderBy: { createdAt: 'asc' }
        }
      }
    });
  }

  async updateOrderStatus(id: string, status: string, note?: string): Promise<any> {
    const targetStatus = status.toUpperCase();

    return prisma.$transaction(async (tx) => {
      const order = await tx.order.findUnique({
        where: { id },
        include: { items: true }
      });

      if (!order) {
        throw new AppError('Order not found', 404);
      }

      if (order.status === targetStatus) {
        return order; // No changes needed
      }

      const prevStatus = order.status;

      // 1. Prepare status data update
      const updateData: any = { status: targetStatus };

      if (targetStatus === 'PAID') {
        updateData.paymentStatus = 'PAID';
      } else if (targetStatus === 'REFUND') {
        updateData.paymentStatus = 'REFUNDED';
      } else if (targetStatus === 'CANCELLED') {
        updateData.paymentStatus = 'UNPAID';
      }

      // 2. If transition is to CANCELLED, restore product and variant stocks
      if (targetStatus === 'CANCELLED' && prevStatus !== 'CANCELLED') {
        for (const item of order.items) {
          if (item.variantId) {
            await tx.productVariant.update({
              where: { id: item.variantId },
              data: { stock: { increment: item.quantity } }
            });
            // Also restore base product stock for consistency
            await tx.product.update({
              where: { id: item.productId },
              data: { stock: { increment: item.quantity } }
            });
          } else {
            await tx.product.update({
              where: { id: item.productId },
              data: { stock: { increment: item.quantity } }
            });
          }
        }
      }

      // 3. Update Order
      const updatedOrder = await tx.order.update({
        where: { id },
        data: updateData,
        include: {
          user: {
            select: { id: true, name: true, email: true, phone: true }
          },
          items: {
            include: { product: true, variant: true }
          },
          timeline: {
            orderBy: { createdAt: 'asc' }
          }
        }
      });

      // 4. Create Order Timeline
      await tx.orderTimeline.create({
        data: {
          orderId: id,
          status: targetStatus,
          note: note || `Order status updated from ${prevStatus} to ${targetStatus}`,
        }
      });

      return updatedOrder;
    });
  }

  async cancelOrder(id: string, userId?: string, note?: string): Promise<any> {
    return prisma.$transaction(async (tx) => {
      const order = await tx.order.findUnique({
        where: { id },
        include: { items: true }
      });

      if (!order) {
        throw new AppError('Order not found', 404);
      }

      // If userId is provided, ensure user owns the order
      if (userId && order.userId !== userId) {
        throw new AppError('You do not have permission to cancel this order', 403);
      }

      // Customers can only cancel if status is PENDING or WAITING_PAYMENT (belum diproses)
      if (userId && order.status !== 'PENDING' && order.status !== 'WAITING_PAYMENT') {
        throw new AppError('Cannot cancel order that is already being processed', 400);
      }

      if (order.status === 'CANCELLED') {
        throw new AppError('Order is already cancelled', 400);
      }

      const prevStatus = order.status;

      // 1. Restore stock
      for (const item of order.items) {
        if (item.variantId) {
          await tx.productVariant.update({
            where: { id: item.variantId },
            data: { stock: { increment: item.quantity } }
          });
          await tx.product.update({
            where: { id: item.productId },
            data: { stock: { increment: item.quantity } }
          });
        } else {
          await tx.product.update({
            where: { id: item.productId },
            data: { stock: { increment: item.quantity } }
          });
        }
      }

      // 2. Update Order
      const updatedOrder = await tx.order.update({
        where: { id },
        data: {
          status: 'CANCELLED',
          paymentStatus: 'UNPAID'
        },
        include: {
          user: {
            select: { id: true, name: true, email: true, phone: true }
          },
          items: {
            include: { product: true, variant: true }
          },
          timeline: {
            orderBy: { createdAt: 'asc' }
          }
        }
      });

      // 3. Create Timeline Entry
      await tx.orderTimeline.create({
        data: {
          orderId: id,
          status: 'CANCELLED',
          note: note || `Order cancelled by user. Previous status: ${prevStatus}`,
        }
      });

      return updatedOrder;
    });
  }

  async createOrder(data: {
    userId: string;
    status: string;
    totalAmount: number;
    paymentMethod: string;
    paymentStatus: string;
    orderType: string;
    subtotal: number;
    discountAmount: number;
    shippingFee: number;
    shippingCarrier?: string | null;
    shippingAddress?: string | null;
    taxAmount: number;
    voucherId?: string | null;
    items: {
      productId: string;
      variantId?: string | null;
      quantity: number;
      price: number;
    }[];
  }): Promise<any> {
    return prisma.$transaction(async (tx) => {
      // 1. Validate active products and reduce stock
      for (const item of data.items) {
        if (item.variantId) {
          const variant = await tx.productVariant.findUnique({
            where: { id: item.variantId },
            include: { product: true }
          });

          if (!variant) {
            throw new AppError('Variant not found', 404);
          }

          if (variant.product.status !== 'ACTIVE') {
            throw new AppError(`Product "${variant.product.name}" is no longer active`, 400);
          }

          if (variant.stock < item.quantity) {
            throw new AppError(`Insufficient stock for ${variant.product.name} (${variant.size || ''} ${variant.color || ''}). Requested ${item.quantity}, available ${variant.stock}`, 400);
          }

          // Decrement variant stock
          await tx.productVariant.update({
            where: { id: item.variantId },
            data: { stock: { decrement: item.quantity } }
          });

          // Decrement base product stock for consistency
          await tx.product.update({
            where: { id: item.productId },
            data: { stock: { decrement: item.quantity } }
          });
        } else {
          const product = await tx.product.findUnique({
            where: { id: item.productId }
          });

          if (!product) {
            throw new AppError('Product not found', 404);
          }

          if (product.status !== 'ACTIVE') {
            throw new AppError(`Product "${product.name}" is no longer active`, 400);
          }

          if (product.stock < item.quantity) {
            throw new AppError(`Insufficient stock for ${product.name}. Requested ${item.quantity}, available ${product.stock}`, 400);
          }

          // Decrement base product stock
          await tx.product.update({
            where: { id: item.productId },
            data: { stock: { decrement: item.quantity } }
          });
        }
      }

      // 2. Create the order
      const order = await tx.order.create({
        data: {
          userId: data.userId,
          status: data.status,
          totalAmount: data.totalAmount,
          paymentMethod: data.paymentMethod,
          paymentStatus: data.paymentStatus,
          orderType: data.orderType,
          subtotal: data.subtotal,
          discountAmount: data.discountAmount,
          shippingFee: data.shippingFee,
          shippingCarrier: data.shippingCarrier,
          shippingAddress: data.shippingAddress,
          taxAmount: data.taxAmount,
          voucherId: data.voucherId,
          items: {
            create: data.items.map(item => ({
              productId: item.productId,
              variantId: item.variantId,
              quantity: item.quantity,
              price: item.price
            }))
          }
        },
        include: {
          user: {
            select: { id: true, name: true, email: true, phone: true }
          },
          items: {
            include: {
              product: {
                select: { id: true, name: true, slug: true, categoryId: true }
              },
              variant: true
            }
          },
          timeline: {
            orderBy: { createdAt: 'asc' }
          }
        }
      });

      // 3. Create initial timeline entry
      await tx.orderTimeline.create({
        data: {
          orderId: order.id,
          status: data.status,
          note: `Order created with status ${data.status} via ${data.orderType}`,
        }
      });

      return order;
    });
  }
}

export const orderRepository = new OrderRepository();
