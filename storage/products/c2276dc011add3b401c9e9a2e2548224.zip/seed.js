import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash("password123", 10);
  
  const owner = await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      name: 'Admin / Owner',
      email: 'admin@example.com',
      password: hashedPassword,
      phone: '081234567890',
      role: 'OWNER',
    },
  });

  const cashier = await prisma.user.upsert({
    where: { email: 'kasir@example.com' },
    update: {},
    create: {
      name: 'Kasir',
      email: 'kasir@example.com',
      password: hashedPassword,
      phone: '081234567891',
      role: 'CASHIER',
    },
  });

  const customer = await prisma.user.upsert({
    where: { email: 'pelanggan@example.com' },
    update: {},
    create: {
      name: 'Pelanggan',
      email: 'pelanggan@example.com',
      password: hashedPassword,
      phone: '081234567892',
      role: 'CUSTOMER',
    },
  });

  console.log('Seeded database successfully with users:', {
    owner: owner.email,
    cashier: cashier.email,
    customer: customer.email,
  });
}

main()
  .catch(e => console.error(e))
  .finally(async () => await prisma.$disconnect());
