# LuxeStore: Clothing POS & E-Commerce

A full-stack unified POS (Point of Sale) and E-Commerce solution built specifically for clothing and retail stores.

## Features
- **Public Shop**: Clean, responsive e-commerce storefront for customers to browse, view product details, add items to cart, and checkout.
- **Admin Dashboard**: Comprehensive dashboard for store management.
- **POS Interface**: Dedicated fast-checkout interface for cashiers.
- **Inventory Management**: Track products, variants (sizes, colors), and stock levels.
- **Role-based Access**: Custom permissions for OWNER, ADMIN, STAFF, CASHIER, and CUSTOMER roles.
- **RESTful API**: Secure Express.js backend using JWT authentication.

## Tech Stack
- **Frontend**: React, Tailwind CSS, Zustand, React Router, Lucide Icons.
- **Backend**: Node.js, Express, Prisma ORM, JSON Web Tokens (JWT), bcrypt.
- **Database**: Configured for SQLite by default for easy setup, fully compatible with PostgreSQL/MySQL via Prisma.

## Getting Started

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Environment Variables**
   Copy `.env.example` to `.env` and set your `JWT_SECRET`.
   ```bash
   cp .env.example .env
   ```

3. **Database Setup**
   Run Prisma migrations to create the database schema.
   ```bash
   npx prisma generate
   npx prisma db push
   ```
   *(Note: For production, use `npx prisma migrate dev` and `npx prisma migrate deploy`)*

4. **Start Development Server**
   ```bash
   npm run dev
   ```
   Server and frontend will run simultaneously via Vite middleware.

## Deployment
This project is configured to bundle the server and frontend into a single Node application, making it easy to deploy to platforms like Vercel, Railway, or Google Cloud Run.

1. **Build**
   ```bash
   npm run build
   ```
   This bundles the React app into `dist/` and compiles the Express server to `dist/server.cjs`.

2. **Start Production**
   ```bash
   npm run start
   ```
