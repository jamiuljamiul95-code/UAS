import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { getApp, createTestUser, getAuthHeader } from '../setup/testUtils';
import { prisma } from '../../server/config/db';

describe('User & Customer Management API', () => {
  describe('GET /api/users (Admin user list)', () => {
    it('should allow ADMIN to retrieve users with pagination, search, and filters', async () => {
      const app = await getApp();
      const admin = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(admin);

      // Create a few users
      const randomId = Date.now();
      const u1 = await createTestUser({ name: `User A ${randomId}`, email: `user-a-${randomId}@test.com`, role: 'CUSTOMER' });
      const u2 = await createTestUser({ name: `User B ${randomId}`, email: `user-b-${randomId}@test.com`, role: 'STAFF' });
      await prisma.user.update({
        where: { id: u2.id },
        data: { status: 'INACTIVE' }
      });

      // 1. Fetch all
      const response = await request(app)
        .get('/api/users')
        .set(authHeader)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.length).toBeGreaterThanOrEqual(2);

      // 2. Search
      const searchResponse = await request(app)
        .get(`/api/users?search=User A ${randomId}`)
        .set(authHeader)
        .expect(200);

      expect(searchResponse.body.data.some((u: any) => u.id === u1.id)).toBe(true);
      expect(searchResponse.body.data.some((u: any) => u.id === u2.id)).toBe(false);

      // 3. Filter by Role
      const roleResponse = await request(app)
        .get('/api/users?role=STAFF')
        .set(authHeader)
        .expect(200);

      expect(roleResponse.body.data.some((u: any) => u.id === u2.id)).toBe(true);
      expect(roleResponse.body.data.some((u: any) => u.id === u1.id)).toBe(false);

      // 4. Filter by Status
      const statusResponse = await request(app)
        .get('/api/users?status=INACTIVE')
        .set(authHeader)
        .expect(200);

      expect(statusResponse.body.data.some((u: any) => u.id === u2.id)).toBe(true);
      expect(statusResponse.body.data.some((u: any) => u.id === u1.id)).toBe(false);
    });

    it('should deny non-admin access', async () => {
      const app = await getApp();
      const customer = await createTestUser({ role: 'CUSTOMER' });
      const authHeader = getAuthHeader(customer);

      await request(app)
        .get('/api/users')
        .set(authHeader)
        .expect(403);
    });
  });

  describe('POST /api/users (Create User)', () => {
    it('should allow ADMIN to create user', async () => {
      const app = await getApp();
      const admin = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(admin);

      const email = `created-${Date.now()}@test.com`;
      const response = await request(app)
        .post('/api/users')
        .set(authHeader)
        .send({
          name: 'Super Customer',
          email,
          password: 'superpassword',
          phone: `0899123${Date.now().toString().slice(-4)}`,
          role: 'CUSTOMER',
          status: 'ACTIVE'
        })
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.email).toBe(email);
      expect(response.body.data).not.toHaveProperty('password');
    });

    it('should reject duplicate email or duplicate phone number', async () => {
      const app = await getApp();
      const admin = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(admin);

      const user1 = await createTestUser();

      // Duplicate email
      await request(app)
        .post('/api/users')
        .set(authHeader)
        .send({
          name: 'Customer Twin',
          email: user1.email,
          password: 'somepassword',
          phone: '081299990001',
          role: 'CUSTOMER'
        })
        .expect(400);
    });
  });

  describe('User Details, Status and Deletion', () => {
    it('should support full user detail, status PATCH, and DELETE', async () => {
      const app = await getApp();
      const admin = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(admin);

      const targetUser = await createTestUser({ role: 'CUSTOMER' });

      // 1. Get Detail
      const detailResponse = await request(app)
        .get(`/api/users/${targetUser.id}`)
        .set(authHeader)
        .expect(200);

      expect(detailResponse.body.success).toBe(true);
      expect(detailResponse.body.data.id).toBe(targetUser.id);
      expect(detailResponse.body.data).toHaveProperty('addresses');
      expect(detailResponse.body.data).toHaveProperty('orderCount');

      // 2. Patch status
      const statusResponse = await request(app)
        .patch(`/api/users/${targetUser.id}/status`)
        .set(authHeader)
        .send({ status: 'INACTIVE' })
        .expect(200);

      expect(statusResponse.body.data.status).toBe('INACTIVE');

      // 3. Delete
      await request(app)
        .delete(`/api/users/${targetUser.id}`)
        .set(authHeader)
        .expect(200);

      // Verify deleted
      await request(app)
        .get(`/api/users/${targetUser.id}`)
        .set(authHeader)
        .expect(404);
    });

    it('should prevent deleting self', async () => {
      const app = await getApp();
      const admin = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(admin);

      await request(app)
        .delete(`/api/users/${admin.id}`)
        .set(authHeader)
        .expect(400);
    });

    it('should prevent deleting customer with orders', async () => {
      const app = await getApp();
      const admin = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(admin);

      const target = await createTestUser({ role: 'CUSTOMER' });

      // Create an order for target user
      await prisma.order.create({
        data: {
          userId: target.id,
          totalAmount: 150000,
          paymentMethod: 'TRANSFER',
          paymentStatus: 'PAID',
          status: 'COMPLETED'
        }
      });

      await request(app)
        .delete(`/api/users/${target.id}`)
        .set(authHeader)
        .expect(400);
    });
  });

  describe('Profile & Addresses API (Logged in Customer)', () => {
    it('should allow customer to get and update profile, and perform address CRUD', async () => {
      const app = await getApp();
      const customer = await createTestUser({ role: 'CUSTOMER' });
      const authHeader = getAuthHeader(customer);

      // 1. Get profile
      const profileRes = await request(app)
        .get('/api/profile')
        .set(authHeader)
        .expect(200);

      expect(profileRes.body.data.id).toBe(customer.id);

      // 2. Update profile
      const newDob = '1995-10-25';
      const updateRes = await request(app)
        .put('/api/profile')
        .set(authHeader)
        .send({
          name: 'Jane Updated',
          dob: newDob,
          gender: 'FEMALE'
        })
        .expect(200);

      expect(updateRes.body.data.name).toBe('Jane Updated');
      expect(updateRes.body.data.dob).toBe(newDob);
      expect(updateRes.body.data.gender).toBe('FEMALE');

      // 3. Address CRUD
      // 3a. Create Address 1 (Default by force since it's first)
      const addrRes1 = await request(app)
        .post('/api/profile/addresses')
        .set(authHeader)
        .send({
          title: 'Rumah',
          recipientName: 'Jane Mom',
          phone: '081234567800',
          province: 'DKI Jakarta',
          city: 'Jakarta Selatan',
          district: 'Kebayoran Baru',
          postalCode: '12110',
          address: 'Jl. Senopati No. 45',
          isDefault: false
        })
        .expect(201);

      expect(addrRes1.body.data.title).toBe('Rumah');
      expect(addrRes1.body.data.isDefault).toBe(true); // Should auto-set to true

      // 3b. Create Address 2 (set as default)
      const addrRes2 = await request(app)
        .post('/api/profile/addresses')
        .set(authHeader)
        .send({
          title: 'Kantor',
          recipientName: 'Jane Doe Office',
          phone: '081234567811',
          province: 'DKI Jakarta',
          city: 'Jakarta Pusat',
          district: 'Menteng',
          postalCode: '10310',
          address: 'Jl. Sudirman Kav 21',
          isDefault: true
        })
        .expect(201);

      expect(addrRes2.body.data.isDefault).toBe(true);

      // 3c. Fetch address list
      const getAddrRes = await request(app)
        .get('/api/profile/addresses')
        .set(authHeader)
        .expect(200);

      expect(getAddrRes.body.data.length).toBe(2);
      expect(getAddrRes.body.data[0].id).toBe(addrRes2.body.data.id); // Default is first

      // 3d. Update Address 1
      const updateAddrRes = await request(app)
        .put(`/api/profile/addresses/${addrRes1.body.data.id}`)
        .set(authHeader)
        .send({
          title: 'Rumah Baru',
          recipientName: 'Jane Mom Updated',
          phone: '081234567800',
          province: 'DKI Jakarta',
          city: 'Jakarta Selatan',
          district: 'Kebayoran Baru',
          postalCode: '12110',
          address: 'Jl. Senopati No. 45B',
          isDefault: true
        })
        .expect(200);

      expect(updateAddrRes.body.data.title).toBe('Rumah Baru');
      expect(updateAddrRes.body.data.isDefault).toBe(true);

      // 3e. Delete Address 2
      await request(app)
        .delete(`/api/profile/addresses/${addrRes2.body.data.id}`)
        .set(authHeader)
        .expect(204);

      // Verify deleted and that Address 1 is now default again
      const checkAddrRes = await request(app)
        .get('/api/profile/addresses')
        .set(authHeader)
        .expect(200);

      expect(checkAddrRes.body.data.length).toBe(1);
      expect(checkAddrRes.body.data[0].id).toBe(addrRes1.body.data.id);
      expect(checkAddrRes.body.data[0].isDefault).toBe(true);
    });
  });
});
