import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { getApp, createTestUser, getAuthHeader } from '../setup/testUtils';
import { prisma } from '../../server/config/db';

describe('Category API', () => {
  describe('GET /api/categories', () => {
    it('should return 200 and a list of categories', async () => {
      const app = await getApp();
      const response = await request(app)
        .get('/api/categories')
        .expect('Content-Type', /json/)
        .expect(200);

      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('data');
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  describe('POST /api/categories', () => {
    it('should create a new category (Success) with valid admin credentials', async () => {
      const app = await getApp();
      const adminUser = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(adminUser);

      const response = await request(app)
        .post('/api/categories')
        .set(authHeader)
        .send({
          name: 'Winter Collection',
          slug: 'winter-collection',
        })
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('id');
      expect(response.body.data.name).toBe('Winter Collection');
      expect(response.body.data.slug).toBe('winter-collection');
    });

    it('should fail with 400 for duplicate slug', async () => {
      const app = await getApp();
      const adminUser = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(adminUser);

      await prisma.category.create({
        data: {
          name: 'Unique Cat',
          slug: 'unique-cat',
        },
      });

      const response = await request(app)
        .post('/api/categories')
        .set(authHeader)
        .send({
          name: 'Another Cat',
          slug: 'unique-cat',
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('already exists');
    });

    it('should fail with 401 without auth header (Unauthorized)', async () => {
      const app = await getApp();

      const response = await request(app)
        .post('/api/categories')
        .send({
          name: 'No Auth Category',
          slug: 'no-auth-category',
        })
        .expect(401);

      expect(response.body.success).toBe(false);
    });

    it('should fail with 403 for customer user (Forbidden)', async () => {
      const app = await getApp();
      const customer = await createTestUser({ role: 'CUSTOMER' });
      const authHeader = getAuthHeader(customer);

      const response = await request(app)
        .post('/api/categories')
        .set(authHeader)
        .send({
          name: 'Customer Category',
          slug: 'customer-category',
        })
        .expect(403);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('insufficient permissions');
    });

    it('should fail with 400 for invalid inputs (Validation Error)', async () => {
      const app = await getApp();
      const adminUser = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(adminUser);

      const response = await request(app)
        .post('/api/categories')
        .set(authHeader)
        .send({
          name: 'Ab', // too short
          slug: 'Invalid Slug!', // uppercase and invalid characters
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Validation failed');
    });
  });

  describe('PUT /api/categories/:id', () => {
    it('should update an existing category (Success)', async () => {
      const app = await getApp();
      const adminUser = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(adminUser);

      const category = await prisma.category.create({
        data: {
          name: 'Summer Sale',
          slug: 'summer-sale',
        },
      });

      const response = await request(app)
        .put(`/api/categories/${category.id}`)
        .set(authHeader)
        .send({
          name: 'Summer Sale Updated',
          slug: 'summer-sale-updated',
        })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.name).toBe('Summer Sale Updated');
      expect(response.body.data.slug).toBe('summer-sale-updated');
    });

    it('should fail with 404 for non-existent category (Not Found)', async () => {
      const app = await getApp();
      const adminUser = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(adminUser);

      const response = await request(app)
        .put('/api/categories/non-existent-uuid')
        .set(authHeader)
        .send({
          name: 'Summer Sale',
        })
        .expect(404);

      expect(response.body.success).toBe(false);
    });
  });

  describe('DELETE /api/categories/:id', () => {
    it('should delete a category (Success)', async () => {
      const app = await getApp();
      const adminUser = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(adminUser);

      const category = await prisma.category.create({
        data: {
          name: 'To Be Deleted',
          slug: 'to-be-deleted',
        },
      });

      const response = await request(app)
        .delete(`/api/categories/${category.id}`)
        .set(authHeader)
        .expect(200);

      expect(response.body.success).toBe(true);

      const deleted = await prisma.category.findUnique({ where: { id: category.id } });
      expect(deleted).toBeNull();
    });

    it('should fail to delete category with associated products', async () => {
      const app = await getApp();
      const adminUser = await createTestUser({ role: 'ADMIN' });
      const authHeader = getAuthHeader(adminUser);

      const category = await prisma.category.create({
        data: {
          name: 'Has Products',
          slug: 'has-products',
        },
      });

      await prisma.product.create({
        data: {
          categoryId: category.id,
          name: 'Some Product',
          slug: 'some-product',
          description: 'This is a long description of a product',
          price: 10000,
          stock: 10,
          sku: 'SKU-HAS-PROD',
        },
      });

      const response = await request(app)
        .delete(`/api/categories/${category.id}`)
        .set(authHeader)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Cannot delete category');
    });
  });
});
