import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { getApp } from '../setup/testUtils';

describe('Health & Global Routes', () => {
  it('GET /api/health should return 200 and OK status', async () => {
    const app = await getApp();
    const response = await request(app)
      .get('/api/health')
      .expect('Content-Type', /json/)
      .expect(200);

    expect(response.body).toEqual({
      status: 'ok',
      message: 'API is running',
    });
    expect(response.headers['x-request-id']).toBeDefined();
  });

  it('GET /api/non-existent-route should return 404 with JSON error', async () => {
    const app = await getApp();
    const response = await request(app)
      .get('/api/non-existent-route')
      .expect('Content-Type', /json/)
      .expect(404);

    expect(response.body).toEqual({
      success: false,
      message: 'Route not found',
    });
  });
});
