import { createExpressApp } from '../../server';
import { prisma } from '../../server/config/db';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { env } from '../../server/config/env';

let appInstance: any = null;

/**
 * Returns a cached or fresh Express app instance.
 */
export const getApp = async () => {
  if (!appInstance) {
    appInstance = await createExpressApp();
  }
  return appInstance;
};

/**
 * Creates a user directly in the test database for testing purposes.
 */
export const createTestUser = async (override: {
  name?: string;
  email?: string;
  password?: string;
  role?: string;
} = {}) => {
  const password = override.password || 'password123';
  const hashedPassword = await bcrypt.hash(password, 10);

  const user = await prisma.user.create({
    data: {
      name: override.name || 'Test User',
      email: override.email || `test-${Date.now()}-${Math.random()}@example.com`,
      password: hashedPassword,
      role: override.role || 'CUSTOMER',
    },
  });

  return {
    ...user,
    plainPassword: password,
  };
};

/**
 * Generates an authentication token and returns an Authorization header object.
 */
export const getAuthHeader = (user: { id: string; email: string; role: string }) => {
  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    env.JWT_SECRET,
    { expiresIn: '1h' }
  );
  return {
    Authorization: `Bearer ${token}`,
  };
};
