import { beforeAll, beforeEach, afterAll } from 'vitest';
import { execSync } from 'child_process';
import { prisma } from '../../server/config/db';

beforeAll(() => {
  // Sync the SQLite schema dynamically for the test environment
  console.log('⏳ Running database synchronization for testing...');
  try {
    execSync('npx prisma db push --accept-data-loss', { stdio: 'inherit' });
    console.log('✅ Test database synchronized successfully.');
  } catch (error) {
    console.error('❌ Failed to synchronize test database schema:', error);
    throw error;
  }
});

beforeEach(async () => {
  // Clear tables in dependency order to prevent foreign key constraint violations
  const tables = [
    'OrderItem',
    'Order',
    'CartItem',
    'Cart',
    'ProductVariant',
    'ProductImage',
    'Product',
    'Category',
    'Address',
    'User',
  ];

  for (const table of tables) {
    try {
      await prisma.$executeRawUnsafe(`DELETE FROM "${table}";`);
    } catch (err) {
      // Ignore if table doesn't exist
    }
  }
});

afterAll(async () => {
  // Gracefully disconnect Prisma Client
  await prisma.$disconnect();
});
