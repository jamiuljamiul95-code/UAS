import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { getApp, createTestUser, getAuthHeader } from '../setup/testUtils';
import { prisma } from '../../server/config/db';

describe('Product API', () => {
  it('GET /api/products should return 200 and a list of products', async () => {
    const app = await getApp();
    const response = await request(app)
      .get('/api/products')
      .expect('Content-Type', /json/)
      .expect(200);

    expect(response.body).toHaveProperty('success', true);
    expect(response.body).toHaveProperty('data');
    expect(Array.isArray(response.body.data)).toBe(true);
  });

  it('POST /api/products should return 401 (Unauthorized) without auth header', async () => {
    const app = await getApp();
    const response = await request(app)
      .post('/api/products')
      .send({
        name: 'New Product',
        slug: 'new-product',
        description: 'This is a long description for a product',
        price: 15000,
        stock: 10,
        sku: 'SKU-001',
        categoryId: 'ad3fa8a0-2f92-4fcf-8547-5d2524a87b0a',
      })
      .expect(401);

    expect(response.body.success).toBe(false);
  });

  it('POST /api/products should return 403 (Forbidden) for a non-admin/staff user', async () => {
    const app = await getApp();
    const customerUser = await createTestUser({ role: 'CUSTOMER' });
    const authHeader = getAuthHeader(customerUser);

    const response = await request(app)
      .post('/api/products')
      .set(authHeader)
      .send({
        name: 'New Product',
        slug: 'new-product',
        description: 'This is a long description for a product',
        price: 15000,
        stock: 10,
        sku: 'SKU-001',
        categoryId: 'ad3fa8a0-2f92-4fcf-8547-5d2524a87b0a',
      })
      .expect(403);

    expect(response.body.success).toBe(false);
    expect(response.body.message).toContain('insufficient permissions');
  });

  it('POST /api/products should return 400 (Validation Error) for invalid inputs', async () => {
    const app = await getApp();
    const adminUser = await createTestUser({ role: 'ADMIN' });
    const authHeader = getAuthHeader(adminUser);

    const response = await request(app)
      .post('/api/products')
      .set(authHeader)
      .send({
        name: 'Ab', // too short name
        slug: 'invalid slug name', // invalid characters and spaces
        description: 'short', // description must be at least 10 chars
        price: -10, // negative price
        stock: -1, // negative stock
        sku: '', // too short sku
        categoryId: 'not-a-uuid', // invalid categoryId UUID
      })
      .expect(400);

    expect(response.body.success).toBe(false);
    expect(response.body.message).toContain('Validation failed');
    expect(response.body).toHaveProperty('errors');
    expect(response.body.errors.length).toBeGreaterThan(0);
  });

  it('POST /api/products should create product successfully with valid admin auth', async () => {
    const app = await getApp();
    const adminUser = await createTestUser({ role: 'ADMIN' });
    const authHeader = getAuthHeader(adminUser);

    // Create a dummy Category first to satisfy the DB foreign key
    const category = await prisma.category.create({
      data: {
        name: 'Electronics',
        slug: 'electronics',
      },
    });

    const response = await request(app)
      .post('/api/products')
      .set(authHeader)
      .send({
        name: 'Valid Product Name',
        slug: 'valid-product-name',
        description: 'This is a long enough product description',
        price: 499000,
        stock: 50,
        sku: 'SKU-VALID-123',
        categoryId: category.id,
      })
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data).toHaveProperty('id');
    expect(response.body.data.name).toBe('Valid Product Name');
    expect(response.body.data.slug).toBe('valid-product-name');
  });
});
