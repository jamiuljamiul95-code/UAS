import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { getApp, createTestUser } from '../setup/testUtils';
import { prisma } from '../../server/config/db';

describe('Auth API', () => {
  describe('POST /api/auth/register', () => {
    it('should register a new user successfully (Success)', async () => {
      const app = await getApp();
      const email = `newuser-${Date.now()}@example.com`;

      const response = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'Jane Doe',
          email,
          password: 'securepassword',
          phone: '081234567890',
        })
        .expect('Content-Type', /json/)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('id');
      expect(response.body.data.email).toBe(email);
      expect(response.body.data.name).toBe('Jane Doe');
      expect(response.body.data).not.toHaveProperty('password'); // Password must not be returned
    });

    it('should fail with 400 when name is too short or email is invalid (Validation Error)', async () => {
      const app = await getApp();

      const response = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'J', // too short
          email: 'invalid-email',
          password: '123', // too short
        })
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Validation failed');
      expect(response.body).toHaveProperty('errors');
      expect(response.body.errors.length).toBeGreaterThan(0);
    });

    it('should return 400 when email already exists', async () => {
      const app = await getApp();
      const existingUser = await createTestUser();

      const response = await request(app)
        .post('/api/auth/register')
        .send({
          name: 'Another User',
          email: existingUser.email,
          password: 'password123',
        })
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Email is already registered');
    });
  });

  describe('POST /api/auth/login', () => {
    it('should login successfully with correct credentials (Success)', async () => {
      const app = await getApp();
      const user = await createTestUser();

      const response = await request(app)
        .post('/api/auth/login')
        .send({
          email: user.email,
          password: user.plainPassword,
        })
        .expect('Content-Type', /json/)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('token');
      expect(response.body.data.user.email).toBe(user.email);
    });

    it('should fail with 401 for incorrect password (Unauthorized / Invalid Credentials)', async () => {
      const app = await getApp();
      const user = await createTestUser();

      const response = await request(app)
        .post('/api/auth/login')
        .send({
          email: user.email,
          password: 'wrongpassword',
        })
        .expect('Content-Type', /json/)
        .expect(401);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Invalid credentials');
    });

    it('should fail with 400 for empty or invalid email (Validation Error)', async () => {
      const app = await getApp();

      const response = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'not-an-email',
          password: '',
        })
        .expect('Content-Type', /json/)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.message).toContain('Validation failed');
    });
  });
});
