# Clothing POS & E-Commerce System - SRS (Software Requirements Specification)

## 1. Introduction
This document defines the software requirements for the "Clothing POS & E-Commerce System". The system serves as a unified platform bridging physical point-of-sale operations with an online storefront for a clothing retail business.

## 2. Overall Description
The system consists of a customer-facing e-commerce application and a multi-role administrative dashboard. It handles inventory management, order processing, and user administration securely.

## 3. System Features

### 3.1 Authentication & Authorization
- Secure JWT-based authentication
- Role-based access control (CUSTOMER, CASHIER, STAFF, ADMIN, OWNER)
- Protected routes for both client-side routing and server-side API endpoints

### 3.2 E-Commerce Storefront (Customer Facing)
- **Product Catalog**: Browse all available products
- **Product Details**: View product images, description, pricing, and variants (size, color)
- **Shopping Cart**: Add, update quantities, remove items (persisted locally)
- **Checkout**: Place orders online

### 3.3 Administrative Dashboard
- **Dashboard Overview**: Key metrics and summaries
- **Point of Sale (POS)**: Interface for cashiers to process in-store transactions quickly
- **Products Management**: Add, edit, remove products and manage inventory levels
- **Categories Management**: Organize products logically
- **Orders Management**: View order details and update fulfillment statuses
- **User Management**: Administrators and owners can change user roles and view staff accounts

## 4. Technical Specifications
- **Frontend**: React 18, React Router DOM, Zustand (state), Tailwind CSS (styling), Lucide React (icons)
- **Backend**: Node.js, Express, Prisma ORM
- **Database**: PostgreSQL (currently configured for SQLite in preview, adaptable to Postgres/MySQL)
- **Architecture**: Client-Server with RESTful JSON API
- **Deployment**: Vercel/Cloud Run Ready (via configured build step bundling server and SPA)
