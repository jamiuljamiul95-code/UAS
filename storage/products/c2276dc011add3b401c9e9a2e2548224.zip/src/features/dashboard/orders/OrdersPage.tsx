import { useState, useEffect } from 'react';
import { 
  Search, Eye, Copy, Check, Calendar, ArrowRight, XCircle, 
  RefreshCw, MapPin, User as UserIcon, Phone, Mail, ChevronLeft, ChevronRight, ShoppingBag, Receipt
} from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import Modal from '../../../components/ui/Modal';
import { useToastStore } from '../../../store/useToastStore';
import api from '../../../lib/axios';

interface User {
  id: string;
  name: string;
  email: string;
  phone: string | null;
}

interface Product {
  id: string;
  name: string;
  slug: string;
}

interface ProductVariant {
  id: string;
  size: string | null;
  color: string | null;
}

interface OrderItem {
  id: string;
  productId: string;
  product: Product;
  variantId: string | null;
  variant: ProductVariant | null;
  quantity: number;
  price: number;
}

interface OrderTimeline {
  id: string;
  status: string;
  note: string | null;
  createdAt: string;
}

interface Order {
  id: string;
  userId: string;
  status: string;
  totalAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  shippingAddress: string;
  shippingCarrier: string | null;
  trackingResi: string | null;
  subtotal: number;
  discountAmount: number;
  shippingFee: number;
  taxAmount: number;
  createdAt: string;
  user: User;
  items: OrderItem[];
  timeline: OrderTimeline[];
}

interface PaginationMeta {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

const ORDER_STATUS_OPTIONS = [
  { value: 'PENDING', label: 'Menunggu Konfirmasi' },
  { value: 'WAITING_PAYMENT', label: 'Menunggu Pembayaran' },
  { value: 'PAID', label: 'Pembayaran Diterima' },
  { value: 'PROCESSING', label: 'Diproses' },
  { value: 'PACKING', label: 'Dikemas' },
  { value: 'SHIPPED', label: 'Dikirim' },
  { value: 'DELIVERED', label: 'Sampai Tujuan' },
  { value: 'COMPLETED', label: 'Selesai' },
  { value: 'CANCELLED', label: 'Dibatalkan' },
  { value: 'REFUND', label: 'Refund (Pengembalian)' }
];

export default function OrdersPage() {
  const { addToast } = useToastStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Pagination states
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [pagination, setPagination] = useState<PaginationMeta | null>(null);

  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Detail Modal & Actions State
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isDetailLoading, setIsDetailLoading] = useState(false);

  // Status update states
  const [targetStatus, setTargetStatus] = useState('');
  const [statusNote, setStatusNote] = useState('');
  const [updatingStatus, setUpdatingStatus] = useState(false);

  useEffect(() => {
    fetchOrders();
  }, [page, limit, statusFilter, startDate, endDate]);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const params: any = {
        page,
        limit,
        status: statusFilter || undefined,
        search: searchTerm || undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
      };

      const response = await api.get('/orders', { params });
      if (response.data.success) {
        setOrders(response.data.data);
        if (response.data.meta) {
          setPagination(response.data.meta as PaginationMeta);
        }
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal memuat daftar pesanan', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchOrders();
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setStatusFilter('');
    setStartDate('');
    setEndDate('');
    setPage(1);
  };

  const handleOpenDetail = async (orderId: string) => {
    setSelectedOrderId(orderId);
    setIsDetailModalOpen(true);
    setIsDetailLoading(true);
    setStatusNote('');
    setTargetStatus('');
    try {
      const response = await api.get(`/orders/${orderId}`);
      if (response.data.success) {
        const orderData = response.data.data;
        setSelectedOrder(orderData);
        setTargetStatus(orderData.status);
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal memuat detail pesanan', 'error');
      setIsDetailModalOpen(false);
    } finally {
      setIsDetailLoading(false);
    }
  };

  const handleUpdateStatusSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder || !targetStatus) return;

    setUpdatingStatus(true);
    try {
      const response = await api.patch(`/orders/${selectedOrder.id}/status`, {
        status: targetStatus,
        note: statusNote.trim() || undefined
      });

      if (response.data.success) {
        addToast(`Status pesanan berhasil diperbarui menjadi ${targetStatus}`, 'success');
        // Refresh detail
        const updated = response.data.data;
        setSelectedOrder(updated);
        setStatusNote('');
        // Refresh list
        fetchOrders();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal memperbarui status pesanan', 'error');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleCancelOrderDirectly = async () => {
    if (!selectedOrder) return;
    
    const confirmCancel = window.confirm('Apakah Anda yakin ingin membatalkan pesanan ini? Stok produk akan dikembalikan otomatis.');
    if (!confirmCancel) return;

    setUpdatingStatus(true);
    try {
      const response = await api.patch(`/orders/${selectedOrder.id}/cancel`, {
        note: 'Dibatalkan oleh Admin.'
      });

      if (response.data.success) {
        addToast('Pesanan berhasil dibatalkan dan stok dikembalikan', 'success');
        setSelectedOrder(response.data.data);
        fetchOrders();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal membatalkan pesanan', 'error');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    addToast('ID Pesanan disalin ke clipboard', 'success');
    setTimeout(() => setCopiedId(null), 2500);
  };

  const formatRupiah = (val: number) => {
    return 'Rp' + val.toLocaleString('id-ID');
  };

  const getStatusBadge = (status: string) => {
    switch (status.toUpperCase()) {
      case 'PENDING':
        return { bg: 'bg-amber-50 text-amber-700 border-amber-200', label: 'Menunggu Konfirmasi' };
      case 'WAITING_PAYMENT':
        return { bg: 'bg-yellow-50 text-yellow-700 border-yellow-200', label: 'Menunggu Pembayaran' };
      case 'PAID':
        return { bg: 'bg-blue-50 text-blue-700 border-blue-200', label: 'Pembayaran Diterima' };
      case 'PROCESSING':
        return { bg: 'bg-indigo-50 text-indigo-700 border-indigo-200', label: 'Diproses' };
      case 'PACKING':
        return { bg: 'bg-purple-50 text-purple-700 border-purple-200', label: 'Dikemas' };
      case 'SHIPPED':
        return { bg: 'bg-sky-50 text-sky-700 border-sky-200', label: 'Dikirim' };
      case 'DELIVERED':
        return { bg: 'bg-teal-50 text-teal-700 border-teal-200', label: 'Sampai Tujuan' };
      case 'COMPLETED':
        return { bg: 'bg-green-50 text-green-700 border-green-200', label: 'Selesai' };
      case 'CANCELLED':
        return { bg: 'bg-rose-50 text-rose-700 border-rose-200', label: 'Dibatalkan' };
      case 'REFUND':
        return { bg: 'bg-red-50 text-red-700 border-red-200', label: 'Refund' };
      default:
        return { bg: 'bg-slate-50 text-slate-700 border-slate-200', label: status };
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Title Header */}
      <div>
        <h1 className="text-2xl font-black tracking-tight text-slate-900 font-sans">Order Management</h1>
        <p className="text-sm text-slate-500 mt-1">Lacak transaksi, ubah status pengiriman, proses refund, dan batalkan pesanan pelanggan.</p>
      </div>

      {/* Advanced Filter Bento Bar */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          {/* Global text search */}
          <div className="md:col-span-4 space-y-1">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Pencarian Global</label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <Input
                className="pl-9 h-11 rounded-xl text-sm"
                placeholder="ID Pesanan, nama customer, email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Status Dropdown */}
          <div className="md:col-span-3 space-y-1">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status Transaksi</label>
            <select
              className="w-full bg-white border border-slate-200 rounded-xl px-3 h-11 text-sm text-slate-700 focus:ring-1 focus:ring-blue-500"
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
            >
              <option value="">Semua Status</option>
              {ORDER_STATUS_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>

          {/* Date Picker Start */}
          <div className="md:col-span-2 space-y-1">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tanggal Mulai</label>
            <input
              type="date"
              className="w-full bg-white border border-slate-200 rounded-xl px-3 h-11 text-sm text-slate-700 focus:ring-1 focus:ring-blue-500"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setPage(1);
              }}
            />
          </div>

          {/* Date Picker End */}
          <div className="md:col-span-2 space-y-1">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tanggal Akhir</label>
            <input
              type="date"
              className="w-full bg-white border border-slate-200 rounded-xl px-3 h-11 text-sm text-slate-700 focus:ring-1 focus:ring-blue-500"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setPage(1);
              }}
            />
          </div>

          {/* Submit Search & Reset buttons */}
          <div className="md:col-span-1 flex gap-2 w-full">
            <Button
              type="button"
              variant="outline"
              onClick={handleResetFilters}
              className="h-11 rounded-xl px-3 flex-1 text-xs font-bold border-slate-200 hover:bg-slate-50"
              title="Reset Filter"
            >
              Reset
            </Button>
          </div>
        </form>
      </div>

      {/* Orders Table Panel */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50/50 text-slate-400 font-bold border-b border-slate-100 uppercase text-xs tracking-wider">
              <tr>
                <th className="px-6 py-4">ID Pesanan</th>
                <th className="px-6 py-4">Pelanggan</th>
                <th className="px-6 py-4">Tanggal dibuat</th>
                <th className="px-6 py-4">Metode Bayar</th>
                <th className="px-6 py-4">Total Belanja</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <RefreshCw className="w-6 h-6 animate-spin text-blue-500" />
                      <span className="text-sm font-medium">Sedang memuat pesanan...</span>
                    </div>
                  </td>
                </tr>
              ) : orders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center gap-1.5">
                      <ShoppingBag className="w-8 h-8 text-slate-300" />
                      <p className="font-bold text-slate-600">Tidak ada pesanan ditemukan</p>
                      <p className="text-xs">Coba sesuaikan kata kunci pencarian atau bersihkan filter Anda.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                orders.map((order) => {
                  const badge = getStatusBadge(order.status);
                  return (
                    <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-xs font-semibold text-slate-900 bg-slate-50 px-2 py-1 rounded border border-slate-200/50">
                            {order.id.slice(0, 8)}...
                          </span>
                          <button
                            onClick={() => handleCopyId(order.id)}
                            className="text-slate-400 hover:text-blue-500 p-0.5"
                            title="Salin ID Pesanan Lengkap"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-semibold text-slate-800">{order.user.name}</p>
                          <p className="text-xs text-slate-400 truncate max-w-44">{order.user.email}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-500">
                        {new Date(order.createdAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider bg-slate-100 px-2 py-0.5 rounded border border-slate-200/50">
                          {order.paymentMethod}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-bold text-slate-900">
                        {formatRupiah(order.totalAmount)}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${badge.bg}`}>
                          <span className="w-1.5 h-1.5 rounded-full bg-current shrink-0" />
                          {badge.label}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenDetail(order.id)}
                          className="h-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50 flex items-center gap-1 rounded-lg"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Detail
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Toolbar */}
        {pagination && pagination.totalPages > 1 && (
          <div className="p-4 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-slate-500">
            <div className="flex items-center gap-2">
              <span>Tampilkan</span>
              <select
                className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-700 font-semibold focus:ring-1 focus:ring-blue-500"
                value={limit}
                onChange={(e) => {
                  setLimit(parseInt(e.target.value));
                  setPage(1);
                }}
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
              <span>dari {pagination.total} pesanan</span>
            </div>

            <div className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                className="h-8 rounded-lg px-2 text-slate-600"
                disabled={page === 1}
                onClick={() => setPage(p => Math.max(1, p - 1))}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((p) => (
                <Button
                  key={p}
                  variant={p === page ? 'default' : 'outline'}
                  size="sm"
                  className={`h-8 w-8 rounded-lg p-0 font-semibold text-xs ${
                    p === page ? 'shadow-md shadow-blue-100' : 'text-slate-600'
                  }`}
                  onClick={() => setPage(p)}
                >
                  {p}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                className="h-8 rounded-lg px-2 text-slate-600"
                disabled={page === pagination.totalPages}
                onClick={() => setPage(p => Math.min(pagination.totalPages, p + 1))}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* --- MASTERCLASS ORDER DETAIL MODAL --- */}
      <Modal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        title="Detail Pesanan & Pelacakan"
        size="xl"
      >
        {isDetailLoading ? (
          <div className="py-20 text-center text-slate-400 space-y-3">
            <RefreshCw className="w-8 h-8 animate-spin text-blue-500 mx-auto" />
            <p className="text-sm font-semibold text-slate-600">Mengambil detail pesanan secara realtime...</p>
          </div>
        ) : selectedOrder ? (
          <div className="space-y-6">
            {/* Header Status Bar */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-50 border border-slate-200/60 rounded-2xl p-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">ID Pesanan:</span>
                  <span className="font-mono text-sm font-black text-slate-800 bg-white px-2.5 py-0.5 rounded border border-slate-200">
                    {selectedOrder.id}
                  </span>
                  <button
                    onClick={() => handleCopyId(selectedOrder.id)}
                    className="p-1 hover:bg-slate-200 rounded text-slate-400 hover:text-blue-500 transition-colors"
                    title="Salin ID Lengkap"
                  >
                    {copiedId === selectedOrder.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="text-xs text-slate-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  Dibuat pada {new Date(selectedOrder.createdAt).toLocaleString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              </div>

              <div>
                <span className={`inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold border shadow-xs ${getStatusBadge(selectedOrder.status).bg}`}>
                  <span className="w-2 h-2 rounded-full bg-current" />
                  {getStatusBadge(selectedOrder.status).label}
                </span>
              </div>
            </div>

            {/* Layout Columns */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Items & Timeline */}
              <div className="lg:col-span-7 space-y-6">
                {/* Product List Card */}
                <div className="bg-white border border-slate-150 rounded-2xl p-5 space-y-4">
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
                    <ShoppingBag className="w-4.5 h-4.5 text-blue-500" />
                    Daftar Item Belanja
                  </h3>

                  <div className="divide-y divide-slate-100 max-h-[280px] overflow-y-auto pr-1">
                    {selectedOrder.items.map((item) => (
                      <div key={item.id} className="py-3 flex justify-between gap-4 first:pt-0 last:pb-0">
                        <div className="space-y-0.5">
                          <p className="font-bold text-slate-800 text-sm leading-snug">{item.product.name}</p>
                          {item.variant && (
                            <p className="text-xs text-slate-500 font-semibold bg-slate-50 inline-block px-1.5 py-0.5 rounded border border-slate-200/50">
                              Varian: {[item.variant.size, item.variant.color].filter(Boolean).join(' - ')}
                            </p>
                          )}
                          <p className="text-xs text-slate-400 font-semibold font-mono">
                            {item.quantity} x {formatRupiah(item.price)}
                          </p>
                        </div>
                        <span className="font-black text-slate-900 text-sm text-right whitespace-nowrap self-center">
                          {formatRupiah(item.quantity * item.price)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status Timeline Card */}
                <div className="bg-white border border-slate-150 rounded-2xl p-5 space-y-4">
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
                    <Calendar className="w-4.5 h-4.5 text-indigo-500" />
                    Timeline Perubahan Status
                  </h3>

                  <div className="relative pl-6 space-y-4 before:absolute before:left-2 before:top-1.5 before:bottom-1.5 before:w-0.5 before:bg-slate-100">
                    {selectedOrder.timeline.length === 0 ? (
                      <div className="text-xs text-slate-400 italic">Pesanan baru dibuat, belum ada histori log status.</div>
                    ) : (
                      selectedOrder.timeline.map((log, index) => {
                        const isLatest = index === selectedOrder.timeline.length - 1;
                        const badgeInfo = getStatusBadge(log.status);
                        return (
                          <div key={log.id} className="relative space-y-1">
                            {/* Bullet dot */}
                            <span className={`absolute -left-[22px] top-1.5 w-2.5 h-2.5 rounded-full border-2 bg-white ${
                              isLatest ? 'border-blue-500 shadow-xs' : 'border-slate-300'
                            }`} />
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                              <span className={`text-xs font-bold ${isLatest ? 'text-blue-600' : 'text-slate-700'}`}>
                                {badgeInfo.label}
                              </span>
                              <span className="font-mono text-[10px] text-slate-400">
                                {new Date(log.createdAt).toLocaleString('id-ID', {
                                  day: 'numeric',
                                  month: 'short',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </span>
                            </div>
                            {log.note && (
                              <p className="text-xs text-slate-500 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                                {log.note}
                              </p>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column: Customer info, Financials, & Admin Controls */}
              <div className="lg:col-span-5 space-y-6">
                {/* Customer Details Card */}
                <div className="bg-white border border-slate-150 rounded-2xl p-5 space-y-4">
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
                    <UserIcon className="w-4.5 h-4.5 text-sky-500" />
                    Informasi Penerima & Alamat
                  </h3>

                  <div className="space-y-3.5 text-xs">
                    <div className="space-y-1.5">
                      <p className="font-bold text-slate-800 text-sm">{selectedOrder.user.name}</p>
                      <div className="space-y-1 text-slate-500">
                        <div className="flex items-center gap-2">
                          <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{selectedOrder.user.email}</span>
                        </div>
                        {selectedOrder.user.phone && (
                          <div className="flex items-center gap-2">
                            <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span>{selectedOrder.user.phone}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-3 space-y-1.5">
                      <p className="font-bold text-slate-700 flex items-center gap-1.5 text-2xs uppercase tracking-wider">
                        <MapPin className="w-3.5 h-3.5 text-rose-500" />
                        Alamat Pengiriman
                      </p>
                      <p className="text-slate-600 leading-relaxed font-sans whitespace-pre-line">
                        {selectedOrder.shippingAddress}
                      </p>
                      {selectedOrder.shippingCarrier && (
                        <div className="pt-1 text-2xs text-slate-500 font-semibold uppercase tracking-wider">
                          Kurir: <span className="font-bold text-slate-800">{selectedOrder.shippingCarrier}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Financial Breakdowns */}
                <div className="bg-white border border-slate-150 rounded-2xl p-5 space-y-3">
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
                    <Receipt className="w-4.5 h-4.5 text-emerald-500" />
                    Rincian Pembayaran ({selectedOrder.paymentMethod})
                  </h3>

                  <div className="space-y-2 text-xs text-slate-600">
                    <div className="flex justify-between">
                      <span>Subtotal Belanja</span>
                      <span className="font-semibold text-slate-800">{formatRupiah(selectedOrder.subtotal)}</span>
                    </div>
                    {selectedOrder.discountAmount > 0 && (
                      <div className="flex justify-between text-rose-600">
                        <span>Potongan Voucher</span>
                        <span className="font-semibold">- {formatRupiah(selectedOrder.discountAmount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Ongkos Kirim</span>
                      <span className="font-semibold text-slate-800">{formatRupiah(selectedOrder.shippingFee)}</span>
                    </div>
                    {selectedOrder.taxAmount > 0 && (
                      <div className="flex justify-between">
                        <span>Pajak (PPN 11%)</span>
                        <span className="font-semibold text-slate-800">{formatRupiah(selectedOrder.taxAmount)}</span>
                      </div>
                    )}
                    <div className="border-t border-slate-100 pt-2 flex justify-between items-center">
                      <span className="font-bold text-slate-800">Total Pembayaran</span>
                      <span className="font-black text-base text-blue-600">{formatRupiah(selectedOrder.totalAmount)}</span>
                    </div>
                    <div className="flex justify-between text-2xs bg-slate-50 px-2 py-1.5 rounded border border-slate-150 font-bold uppercase tracking-wider mt-1">
                      <span>Status Pembayaran:</span>
                      <span className={selectedOrder.paymentStatus === 'PAID' ? 'text-green-600' : 'text-amber-600'}>
                        {selectedOrder.paymentStatus === 'PAID' ? 'LUNAS / PAID' : selectedOrder.paymentStatus}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Administrative Status Modification Panel */}
                <div className="bg-white border border-slate-150 rounded-2xl p-5 space-y-4">
                  <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2 border-b border-slate-100 pb-3">
                    <RefreshCw className="w-4.5 h-4.5 text-orange-500 animate-pulse" />
                    Kontrol & Update Status
                  </h3>

                  <form onSubmit={handleUpdateStatusSubmit} className="space-y-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Ubah Status Ke</label>
                      <select
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 h-10 text-xs text-slate-700 font-semibold focus:ring-1 focus:ring-blue-500"
                        value={targetStatus}
                        onChange={(e) => setTargetStatus(e.target.value)}
                        disabled={selectedOrder.status === 'CANCELLED' || selectedOrder.status === 'COMPLETED'}
                      >
                        {ORDER_STATUS_OPTIONS.map(opt => (
                          <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Catatan Perubahan (Opsional)</label>
                      <textarea
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 min-h-16 focus:ring-1 focus:ring-blue-500"
                        placeholder="Contoh: Nomor Resi JNE: JNE1234567, Pembayaran valid via bank transfer..."
                        value={statusNote}
                        onChange={(e) => setStatusNote(e.target.value)}
                        disabled={selectedOrder.status === 'CANCELLED' || selectedOrder.status === 'COMPLETED'}
                      />
                    </div>

                    <div className="flex gap-2">
                      {/* Cancel Order Button */}
                      {(selectedOrder.status === 'PENDING' || selectedOrder.status === 'WAITING_PAYMENT') && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={handleCancelOrderDirectly}
                          disabled={updatingStatus}
                          className="flex-1 rounded-xl text-xs font-bold border-rose-200 text-rose-600 hover:bg-rose-50 hover:text-rose-700 h-10 flex items-center justify-center gap-1 shrink-0"
                        >
                          <XCircle className="w-4 h-4" />
                          Batalkan
                        </Button>
                      )}

                      <Button
                        type="submit"
                        disabled={updatingStatus || selectedOrder.status === 'CANCELLED' || selectedOrder.status === 'COMPLETED' || selectedOrder.status === targetStatus}
                        className="flex-1 rounded-xl text-xs font-black h-10"
                      >
                        {updatingStatus ? 'Menyimpan...' : 'Perbarui Status'}
                      </Button>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex justify-end pt-4 border-t border-slate-100">
              <Button
                variant="outline"
                onClick={() => setIsDetailModalOpen(false)}
                className="rounded-xl px-5 text-xs font-bold"
              >
                Tutup Detail
              </Button>
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
