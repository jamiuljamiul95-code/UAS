import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Search, Check, X, AlertCircle } from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import api from '../../../lib/axios';

interface Category {
  id: string;
  name: string;
  slug: string;
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  // In-app dialog & feedback states
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await api.get('/categories');
      if (response.data.success) {
        setCategories(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch categories', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName) return;
    setErrorMsg(null);
    setSaving(true);
    
    try {
      const slug = newCategoryName.toLowerCase().replace(/[\s_]+/g, '-').replace(/[^\w-]+/g, '');
      
      if (editingCategory) {
        const response = await api.put(`/categories/${editingCategory.id}`, { name: newCategoryName, slug });
        if (response.data.success) {
          setCategories(categories.map(c => c.id === editingCategory.id ? response.data.data : c));
          setNewCategoryName('');
          setEditingCategory(null);
          setIsModalOpen(false);
          setSuccessMsg('Category updated successfully');
          setTimeout(() => setSuccessMsg(null), 3000);
        }
      } else {
        const response = await api.post('/categories', { name: newCategoryName, slug });
        if (response.data.success) {
          setCategories([...categories, response.data.data]);
          setNewCategoryName('');
          setIsModalOpen(false);
          setSuccessMsg('Category created successfully');
          setTimeout(() => setSuccessMsg(null), 3000);
        }
      }
    } catch (error: any) {
      console.error('Failed to save category', error);
      setErrorMsg(error.response?.data?.message || 'Failed to save category');
    } finally {
      setSaving(false);
    }
  };

  const startEdit = (category: Category) => {
    setErrorMsg(null);
    setEditingCategory(category);
    setNewCategoryName(category.name);
    setIsModalOpen(true);
  };

  const startAdd = () => {
    setErrorMsg(null);
    setEditingCategory(null);
    setNewCategoryName('');
    setIsModalOpen(true);
  };

  const confirmDelete = (category: Category) => {
    setErrorMsg(null);
    setCategoryToDelete(category);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (!categoryToDelete) return;
    setErrorMsg(null);
    setSaving(true);
    
    try {
      const response = await api.delete(`/categories/${categoryToDelete.id}`);
      if (response.data.success) {
        setCategories(categories.filter(c => c.id !== categoryToDelete.id));
        setCategoryToDelete(null);
        setIsDeleteModalOpen(false);
        setSuccessMsg('Category deleted successfully');
        setTimeout(() => setSuccessMsg(null), 3000);
      }
    } catch (error: any) {
      console.error('Failed to delete category', error);
      setErrorMsg(error.response?.data?.message || 'Failed to delete category');
    } finally {
      setSaving(false);
    }
  };

  const filteredCategories = categories.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Categories</h1>
          <p className="text-sm text-slate-500 mt-1">Manage product categories for your store.</p>
        </div>
        <Button className="gap-2" onClick={startAdd}>
          <Plus className="w-4 h-4" />
          Add Category
        </Button>
      </div>

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm transition-all flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span className="font-medium">{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-500 hover:text-emerald-700 transition-colors focus:outline-none cursor-pointer" aria-label="Close success banner">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorMsg && !isModalOpen && !isDeleteModalOpen && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-sm transition-all flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span className="font-medium">{errorMsg}</span>
          </div>
          <button onClick={() => setErrorMsg(null)} className="text-rose-500 hover:text-rose-700 transition-colors focus:outline-none cursor-pointer" aria-label="Close error banner">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input 
              className="pl-10" 
              placeholder="Search categories..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4">Slug</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={3} className="px-6 py-8 text-center text-slate-500">
                    Loading categories...
                  </td>
                </tr>
              ) : filteredCategories.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-6 py-8 text-center text-slate-500">
                    No categories found.
                  </td>
                </tr>
              ) : (
                filteredCategories.map((category) => (
                  <tr key={category.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-slate-900">{category.name}</td>
                    <td className="px-6 py-4 text-slate-600">{category.slug}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-600" onClick={() => startEdit(category)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50" onClick={() => confirmDelete(category)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Category Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200">
              <h3 className="text-lg font-bold text-slate-900">
                {editingCategory ? 'Edit Category' : 'Add New Category'}
              </h3>
            </div>
            <form onSubmit={handleSubmit} className="p-6">
              {errorMsg && (
                <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                  <button type="button" onClick={() => setErrorMsg(null)} className="text-rose-600 hover:text-rose-800 focus:outline-none ml-2 cursor-pointer" aria-label="Close error message">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Category Name</label>
                  <Input 
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    placeholder="e.g. T-Shirts"
                    required
                    disabled={saving}
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)} disabled={saving}>Cancel</Button>
                <Button type="submit" disabled={saving}>
                  {saving ? 'Saving...' : (editingCategory ? 'Save Changes' : 'Create Category')}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom Delete Confirmation Modal */}
      {isDeleteModalOpen && categoryToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200">
              <h3 className="text-lg font-bold text-slate-900">Delete Category</h3>
            </div>
            <div className="p-6">
              {errorMsg && (
                <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                  <button type="button" onClick={() => setErrorMsg(null)} className="text-rose-600 hover:text-rose-800 focus:outline-none ml-2 cursor-pointer" aria-label="Close error message">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
              <p className="text-slate-600 text-sm">
                Are you sure you want to delete the category <strong className="text-slate-900">"{categoryToDelete.name}"</strong>? This action cannot be undone.
              </p>
              <div className="mt-6 flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setIsDeleteModalOpen(false)} disabled={saving}>Cancel</Button>
                <Button variant="ghost" className="bg-red-600 text-white hover:bg-red-700 hover:text-white" onClick={handleDelete} disabled={saving}>
                  {saving ? 'Deleting...' : 'Delete Category'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

