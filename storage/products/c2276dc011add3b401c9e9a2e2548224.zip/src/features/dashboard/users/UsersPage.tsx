import { useState, useEffect } from 'react';
import { 
  Search, Shield, Plus, Trash2, Edit, Eye, UserCheck, UserX, 
  Calendar, ChevronLeft, ChevronRight, Coins, ShoppingCart, 
  MapPin, SlidersHorizontal, RefreshCw, X 
} from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import api from '../../../lib/axios';
import { useToastStore } from '../../../store/useToastStore';
import { useAuthStore } from '../../../store/useAuthStore';
import Modal from '../../../components/ui/Modal';
import ConfirmationDialog from '../../../components/ui/ConfirmationDialog';
import { TableSkeleton } from '../../../components/ui/Skeleton';

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  phone: string | null;
  status: string;
  avatar: string | null;
  dob: string | null;
  gender: string | null;
  createdAt: string;
}

interface Address {
  id: string;
  title: string;
  recipientName: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  postalCode: string;
  address: string;
  notes: string | null;
  isDefault: boolean;
}

interface UserDetail extends User {
  addresses: Address[];
  orderCount: number;
  totalSpent: number;
}

export default function UsersPage() {
  const { addToast } = useToastStore();
  const currentUser = useAuthStore(state => state.user);

  // States
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalItems, setTotalItems] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  
  // Filters & Search
  const [search, setSearch] = useState('');
  const [role, setRole] = useState('all');
  const [status, setStatus] = useState('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [sortBy, setSortBy] = useState('newest');

  // Modals & Dialogs States
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
  
  // Selected user data
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [userDetail, setUserDetail] = useState<UserDetail | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  // Form Fields State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    role: 'CUSTOMER',
    status: 'ACTIVE',
    dob: '',
    gender: '',
    avatar: '',
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, [page, limit, role, status, startDate, endDate, sortBy]);

  // Debounced Search
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchUsers();
    }, 400);
    return () => clearTimeout(timer);
  }, [search]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await api.get('/users', {
        params: {
          page,
          limit,
          search: search || undefined,
          role: role !== 'all' ? role : undefined,
          status: status !== 'all' ? status : undefined,
          startDate: startDate || undefined,
          endDate: endDate || undefined,
          sortBy,
        }
      });
      if (response.data.success) {
        setUsers(response.data.data);
        if (response.data.meta) {
          setTotalItems(response.data.meta.totalItems);
          setTotalPages(response.data.meta.totalPages);
        }
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to fetch users', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleResetFilters = () => {
    setSearch('');
    setRole('all');
    setStatus('all');
    setStartDate('');
    setEndDate('');
    setSortBy('newest');
    setPage(1);
    addToast('Filters reset successfully', 'info');
  };

  // Open Details Modal
  const handleOpenDetail = async (user: User) => {
    setSelectedUser(user);
    setIsDetailModalOpen(true);
    setLoadingDetail(true);
    setUserDetail(null);
    try {
      const response = await api.get(`/users/${user.id}`);
      if (response.data.success) {
        setUserDetail(response.data.data);
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to fetch user details', 'error');
      setIsDetailModalOpen(false);
    } finally {
      setLoadingDetail(false);
    }
  };

  // Handle Form Input Changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  // Validate form matching Zod validator requirements
  const validateForm = (isEdit: boolean) => {
    const errors: Record<string, string> = {};
    if (!formData.name || formData.name.length < 3) {
      errors.name = 'Name must be at least 3 characters';
    }
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Invalid email address';
    }
    if (!isEdit && (!formData.password || formData.password.length < 6)) {
      errors.password = 'Password must be at least 6 characters';
    }
    if (isEdit && formData.password && formData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }
    if (formData.phone && formData.phone.length < 8) {
      errors.phone = 'Phone number must be at least 8 digits';
    }
    if (formData.dob && !/^\d{4}-\d{2}-\d{2}$/.test(formData.dob)) {
      errors.dob = 'Date of birth must be in YYYY-MM-DD format';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Open Create Modal
  const handleOpenCreate = () => {
    setFormData({
      name: '',
      email: '',
      password: '',
      phone: '',
      role: 'CUSTOMER',
      status: 'ACTIVE',
      dob: '',
      gender: '',
      avatar: '',
    });
    setFormErrors({});
    setIsCreateModalOpen(true);
  };

  // Submit Create Customer
  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm(false)) return;

    setIsSubmitting(true);
    try {
      const response = await api.post('/users', {
        ...formData,
        phone: formData.phone || undefined,
        dob: formData.dob || undefined,
        gender: formData.gender || undefined,
        avatar: formData.avatar || undefined,
      });
      if (response.data.success) {
        addToast('Customer created successfully', 'success');
        setIsCreateModalOpen(false);
        fetchUsers();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to create customer', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Open Edit Modal
  const handleOpenEdit = (user: User) => {
    setSelectedUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      password: '', // Keep empty unless updating password
      phone: user.phone || '',
      role: user.role,
      status: user.status,
      dob: user.dob || '',
      gender: user.gender || '',
      avatar: user.avatar || '',
    });
    setFormErrors({});
    setIsEditModalOpen(true);
  };

  // Submit Edit Customer
  const handleEditCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;
    if (!validateForm(true)) return;

    setIsSubmitting(true);
    try {
      const payload: any = {
        name: formData.name,
        email: formData.email,
        phone: formData.phone || null,
        role: formData.role,
        status: formData.status,
        dob: formData.dob || null,
        gender: formData.gender || null,
        avatar: formData.avatar || null,
      };

      if (formData.password) {
        payload.password = formData.password;
      }

      const response = await api.put(`/users/${selectedUser.id}`, payload);
      if (response.data.success) {
        addToast('Customer updated successfully', 'success');
        setIsEditModalOpen(false);
        fetchUsers();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to update customer', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Toggle Status directly from table
  const handleToggleStatus = async (user: User) => {
    const newStatus = user.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    try {
      const response = await api.patch(`/users/${user.id}/status`, { status: newStatus });
      if (response.data.success) {
        addToast(`Customer status updated to ${newStatus}`, 'success');
        setUsers(users.map(u => u.id === user.id ? { ...u, status: newStatus } : u));
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to update customer status', 'error');
    }
  };

  // Open Delete Dialog
  const handleOpenDelete = (user: User) => {
    if (user.id === currentUser?.id) {
      addToast('You cannot delete your own account', 'warning');
      return;
    }
    setSelectedUser(user);
    setIsConfirmDeleteOpen(true);
  };

  // Submit Delete User
  const handleDeleteConfirm = async () => {
    if (!selectedUser) return;
    setIsSubmitting(true);
    try {
      const response = await api.delete(`/users/${selectedUser.id}`);
      if (response.data.success) {
        addToast('Customer deleted successfully', 'success');
        setIsConfirmDeleteOpen(false);
        fetchUsers();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Cannot delete: user has transactions.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 font-sans">Customer & User Management</h1>
          <p className="text-sm text-slate-500 mt-1">Manage, search, filter and audit all user accounts and shipping addresses.</p>
        </div>
        <Button 
          onClick={handleOpenCreate}
          className="rounded-xl flex items-center gap-2 shadow-sm font-semibold h-11"
        >
          <Plus className="w-5 h-5" />
          Add Customer
        </Button>
      </div>

      {/* Search and Filters Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-4">
        {/* Search & Reset */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input 
              className="pl-10 h-11 rounded-xl border-slate-200 focus:border-blue-500" 
              placeholder="Search by Name, Email, or Phone..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-3">
            <select
              className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-medium text-slate-700 h-11 focus:outline-none focus:ring-1 focus:ring-blue-500"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="newest">Newest Registered</option>
              <option value="oldest">Oldest Registered</option>
              <option value="name">Name (A-Z)</option>
              <option value="email">Email (A-Z)</option>
            </select>
            <Button
              variant="outline"
              onClick={handleResetFilters}
              className="rounded-xl flex items-center gap-2 text-slate-600 border-slate-200 hover:bg-slate-50 h-11"
            >
              <RefreshCw className="w-4 h-4" />
              Reset
            </Button>
          </div>
        </div>

        {/* Detailed Filters (Collapsible in design but layout-clean directly shown) */}
        <div className="pt-2 border-t border-slate-50 flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Filters:</span>
          </div>

          {/* Role Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Role:</span>
            <select
              className="bg-slate-50 border border-slate-100 rounded-lg px-2 py-1 text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
              value={role}
              onChange={(e) => { setRole(e.target.value); setPage(1); }}
            >
              <option value="all">All Roles</option>
              <option value="CUSTOMER">Customer</option>
              <option value="CASHIER">Cashier</option>
              <option value="STAFF">Staff</option>
              <option value="ADMIN">Admin</option>
              <option value="OWNER">Owner</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Status:</span>
            <select
              className="bg-slate-50 border border-slate-100 rounded-lg px-2 py-1 text-xs font-medium text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
              value={status}
              onChange={(e) => { setStatus(e.target.value); setPage(1); }}
            >
              <option value="all">All Status</option>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>

          {/* Registration Date Filter */}
          <div className="flex items-center gap-2 text-xs text-slate-500 ml-auto flex-wrap">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>Join Date:</span>
            <input 
              type="date"
              className="bg-slate-50 border border-slate-100 rounded-lg px-2 py-1 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-700"
              value={startDate}
              onChange={(e) => { setStartDate(e.target.value); setPage(1); }}
            />
            <span>to</span>
            <input 
              type="date"
              className="bg-slate-50 border border-slate-100 rounded-lg px-2 py-1 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-blue-500 text-slate-700"
              value={endDate}
              onChange={(e) => { setEndDate(e.target.value); setPage(1); }}
            />
          </div>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50/75 border-b border-slate-100 text-slate-500 font-semibold tracking-wider text-xs uppercase">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Phone Number</th>
                <th className="px-6 py-4">Role</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Joined Date</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <TableSkeleton rows={limit} cols={6} />
              ) : users.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                    No customers found matching your criteria.
                  </td>
                </tr>
              ) : (
                users.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        {user.avatar ? (
                          <img 
                            src={user.avatar} 
                            alt={user.name} 
                            className="w-10 h-10 rounded-full object-cover border border-slate-100"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-sm uppercase">
                            {user.name.charAt(0)}
                          </div>
                        )}
                        <div>
                          <p className="font-semibold text-slate-900">{user.name}</p>
                          <p className="text-xs text-slate-400 font-mono">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-600 font-mono">
                      {user.phone || <span className="text-slate-300">-</span>}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                        user.role === 'OWNER' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' :
                        user.role === 'ADMIN' ? 'bg-blue-50 text-blue-700 border border-blue-100' :
                        user.role === 'STAFF' ? 'bg-amber-50 text-amber-700 border border-amber-100' :
                        user.role === 'CASHIER' ? 'bg-teal-50 text-teal-700 border border-teal-100' :
                        'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}>
                        <Shield className="w-3 h-3 shrink-0" />
                        {user.role}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => handleToggleStatus(user)}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold cursor-pointer transition-all border ${
                          user.status === 'ACTIVE' 
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-100 hover:bg-emerald-100' 
                            : 'bg-rose-50 text-rose-700 border-rose-100 hover:bg-rose-100'
                        }`}
                        title="Click to toggle status"
                      >
                        {user.status === 'ACTIVE' ? <UserCheck className="w-3.5 h-3.5" /> : <UserX className="w-3.5 h-3.5" />}
                        {user.status}
                      </button>
                    </td>
                    <td className="px-6 py-4 text-slate-500 font-mono text-xs">
                      {new Date(user.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenDetail(user)}
                          className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-700 transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(user)}
                          className="p-1.5 hover:bg-slate-100 rounded-lg text-blue-500 hover:text-blue-700 transition-colors"
                          title="Edit Customer"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenDelete(user)}
                          disabled={user.id === currentUser?.id}
                          className="p-1.5 hover:bg-red-50 rounded-lg text-red-500 hover:text-red-700 transition-colors disabled:opacity-40"
                          title="Delete Customer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table Pagination footer */}
        <div className="bg-slate-50/70 border-t border-slate-100 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Rows per page:</span>
            <select
              className="bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs font-semibold text-slate-700 focus:outline-none"
              value={limit}
              onChange={(e) => { setLimit(parseInt(e.target.value, 10)); setPage(1); }}
            >
              <option value="10">10</option>
              <option value="20">20</option>
              <option value="50">50</option>
              <option value="100">100</option>
            </select>
            <span className="text-xs text-slate-400 font-mono ml-2">Total: {totalItems} items</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-xs font-mono text-slate-500">Page {page} of {totalPages}</span>
            <div className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                className="rounded-lg border-slate-200 p-2"
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="rounded-lg border-slate-200 p-2"
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* --- CREATE MODAL --- */}
      <Modal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} title="Create Customer" size="lg">
        <form onSubmit={handleCreateCustomer} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Full Name *</label>
              <Input
                name="name"
                className={`rounded-xl ${formErrors.name ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="Jane Doe"
                value={formData.name}
                onChange={handleInputChange}
                required
              />
              {formErrors.name && <p className="text-xs text-rose-500">{formErrors.name}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Email Address *</label>
              <Input
                name="email"
                type="email"
                className={`rounded-xl ${formErrors.email ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="jane@example.com"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
              {formErrors.email && <p className="text-xs text-rose-500">{formErrors.email}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Password *</label>
              <Input
                name="password"
                type="password"
                className={`rounded-xl ${formErrors.password ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="Password (min 6 chars)"
                value={formData.password}
                onChange={handleInputChange}
                required
              />
              {formErrors.password && <p className="text-xs text-rose-500">{formErrors.password}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Phone Number</label>
              <Input
                name="phone"
                className={`rounded-xl ${formErrors.phone ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="0812345678"
                value={formData.phone}
                onChange={handleInputChange}
              />
              {formErrors.phone && <p className="text-xs text-rose-500">{formErrors.phone}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Role</label>
              <select
                name="role"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 h-10 focus:ring-1 focus:ring-blue-500"
                value={formData.role}
                onChange={handleInputChange}
              >
                <option value="CUSTOMER">Customer</option>
                <option value="CASHIER">Cashier</option>
                <option value="STAFF">Staff</option>
                <option value="ADMIN">Admin</option>
                <option value="OWNER">Owner</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</label>
              <select
                name="status"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 h-10 focus:ring-1 focus:ring-blue-500"
                value={formData.status}
                onChange={handleInputChange}
              >
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Date of Birth</label>
              <Input
                name="dob"
                type="date"
                className={`rounded-xl ${formErrors.dob ? 'border-rose-500' : 'border-slate-200'}`}
                value={formData.dob}
                onChange={handleInputChange}
              />
              {formErrors.dob && <p className="text-xs text-rose-500">{formErrors.dob}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Gender</label>
              <select
                name="gender"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 h-10 focus:ring-1 focus:ring-blue-500"
                value={formData.gender}
                onChange={handleInputChange}
              >
                <option value="">Select Gender</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Avatar / Profile Picture URL</label>
              <Input
                name="avatar"
                className="rounded-xl border-slate-200"
                placeholder="https://images.unsplash.com/photo-..."
                value={formData.avatar}
                onChange={handleInputChange}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <Button type="button" variant="outline" onClick={() => setIsCreateModalOpen(false)} disabled={isSubmitting} className="rounded-xl">
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting} className="rounded-xl min-w-28">
              {isSubmitting ? 'Creating...' : 'Create Account'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* --- EDIT MODAL --- */}
      <Modal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} title="Edit Customer" size="lg">
        <form onSubmit={handleEditCustomer} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Full Name *</label>
              <Input
                name="name"
                className={`rounded-xl ${formErrors.name ? 'border-rose-500' : 'border-slate-200'}`}
                value={formData.name}
                onChange={handleInputChange}
                required
              />
              {formErrors.name && <p className="text-xs text-rose-500">{formErrors.name}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Email Address *</label>
              <Input
                name="email"
                type="email"
                className={`rounded-xl ${formErrors.email ? 'border-rose-500' : 'border-slate-200'}`}
                value={formData.email}
                onChange={handleInputChange}
                required
              />
              {formErrors.email && <p className="text-xs text-rose-500">{formErrors.email}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">New Password (Optional)</label>
              <Input
                name="password"
                type="password"
                className={`rounded-xl ${formErrors.password ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="Leave blank to keep current"
                value={formData.password}
                onChange={handleInputChange}
              />
              {formErrors.password && <p className="text-xs text-rose-500">{formErrors.password}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Phone Number</label>
              <Input
                name="phone"
                className={`rounded-xl ${formErrors.phone ? 'border-rose-500' : 'border-slate-200'}`}
                value={formData.phone}
                onChange={handleInputChange}
              />
              {formErrors.phone && <p className="text-xs text-rose-500">{formErrors.phone}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Role</label>
              <select
                name="role"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 h-10 focus:ring-1 focus:ring-blue-500"
                value={formData.role}
                onChange={handleInputChange}
              >
                <option value="CUSTOMER">Customer</option>
                <option value="CASHIER">Cashier</option>
                <option value="STAFF">Staff</option>
                <option value="ADMIN">Admin</option>
                <option value="OWNER">Owner</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Status</label>
              <select
                name="status"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 h-10 focus:ring-1 focus:ring-blue-500"
                value={formData.status}
                onChange={handleInputChange}
              >
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Date of Birth</label>
              <Input
                name="dob"
                type="date"
                className={`rounded-xl ${formErrors.dob ? 'border-rose-500' : 'border-slate-200'}`}
                value={formData.dob}
                onChange={handleInputChange}
              />
              {formErrors.dob && <p className="text-xs text-rose-500">{formErrors.dob}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Gender</label>
              <select
                name="gender"
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 h-10 focus:ring-1 focus:ring-blue-500"
                value={formData.gender}
                onChange={handleInputChange}
              >
                <option value="">Select Gender</option>
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Avatar / Profile Picture URL</label>
              <Input
                name="avatar"
                className="rounded-xl border-slate-200"
                value={formData.avatar}
                onChange={handleInputChange}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <Button type="button" variant="outline" onClick={() => setIsEditModalOpen(false)} disabled={isSubmitting} className="rounded-xl">
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting} className="rounded-xl min-w-28">
              {isSubmitting ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* --- CUSTOMER DETAIL MODAL --- */}
      <Modal isOpen={isDetailModalOpen} onClose={() => setIsDetailModalOpen(false)} title="Customer Detailed Profile" size="lg">
        {loadingDetail ? (
          <div className="space-y-6 py-4">
            <div className="flex items-center gap-4 animate-pulse">
              <div className="w-16 h-16 bg-slate-100 rounded-full" />
              <div className="space-y-2 flex-1">
                <div className="h-5 bg-slate-100 rounded w-1/3" />
                <div className="h-4 bg-slate-100 rounded w-1/2" />
              </div>
            </div>
            <div className="h-28 bg-slate-50 rounded-2xl animate-pulse" />
          </div>
        ) : !userDetail ? (
          <p className="text-center text-slate-400 py-6">Could not load customer detailed statistics.</p>
        ) : (
          <div className="space-y-6">
            {/* Header Section */}
            <div className="flex items-center gap-4">
              {userDetail.avatar ? (
                <img 
                  src={userDetail.avatar} 
                  alt={userDetail.name} 
                  className="w-16 h-16 rounded-full object-cover border border-slate-100"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-2xl uppercase">
                  {userDetail.name.charAt(0)}
                </div>
              )}
              <div>
                <h4 className="text-xl font-bold text-slate-900">{userDetail.name}</h4>
                <p className="text-sm text-slate-500 font-mono">{userDetail.email}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-semibold">{userDetail.role}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-md font-semibold ${
                    userDetail.status === 'ACTIVE' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                  }`}>{userDetail.status}</span>
                </div>
              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-4 bg-slate-50/75 p-4 rounded-2xl border border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
                  <ShoppingCart className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Total Transactions</p>
                  <p className="text-lg font-bold text-slate-900 font-mono">{userDetail.orderCount} Orders</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Total Amount Spent</p>
                  <p className="text-lg font-bold text-slate-900 font-mono">
                    Rp {userDetail.totalSpent.toLocaleString('id-ID')}
                  </p>
                </div>
              </div>
            </div>

            {/* Personal Info Grid */}
            <div className="space-y-3">
              <h5 className="text-sm font-semibold text-slate-800 uppercase tracking-wider border-b border-slate-50 pb-1">Personal Details</h5>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
                <div>
                  <span className="text-slate-400 font-medium">Phone Number:</span>
                  <span className="ml-2 font-semibold text-slate-700 font-mono">{userDetail.phone || '-'}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-medium">Gender:</span>
                  <span className="ml-2 font-semibold text-slate-700">{userDetail.gender || '-'}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-medium">Date of Birth:</span>
                  <span className="ml-2 font-semibold text-slate-700 font-mono">{userDetail.dob || '-'}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-medium">Registration Date:</span>
                  <span className="ml-2 font-semibold text-slate-700 font-mono">
                    {new Date(userDetail.createdAt).toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'short' })}
                  </span>
                </div>
              </div>
            </div>

            {/* Address Management Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-50 pb-1">
                <h5 className="text-sm font-semibold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  Saved Shipping Addresses ({userDetail.addresses.length})
                </h5>
              </div>

              {userDetail.addresses.length === 0 ? (
                <p className="text-sm text-slate-400 italic text-center py-3 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">No saved shipping addresses registered.</p>
              ) : (
                <div className="space-y-3">
                  {userDetail.addresses.map((addr) => (
                    <div 
                      key={addr.id} 
                      className={`p-4 rounded-xl border transition-all ${
                        addr.isDefault 
                          ? 'bg-blue-50/30 border-blue-200 shadow-xs' 
                          : 'bg-white border-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-900 text-sm flex items-center gap-2">
                          {addr.title}
                          {addr.isDefault && (
                            <span className="text-[10px] bg-blue-100 text-blue-700 font-bold px-1.5 py-0.5 rounded-md uppercase">Default</span>
                          )}
                        </span>
                        <span className="text-xs text-slate-500 font-mono">{addr.phone}</span>
                      </div>
                      <p className="text-sm text-slate-700 mt-1.5 font-medium">{addr.recipientName}</p>
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                        {addr.address}, {addr.district}, {addr.city}, {addr.province} - {addr.postalCode}
                      </p>
                      {addr.notes && (
                        <p className="text-[11px] text-amber-600 font-medium mt-1 bg-amber-50 px-2 py-0.5 rounded inline-block">
                          Note: {addr.notes}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer button */}
            <div className="flex justify-end pt-4 border-t border-slate-50">
              <Button onClick={() => setIsDetailModalOpen(false)} className="rounded-xl px-6">
                Close View
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* --- CONFIRM DELETE DIALOG --- */}
      <ConfirmationDialog
        isOpen={isConfirmDeleteOpen}
        onClose={() => setIsConfirmDeleteOpen(false)}
        onConfirm={handleDeleteConfirm}
        title="Delete Customer Account"
        description={`Are you sure you want to permanently delete customer "${selectedUser?.name}"? All saved profile data will be permanently wiped. This action is irreversible, and can only succeed if they have no registered transactions.`}
        confirmText="Confirm Delete"
        cancelText="Cancel"
        isLoading={isSubmitting}
        type="danger"
      />
    </div>
  );
}
