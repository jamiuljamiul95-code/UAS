import { useState, useEffect } from 'react';
import { 
  Plus, Edit, Trash2, Search, Check, X, AlertCircle, 
  ChevronLeft, ChevronRight, SlidersHorizontal, Image as ImageIcon, 
  Package, Info, Tag, Layers, Database, ChevronDown
} from 'lucide-react';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import api from '../../../lib/axios';

interface Category {
  id: string;
  name: string;
  slug: string;
}

interface ProductImage {
  id?: string;
  url: string;
  isMain: boolean;
}

interface ProductVariant {
  id?: string;
  color: string | null;
  size: string | null;
  stock: number;
  sku: string | null;
}

interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  discountPrice: number | null;
  weight: number | null;
  status: string;
  stock: number;
  sku: string;
  categoryId: string;
  category?: Category;
  images: ProductImage[];
  variants: ProductVariant[];
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Pagination states
  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);

  // Search, Filter & Sort states
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedStock, setSelectedStock] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Modal and feedback states
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Form states
  const [formName, setFormName] = useState('');
  const [formSlug, setFormSlug] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formCategoryId, setFormCategoryId] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formDiscountPrice, setFormDiscountPrice] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formWeight, setFormWeight] = useState('');
  const [formStatus, setFormStatus] = useState('ACTIVE');
  const [formStock, setFormStock] = useState('');
  const [formImages, setFormImages] = useState<string[]>([]);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [formVariants, setFormVariants] = useState<Omit<ProductVariant, 'id'>[]>([]);

  // Variant helper state
  const [varColor, setVarColor] = useState('');
  const [varSize, setVarSize] = useState('');
  const [varStock, setVarStock] = useState('');
  const [varSku, setVarSku] = useState('');

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [page, search, selectedCategory, selectedStatus, selectedStock, sortBy, sortOrder]);

  const fetchCategories = async () => {
    try {
      const response = await api.get('/categories');
      if (response.data.success) {
        setCategories(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch categories', error);
    }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const params: any = {
        page,
        limit,
        search,
        categoryId: selectedCategory,
        status: selectedStatus,
        stock: selectedStock,
        sortBy,
        sortOrder,
      };
      const response = await api.get('/products', { params });
      if (response.data.success) {
        setProducts(response.data.data);
        if (response.data.meta) {
          setTotalPages(response.data.meta.totalPages || 1);
          setTotalItems(response.data.meta.totalItems || 0);
        }
      }
    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setLoading(false);
    }
  };

  // Auto slug generation from name
  const handleNameChange = (val: string) => {
    setFormName(val);
    const slug = val
      .toLowerCase()
      .replace(/[\s_]+/g, '-')
      .replace(/[^\w-]+/g, '')
      .replace(/--+/g, '-');
    setFormSlug(slug);
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => {
      setSuccessMsg(null);
    }, 3000);
  };

  const startCreate = () => {
    setErrorMsg(null);
    setEditingProduct(null);
    setFormName('');
    setFormSlug('');
    setFormSku('');
    setFormCategoryId(categories[0]?.id || '');
    setFormPrice('');
    setFormDiscountPrice('');
    setFormDescription('');
    setFormWeight('');
    setFormStatus('ACTIVE');
    setFormStock('');
    setFormImages([]);
    setImageUrlInput('');
    setFormVariants([]);
    setIsFormModalOpen(true);
  };

  const startEdit = (product: Product) => {
    setErrorMsg(null);
    setEditingProduct(product);
    setFormName(product.name);
    setFormSlug(product.slug);
    setFormSku(product.sku);
    setFormCategoryId(product.categoryId);
    setFormPrice(product.price.toString());
    setFormDiscountPrice(product.discountPrice?.toString() || '');
    setFormDescription(product.description);
    setFormWeight(product.weight?.toString() || '');
    setFormStatus(product.status);
    setFormStock(product.stock.toString());
    setFormImages(product.images.map(img => img.url));
    setImageUrlInput('');
    setFormVariants(product.variants.map(v => ({
      color: v.color,
      size: v.size,
      stock: v.stock,
      sku: v.sku
    })));
    setIsFormModalOpen(true);
  };

  const handleAddImage = () => {
    if (!imageUrlInput) return;
    if (!imageUrlInput.startsWith('http://') && !imageUrlInput.startsWith('https://') && !imageUrlInput.startsWith('data:image')) {
      setErrorMsg('Please enter a valid image URL');
      return;
    }
    setFormImages([...formImages, imageUrlInput]);
    setImageUrlInput('');
    setErrorMsg(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('File must be an image');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setFormImages([...formImages, reader.result]);
        setErrorMsg(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDeleteImage = (index: number) => {
    setFormImages(formImages.filter((_, idx) => idx !== index));
  };

  const handleAddVariant = () => {
    if (!varStock) {
      setErrorMsg('Variant stock is required');
      return;
    }
    const stockNum = parseInt(varStock, 10);
    if (isNaN(stockNum) || stockNum < 0) {
      setErrorMsg('Variant stock must be non-negative');
      return;
    }

    const newVariant = {
      color: varColor || null,
      size: varSize || null,
      stock: stockNum,
      sku: varSku || null,
    };

    setFormVariants([...formVariants, newVariant]);
    setVarColor('');
    setVarSize('');
    setVarStock('');
    setVarSku('');
    setErrorMsg(null);
  };

  const handleDeleteVariant = (index: number) => {
    setFormVariants(formVariants.filter((_, idx) => idx !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Validation
    if (!formName.trim()) {
      setErrorMsg('Product name is required');
      return;
    }
    const priceNum = parseFloat(formPrice);
    if (isNaN(priceNum) || priceNum < 0) {
      setErrorMsg('Price must be greater than or equal to 0');
      return;
    }
    const stockNum = parseInt(formStock, 10);
    if (isNaN(stockNum) || stockNum < 0) {
      setErrorMsg('Stock must be greater than or equal to 0');
      return;
    }
    if (!formSku.trim()) {
      setErrorMsg('SKU is required');
      return;
    }
    if (!formSlug.trim()) {
      setErrorMsg('Slug is required');
      return;
    }
    if (!formCategoryId) {
      setErrorMsg('Category is required');
      return;
    }

    const discountPriceNum = formDiscountPrice ? parseFloat(formDiscountPrice) : null;
    if (discountPriceNum !== null && (isNaN(discountPriceNum) || discountPriceNum < 0)) {
      setErrorMsg('Discount price must be greater than or equal to 0');
      return;
    }

    const weightNum = formWeight ? parseFloat(formWeight) : null;
    if (weightNum !== null && (isNaN(weightNum) || weightNum < 0)) {
      setErrorMsg('Weight must be greater than or equal to 0');
      return;
    }

    setSaving(true);
    const payload = {
      name: formName,
      slug: formSlug,
      sku: formSku,
      categoryId: formCategoryId,
      price: priceNum,
      discountPrice: discountPriceNum,
      weight: weightNum,
      status: formStatus,
      stock: stockNum,
      description: formDescription,
      images: formImages,
      variants: formVariants,
    };

    try {
      if (editingProduct) {
        const response = await api.put(`/products/${editingProduct.id}`, payload);
        if (response.data.success) {
          showSuccess('Product updated successfully.');
          setIsFormModalOpen(false);
          fetchProducts();
        }
      } else {
        const response = await api.post('/products', payload);
        if (response.data.success) {
          showSuccess('Product created successfully.');
          setIsFormModalOpen(false);
          fetchProducts();
        }
      }
    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.response?.data?.message || 'Failed to save product');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = (product: Product) => {
    setErrorMsg(null);
    setProductToDelete(product);
    setIsDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (!productToDelete) return;
    setErrorMsg(null);
    setSaving(true);

    try {
      const response = await api.delete(`/products/${productToDelete.id}`);
      if (response.data.success) {
        showSuccess('Category deleted successfully. Product deleted successfully.');
        setIsDeleteModalOpen(false);
        setProductToDelete(null);
        fetchProducts();
      }
    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.response?.data?.message || 'Failed to delete product');
    } finally {
      setSaving(false);
    }
  };

  const handleSortChange = (option: string) => {
    if (option === 'newest') {
      setSortBy('newest');
      setSortOrder('desc');
    } else if (option === 'oldest') {
      setSortBy('oldest');
      setSortOrder('asc');
    } else if (option === 'price-asc') {
      setSortBy('price');
      setSortOrder('asc');
    } else if (option === 'price-desc') {
      setSortBy('price');
      setSortOrder('desc');
    } else if (option === 'name-asc') {
      setSortBy('name');
      setSortOrder('asc');
    } else if (option === 'name-desc') {
      setSortBy('name');
      setSortOrder('desc');
    } else if (option === 'stock-asc') {
      setSortBy('stock');
      setSortOrder('asc');
    } else if (option === 'stock-desc') {
      setSortBy('stock');
      setSortOrder('desc');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Products</h1>
          <p className="text-sm text-slate-500 mt-1">Manage and sync physical product variants, stock, images and pricing.</p>
        </div>
        <Button onClick={startCreate} className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer">
          <Plus className="w-4 h-4" />
          Add Product
        </Button>
      </div>

      {/* Success Banner */}
      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-sm flex items-center justify-between shadow-sm transition-all animate-fadeIn">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span className="font-semibold">✓ {successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-emerald-500 hover:text-emerald-700 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* General Error Banner */}
      {errorMsg && !isFormModalOpen && !isDeleteModalOpen && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-sm flex items-center justify-between shadow-sm transition-all animate-fadeIn">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span className="font-medium">{errorMsg}</span>
          </div>
          <button onClick={() => setErrorMsg(null)} className="text-rose-500 hover:text-rose-700 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input 
              className="pl-10" 
              placeholder="Search by name, description, SKU..." 
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
            />
          </div>

          {/* Filters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Category Filter */}
            <div className="relative">
              <select
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none pr-8 cursor-pointer"
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setPage(1);
                }}
              >
                <option value="all">All Categories</option>
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>

            {/* Status Filter */}
            <div className="relative">
              <select
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none pr-8 cursor-pointer"
                value={selectedStatus}
                onChange={(e) => {
                  setSelectedStatus(e.target.value);
                  setPage(1);
                }}
              >
                <option value="all">All Statuses</option>
                <option value="ACTIVE">Active Only</option>
                <option value="INACTIVE">Inactive Only</option>
                <option value="DRAFT">Drafts Only</option>
              </select>
              <ChevronDown className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>

            {/* Stock Filter */}
            <div className="relative">
              <select
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none pr-8 cursor-pointer"
                value={selectedStock}
                onChange={(e) => {
                  setSelectedStock(e.target.value);
                  setPage(1);
                }}
              >
                <option value="all">All Stock Status</option>
                <option value="instock">In Stock</option>
                <option value="outofstock">Out of Stock</option>
              </select>
              <ChevronDown className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>

            {/* Sorting */}
            <div className="relative">
              <select
                className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none pr-8 cursor-pointer"
                onChange={(e) => {
                  handleSortChange(e.target.value);
                  setPage(1);
                }}
              >
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="name-asc">Name: A to Z</option>
                <option value="name-desc">Name: Z to A</option>
                <option value="stock-asc">Stock: Low to High</option>
                <option value="stock-desc">Stock: High to Low</option>
              </select>
              <ChevronDown className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Product List Table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Image</th>
                <th className="px-6 py-4">Product details</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4">Price</th>
                <th className="px-6 py-4">Stock</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-xs">Loading products...</span>
                    </div>
                  </td>
                </tr>
              ) : products.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    <Package className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                    No products found.
                  </td>
                </tr>
              ) : (
                products.map((product) => {
                  const mainImage = product.images?.find(i => i.isMain)?.url || product.images?.[0]?.url || '';
                  return (
                    <tr key={product.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        {mainImage ? (
                          <img 
                            src={mainImage} 
                            alt={product.name} 
                            className="w-12 h-12 rounded-lg object-cover border border-slate-100 shadow-sm"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-lg bg-slate-100 flex items-center justify-center text-slate-400 border border-slate-200">
                            <ImageIcon className="w-5 h-5" />
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-900">{product.name}</div>
                        <div className="text-xs text-slate-400 font-mono mt-0.5">SKU: {product.sku}</div>
                        {product.variants?.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1.5">
                            {product.variants.map((v, index) => (
                              <span key={index} className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200">
                                {v.color && `${v.color}`}
                                {v.color && v.size && ' / '}
                                {v.size && `${v.size}`}
                                {` (${v.stock})`}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 text-slate-600 font-medium">
                        {product.category?.name || 'Uncategorized'}
                      </td>
                      <td className="px-6 py-4 text-slate-700 font-medium">
                        {product.discountPrice ? (
                          <div className="space-y-0.5">
                            <div className="text-slate-900">Rp {product.discountPrice.toLocaleString('id-ID')}</div>
                            <div className="text-xs text-slate-400 line-through">Rp {product.price.toLocaleString('id-ID')}</div>
                          </div>
                        ) : (
                          <span>Rp {product.price.toLocaleString('id-ID')}</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                          product.stock > 10 
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' 
                            : product.stock > 0 
                            ? 'bg-amber-50 text-amber-800 border border-amber-100' 
                            : 'bg-rose-50 text-rose-800 border border-rose-100'
                        }`}>
                          {product.stock} in stock
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold ${
                          product.status === 'ACTIVE'
                            ? 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                            : product.status === 'INACTIVE'
                            ? 'bg-slate-100 text-slate-600 border border-slate-200'
                            : 'bg-yellow-50 text-yellow-700 border border-yellow-100'
                        }`}>
                          {product.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-slate-600 hover:text-indigo-600 cursor-pointer"
                            onClick={() => startEdit(product)}
                            title="Edit Product"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-rose-600 hover:text-rose-700 hover:bg-rose-50 cursor-pointer" 
                            onClick={() => confirmDelete(product)}
                            title="Delete Product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-slate-200 flex items-center justify-between bg-slate-50/50">
            <span className="text-xs text-slate-500">
              Showing page <strong>{page}</strong> of <strong>{totalPages}</strong> ({totalItems} items total)
            </span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page <= 1}
                onClick={() => setPage(page - 1)}
                className="h-8 py-1 px-2.5 text-xs text-slate-600 hover:text-indigo-600 cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5 mr-1" />
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages}
                onClick={() => setPage(page + 1)}
                className="h-8 py-1 px-2.5 text-xs text-slate-600 hover:text-indigo-600 cursor-pointer"
              >
                Next
                <ChevronRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit Form Modal */}
      {isFormModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-4xl overflow-hidden my-8 max-h-[90vh] flex flex-col animate-scaleUp">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Tag className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-bold text-slate-900">
                  {editingProduct ? 'Edit Product ID: ' + editingProduct.id : 'Create New Product'}
                </h3>
              </div>
              <button 
                onClick={() => setIsFormModalOpen(false)} 
                className="text-slate-400 hover:text-slate-600 cursor-pointer focus:outline-none"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Scrollable Form */}
            <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
              {errorMsg && (
                <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-sm flex items-center justify-between animate-fadeIn">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                    <span className="font-medium">{errorMsg}</span>
                  </div>
                  <button type="button" onClick={() => setErrorMsg(null)} className="text-rose-500 hover:text-rose-700 cursor-pointer">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Grid 1: Basic Information */}
              <div className="space-y-4">
                <h4 className="text-sm font-semibold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                  <Info className="w-4 h-4" /> Basic Information
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Product Name *</label>
                    <Input
                      value={formName}
                      onChange={(e) => handleNameChange(e.target.value)}
                      placeholder="e.g. Premium Cotton T-Shirt"
                      required
                      disabled={saving}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Product Slug *</label>
                    <Input
                      value={formSlug}
                      onChange={(e) => setFormSlug(e.target.value)}
                      placeholder="e.g. premium-cotton-t-shirt"
                      required
                      disabled={saving}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">SKU *</label>
                    <Input
                      value={formSku}
                      onChange={(e) => setFormSku(e.target.value)}
                      placeholder="e.g. TS-PREM-COT-01"
                      required
                      disabled={saving}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Category *</label>
                    <select
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none pr-8 cursor-pointer h-10"
                      value={formCategoryId}
                      onChange={(e) => setFormCategoryId(e.target.value)}
                      required
                      disabled={saving}
                    >
                      <option value="" disabled>Select Category</option>
                      {categories.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Grid 2: Pricing, Weight & Stock */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h4 className="text-sm font-semibold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                  <Database className="w-4 h-4" /> Pricing & Logistics
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Base Price (Rp) *</label>
                    <Input
                      type="number"
                      value={formPrice}
                      onChange={(e) => setFormPrice(e.target.value)}
                      placeholder="e.g. 150000"
                      min="0"
                      required
                      disabled={saving}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Discount Price (Rp)</label>
                    <Input
                      type="number"
                      value={formDiscountPrice}
                      onChange={(e) => setFormDiscountPrice(e.target.value)}
                      placeholder="e.g. 129000"
                      min="0"
                      disabled={saving}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Weight (grams)</label>
                    <Input
                      type="number"
                      value={formWeight}
                      onChange={(e) => setFormWeight(e.target.value)}
                      placeholder="e.g. 250"
                      min="0"
                      disabled={saving}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Total Stock *</label>
                    <Input
                      type="number"
                      value={formStock}
                      onChange={(e) => setFormStock(e.target.value)}
                      placeholder="e.g. 100"
                      min="0"
                      required
                      disabled={saving}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Status *</label>
                    <select
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg py-2 px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none pr-8 cursor-pointer h-10"
                      value={formStatus}
                      onChange={(e) => setFormStatus(e.target.value)}
                      required
                      disabled={saving}
                    >
                      <option value="ACTIVE">ACTIVE</option>
                      <option value="INACTIVE">INACTIVE</option>
                      <option value="DRAFT">DRAFT</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Grid 3: Description */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">Description *</label>
                <textarea
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Provide details about material, size guides, wash instructions..."
                  required
                  disabled={saving}
                />
              </div>

              {/* Grid 4: Product Images */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h4 className="text-sm font-semibold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4" /> Product Images
                </h4>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <Input
                      value={imageUrlInput}
                      onChange={(e) => setImageUrlInput(e.target.value)}
                      placeholder="Paste image URL (e.g. https://example.com/image.jpg)"
                      disabled={saving}
                    />
                    <Button type="button" variant="outline" onClick={handleAddImage} className="cursor-pointer">Add URL</Button>
                  </div>
                  
                  {/* Local file uploader */}
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-300 border-dashed rounded-lg cursor-pointer bg-slate-50 hover:bg-slate-100 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <ImageIcon className="w-8 h-8 mb-3 text-slate-400" />
                        <p className="mb-2 text-sm text-slate-500"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                        <p className="text-xs text-slate-400">PNG, JPG, WebP (Converted to local base64)</p>
                      </div>
                      <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} disabled={saving} />
                    </label>
                  </div>

                  {/* Image Previews */}
                  {formImages.length > 0 && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 mt-4">
                      {formImages.map((url, idx) => (
                        <div key={idx} className="relative group aspect-square rounded-lg border border-slate-200 overflow-hidden shadow-sm">
                          <img src={url} alt="product preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          {idx === 0 && (
                            <span className="absolute top-1 left-1 bg-indigo-600 text-white text-[9px] px-1 rounded-sm uppercase font-bold shadow">
                              Main
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={() => handleDeleteImage(idx)}
                            className="absolute top-1 right-1 bg-rose-600 hover:bg-rose-700 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow"
                            title="Remove Image"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Grid 5: Product Variants */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h4 className="text-sm font-semibold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-4 h-4" /> Product Variants
                </h4>
                
                {/* Variant Input Controls */}
                <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-3">
                  <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider mb-2">Create / Update Variants</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Color (e.g. Black)</label>
                      <Input
                        value={varColor}
                        onChange={(e) => setVarColor(e.target.value)}
                        placeholder="e.g. Black"
                        disabled={saving}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Size (e.g. L)</label>
                      <Input
                        value={varSize}
                        onChange={(e) => setVarSize(e.target.value)}
                        placeholder="e.g. L"
                        disabled={saving}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Stock *</label>
                      <Input
                        type="number"
                        value={varStock}
                        onChange={(e) => setVarStock(e.target.value)}
                        placeholder="e.g. 15"
                        min="0"
                        disabled={saving}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Variant SKU</label>
                      <Input
                        value={varSku}
                        onChange={(e) => setVarSku(e.target.value)}
                        placeholder="e.g. SKU-SHIRT-L-BLK"
                        disabled={saving}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end mt-2">
                    <Button type="button" variant="outline" size="sm" onClick={handleAddVariant} className="cursor-pointer text-indigo-600 border-indigo-200 hover:bg-indigo-50">
                      Add Variant option
                    </Button>
                  </div>
                </div>

                {/* Variant Listing (Read & Delete) */}
                {formVariants.length > 0 ? (
                  <div className="border border-slate-200 rounded-lg overflow-hidden">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-600">
                        <tr>
                          <th className="px-4 py-2">Color</th>
                          <th className="px-4 py-2">Size</th>
                          <th className="px-4 py-2">Stock</th>
                          <th className="px-4 py-2">Variant SKU</th>
                          <th className="px-4 py-2 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {formVariants.map((v, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50">
                            <td className="px-4 py-2 font-medium text-slate-700">{v.color || '—'}</td>
                            <td className="px-4 py-2 font-medium text-slate-700">{v.size || '—'}</td>
                            <td className="px-4 py-2 text-slate-600">{v.stock}</td>
                            <td className="px-4 py-2 font-mono text-slate-500">{v.sku || '—'}</td>
                            <td className="px-4 py-2 text-right">
                              <button
                                type="button"
                                onClick={() => handleDeleteVariant(idx)}
                                className="text-rose-600 hover:text-rose-700 hover:bg-rose-50 p-1 rounded cursor-pointer transition-all"
                                title="Delete variant"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 rounded-lg text-center text-xs text-slate-400">
                    No variants added. This product will be managed as a single stock unit.
                  </div>
                )}
              </div>
            </form>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-3">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsFormModalOpen(false)} 
                disabled={saving}
                className="cursor-pointer"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSubmit}
                disabled={saving}
                className="bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer shadow-sm"
              >
                {saving ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Saving...</span>
                  </div>
                ) : (
                  editingProduct ? 'Save Changes' : 'Create Product'
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md overflow-hidden animate-scaleUp">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-600" />
              <h3 className="text-lg font-bold text-slate-900">Delete Product</h3>
            </div>
            <div className="p-6 space-y-4">
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-sm flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                  <button type="button" onClick={() => setErrorMsg(null)} className="text-rose-600 hover:text-rose-800 focus:outline-none">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
              <p className="text-slate-600 text-sm">
                Are you sure you want to delete the product <strong className="text-slate-900">"{productToDelete.name}"</strong>? This action cannot be undone.
              </p>
              <div className="flex justify-end gap-3 pt-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDeleteModalOpen(false)} 
                  disabled={saving}
                  className="cursor-pointer"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleDelete} 
                  disabled={saving}
                  className="bg-rose-600 text-white hover:bg-rose-700 cursor-pointer shadow-sm"
                >
                  {saving ? 'Deleting...' : 'Delete Product'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
