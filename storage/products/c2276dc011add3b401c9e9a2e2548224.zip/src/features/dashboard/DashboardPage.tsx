import { useAuthStore } from '../../store/useAuthStore';
import { ShoppingBag, TrendingUp, Users, DollarSign } from 'lucide-react';

export default function DashboardPage() {
  const { user } = useAuthStore();

  const stats = [
    { name: 'Total Revenue', value: '$45,231.89', icon: DollarSign, change: '+20.1%', changeType: 'positive' },
    { name: 'Orders', value: '+573', icon: ShoppingBag, change: '+12.5%', changeType: 'positive' },
    { name: 'Active Customers', value: '+2350', icon: Users, change: '+4.3%', changeType: 'positive' },
    { name: 'Conversion Rate', value: '3.2%', icon: TrendingUp, change: '-0.4%', changeType: 'negative' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Dashboard overview</h1>
        <p className="text-sm text-slate-500 mt-1">Welcome back, {user?.name}. Here's what's happening with your store today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500 truncate">{stat.name}</p>
                  <p className="mt-2 text-3xl font-semibold text-slate-900">{stat.value}</p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <Icon className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4">
                <span className={`text-sm font-medium ${stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.change}
                </span>
                <span className="text-sm text-slate-500 ml-2">from last month</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Placeholder for Charts / Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 min-h-[400px] flex items-center justify-center">
          <p className="text-slate-400">Sales Chart Placeholder</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 min-h-[400px] flex items-center justify-center">
          <p className="text-slate-400">Recent Orders Placeholder</p>
        </div>
      </div>
    </div>
  );
}
