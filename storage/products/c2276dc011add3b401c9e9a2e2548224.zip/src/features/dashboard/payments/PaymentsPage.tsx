import { useState, useEffect } from 'react';
import { 
  Search, Filter, CreditCard, CheckCircle2, XCircle, AlertCircle, 
  Calendar, ChevronLeft, ChevronRight, Eye, RefreshCw, FileText, 
  Check, Image as ImageIcon, User, Copy, ExternalLink, Clock, Receipt, RefreshCw as LoopIcon
} from 'lucide-react';
import api from '../../../lib/axios';
import { useAuthStore } from '../../../store/useAuthStore';
import { useToastStore } from '../../../store/useToastStore';
import Modal from '../../../components/ui/Modal';
import ConfirmationDialog from '../../../components/ui/ConfirmationDialog';
import { Skeleton } from '../../../components/ui/Skeleton';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';

interface PaymentDetail {
  id: string;
  orderId: string;
  userId: string;
  amount: number;
  paymentMethod: string;
  status: string;
  proofOfPayment: string | null;
  note: string | null;
  createdAt: string;
  updatedAt: string;
  user: {
    id: string;
    name: string;
    email: string;
    phone: string | null;
  };
  order: {
    id: string;
    totalAmount: number;
    status: string;
    paymentStatus: string;
    shippingAddress: string | null;
    items: Array<{
      id: string;
      price: number;
      quantity: number;
      product: {
        id: string;
        name: string;
        slug: string;
      };
    }>;
  };
}

export default function PaymentsPage() {
  const { user } = useAuthStore();
  const { addToast } = useToastStore();

  const [payments, setPayments] = useState<PaymentDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [totalPages, setTotalPages] = useState(1);

  // Search and Filters
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [method, setMethod] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Selected Detail Modal
  const [selectedPayment, setSelectedPayment] = useState<PaymentDetail | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [zoomImage, setZoomImage] = useState(false);

  // Admin Actions States
  const [actionType, setActionType] = useState<'approve' | 'reject' | null>(null);
  const [actionNote, setActionNote] = useState('');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submittingAction, setSubmittingAction] = useState(false);

  // Copy State
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    fetchPayments();
  }, [page, limit, status, method, startDate, endDate]);

  const fetchPayments = async () => {
    setLoading(true);
    try {
      const params: any = {
        page,
        limit,
        status: status || undefined,
        method: method || undefined,
        search: search.trim() || undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
      };

      const response = await api.get('/payments', { params });
      if (response.data.success) {
        setPayments(response.data.data);
        if (response.data.pagination) {
          setTotal(response.data.pagination.total);
          setTotalPages(response.data.pagination.totalPages);
        }
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal mengambil data pembayaran', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchPayments();
  };

  const resetFilters = () => {
    setSearch('');
    setStatus('');
    setMethod('');
    setStartDate('');
    setEndDate('');
    setPage(1);
  };

  const handleCopyId = (id: string, type: 'payment' | 'order') => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    addToast(`${type === 'payment' ? 'ID Pembayaran' : 'ID Pesanan'} disalin`, 'success');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleOpenDetail = async (paymentId: string) => {
    try {
      const response = await api.get(`/payments/${paymentId}`);
      if (response.data.success) {
        setSelectedPayment(response.data.data);
        setDetailModalOpen(true);
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal mengambil detail pembayaran', 'error');
    }
  };

  const handleActionConfirm = async () => {
    if (!selectedPayment || !actionType) return;
    setSubmittingAction(true);

    try {
      const endpoint = `/payments/${selectedPayment.id}/${actionType}`;
      const response = await api.patch(endpoint, { note: actionNote.trim() || undefined });

      if (response.data.success) {
        addToast(
          `Pembayaran berhasil ${actionType === 'approve' ? 'disetujui' : 'ditolak'}`,
          'success'
        );
        setConfirmOpen(false);
        setActionNote('');
        setActionType(null);
        
        // Refresh detail in modal
        const detailResponse = await api.get(`/payments/${selectedPayment.id}`);
        if (detailResponse.data.success) {
          setSelectedPayment(detailResponse.data.data);
        }
        
        // Refresh main list
        fetchPayments();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal memproses verifikasi', 'error');
    } finally {
      setSubmittingAction(false);
    }
  };

  const getStatusBadge = (statusStr: string) => {
    switch (statusStr.toUpperCase()) {
      case 'PAID':
        return {
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          icon: <CheckCircle2 className="w-3.5 h-3.5" />,
          label: 'Paid'
        };
      case 'PENDING':
        return {
          bg: 'bg-amber-50 text-amber-700 border-amber-200',
          icon: <Clock className="w-3.5 h-3.5 animate-pulse" />,
          label: 'Pending'
        };
      case 'WAITING_VERIFICATION':
        return {
          bg: 'bg-blue-50 text-blue-700 border-blue-200',
          icon: <AlertCircle className="w-3.5 h-3.5" />,
          label: 'Waiting Verification'
        };
      case 'REJECTED':
        return {
          bg: 'bg-rose-50 text-rose-700 border-rose-200',
          icon: <XCircle className="w-3.5 h-3.5" />,
          label: 'Rejected'
        };
      case 'REFUNDED':
        return {
          bg: 'bg-slate-100 text-slate-700 border-slate-200',
          icon: <LoopIcon className="w-3.5 h-3.5" />,
          label: 'Refunded'
        };
      default:
        return {
          bg: 'bg-slate-50 text-slate-600 border-slate-100',
          icon: null,
          label: statusStr
        };
    }
  };

  const getMethodBadge = (methodStr: string) => {
    const format = methodStr.replace('_', ' ').toUpperCase();
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 text-slate-800 border border-slate-200/50">
        <CreditCard className="w-3 h-3 text-slate-500" />
        {format}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            <CreditCard className="w-6 h-6 text-blue-600 shrink-0" />
            Payment Management
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Pantau pembayaran masuk, verifikasi bukti transfer, dan lacak status pesanan.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            onClick={fetchPayments} 
            variant="outline" 
            className="rounded-xl flex items-center gap-1.5 text-xs font-semibold border-slate-200 shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-500' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Filter and Search Panel */}
      <div className="bg-white rounded-2xl border border-slate-200/70 p-5 shadow-sm space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="relative md:col-span-6">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              type="text"
              placeholder="Cari Nomor Payment, Nomor Order, atau Nama Pelanggan..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 h-11 rounded-xl border-slate-200 text-sm focus:border-blue-500 w-full"
            />
          </div>
          <div className="md:col-span-3">
            <Button type="submit" className="w-full h-11 rounded-xl font-bold text-sm shadow-xs">
              Cari Pembayaran
            </Button>
          </div>
          <div className="md:col-span-3">
            <Button 
              type="button" 
              variant="outline" 
              onClick={resetFilters}
              className="w-full h-11 rounded-xl font-semibold text-sm border-slate-200 text-slate-600 hover:bg-slate-50"
            >
              Reset Pencarian
            </Button>
          </div>
        </form>

        <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center gap-4 text-xs">
          <div className="flex items-center gap-2 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-bold text-slate-500 uppercase tracking-wider text-[10px]">Filter Cepat:</span>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Status:</span>
            <select
              value={status}
              onChange={(e) => { setStatus(e.target.value); setPage(1); }}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700 font-medium focus:outline-none focus:border-blue-500"
            >
              <option value="">Semua Status</option>
              <option value="PENDING">Pending</option>
              <option value="WAITING_VERIFICATION">Waiting Verification</option>
              <option value="PAID">Paid</option>
              <option value="REJECTED">Rejected</option>
              <option value="REFUNDED">Refunded</option>
            </select>
          </div>

          {/* Method Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Metode:</span>
            <select
              value={method}
              onChange={(e) => { setMethod(e.target.value); setPage(1); }}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700 font-medium focus:outline-none focus:border-blue-500"
            >
              <option value="">Semua Metode</option>
              <option value="BANK_TRANSFER">Bank Transfer</option>
              <option value="QRIS">QRIS</option>
              <option value="EWALLET">E-Wallet</option>
              <option value="CASH">Cash (POS)</option>
              <option value="COD">COD</option>
            </select>
          </div>

          {/* Datepicker Filters */}
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Tanggal:</span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => { setStartDate(e.target.value); setPage(1); }}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-0.5 text-slate-700 focus:outline-none focus:border-blue-500"
            />
            <span className="text-slate-400">s/d</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => { setEndDate(e.target.value); setPage(1); }}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-0.5 text-slate-700 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Main Table Area */}
      <div className="bg-white rounded-2xl border border-slate-200/70 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-6 space-y-4">
            <Skeleton className="h-10 w-full rounded-lg animate-pulse" />
            <Skeleton className="h-14 w-full rounded-xl animate-pulse" />
            <Skeleton className="h-14 w-full rounded-xl animate-pulse" />
            <Skeleton className="h-14 w-full rounded-xl animate-pulse" />
          </div>
        ) : payments.length === 0 ? (
          <div className="p-12 text-center bg-slate-50/50">
            <CreditCard className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-600 font-bold">Data Pembayaran Tidak Ditemukan</p>
            <p className="text-slate-400 text-xs mt-1 max-w-md mx-auto">
              Tidak ada pembayaran terdaftar yang sesuai dengan pencarian atau filter yang Anda terapkan.
            </p>
            {(search || status || method || startDate || endDate) && (
              <Button onClick={resetFilters} className="mt-4 rounded-xl text-xs font-semibold">
                Bersihkan Filter
              </Button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/70 border-b border-slate-150 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  <th className="px-6 py-4">Nomor Payment</th>
                  <th className="px-6 py-4">Nomor Order</th>
                  <th className="px-6 py-4">Pelanggan</th>
                  <th className="px-6 py-4">Metode</th>
                  <th className="px-6 py-4">Jumlah</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Tanggal dibuat</th>
                  <th className="px-6 py-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {payments.map((p) => {
                  const badge = getStatusBadge(p.status);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/40 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-slate-800">
                        <button 
                          onClick={() => handleCopyId(p.id, 'payment')}
                          className="hover:text-blue-600 transition-colors inline-flex items-center gap-1 font-bold"
                        >
                          {p.id.slice(0, 8)}...
                          <Copy className="w-3 h-3 text-slate-400 shrink-0" />
                        </button>
                      </td>
                      <td className="px-6 py-4 font-mono text-xs text-slate-500">
                        <button 
                          onClick={() => handleCopyId(p.orderId, 'order')}
                          className="hover:text-blue-600 transition-colors inline-flex items-center gap-1"
                        >
                          {p.orderId.slice(0, 8)}...
                          <Copy className="w-3 h-3 text-slate-400 shrink-0" />
                        </button>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {p.user.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-bold text-slate-800 leading-tight">{p.user.name}</p>
                            <p className="text-2xs text-slate-400 leading-none mt-0.5">{p.user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {getMethodBadge(p.paymentMethod)}
                      </td>
                      <td className="px-6 py-4 font-black text-slate-900">
                        Rp{p.amount.toLocaleString('id-ID')}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${badge.bg}`}>
                          {badge.icon}
                          {badge.label}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-500 text-xs">
                        {new Date(p.createdAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Button 
                          onClick={() => handleOpenDetail(p.id)}
                          variant="outline" 
                          size="sm"
                          className="rounded-xl border-slate-200 hover:bg-slate-50 h-9 flex items-center gap-1.5 font-bold text-xs ml-auto"
                        >
                          <Eye className="w-3.5 h-3.5 text-slate-500" />
                          Detail
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Row */}
        {!loading && payments.length > 0 && (
          <div className="bg-slate-50/50 border-t border-slate-100 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-medium text-slate-500">
            <div className="flex items-center gap-3">
              <span>Menampilkan {payments.length} dari {total} data</span>
              <div className="flex items-center gap-1.5">
                <span>Baris per halaman:</span>
                <select
                  value={limit}
                  onChange={(e) => { setLimit(parseInt(e.target.value, 10)); setPage(1); }}
                  className="bg-white border border-slate-200 rounded-lg px-2 py-0.5 focus:outline-none"
                >
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 rounded-lg p-0"
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
              >
                <ChevronLeft className="w-4 h-4 text-slate-600" />
              </Button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <Button
                  key={p}
                  variant={p === page ? 'default' : 'outline'}
                  size="sm"
                  className={`h-8 w-8 rounded-lg p-0 font-semibold text-xs ${
                    p === page ? 'shadow-md shadow-blue-100' : 'text-slate-600'
                  }`}
                  onClick={() => setPage(p)}
                >
                  {p}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 rounded-lg p-0"
                onClick={() => setPage(Math.min(totalPages, page + 1))}
                disabled={page === totalPages}
              >
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Payment Detail Modal */}
      {selectedPayment && (
        <Modal
          isOpen={detailModalOpen}
          onClose={() => { setDetailModalOpen(false); setZoomImage(false); }}
          title="Detail Transaksi Pembayaran"
          size="lg"
        >
          <div className="space-y-6">
            {/* Upper grid details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <Receipt className="w-3.5 h-3.5 text-slate-400" />
                    Informasi Pembayaran
                  </p>
                  <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">No. Payment:</span>
                      <button 
                        onClick={() => handleCopyId(selectedPayment.id, 'payment')}
                        className="font-mono font-bold text-slate-800 hover:text-blue-600 flex items-center gap-1"
                      >
                        {selectedPayment.id.slice(0, 12)}...
                        <Copy className="w-3 h-3 text-slate-400" />
                      </button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">No. Order:</span>
                      <button 
                        onClick={() => handleCopyId(selectedPayment.orderId, 'order')}
                        className="font-mono font-bold text-slate-800 hover:text-blue-600 flex items-center gap-1"
                      >
                        {selectedPayment.orderId.slice(0, 12)}...
                        <Copy className="w-3 h-3 text-slate-400" />
                      </button>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Metode:</span>
                      {getMethodBadge(selectedPayment.paymentMethod)}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Total Tagihan:</span>
                      <span className="font-extrabold text-blue-600 text-sm">
                        Rp{selectedPayment.amount.toLocaleString('id-ID')}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Tanggal Buat:</span>
                      <span className="font-semibold text-slate-700">
                        {new Date(selectedPayment.createdAt).toLocaleString('id-ID', {
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Status Pembayaran:</span>
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadge(selectedPayment.status).bg}`}>
                        {getStatusBadge(selectedPayment.status).label}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    Profil Pelanggan
                  </p>
                  <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl space-y-1.5 text-xs text-slate-600">
                    <p className="font-bold text-slate-800">{selectedPayment.user.name}</p>
                    <p>Email: <span className="font-semibold text-slate-700">{selectedPayment.user.email}</span></p>
                    <p>Telepon: <span className="font-semibold text-slate-700">{selectedPayment.user.phone || '-'}</span></p>
                  </div>
                </div>
              </div>

              {/* Bukti Pembayaran preview area */}
              <div className="space-y-1.5 flex flex-col">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <ImageIcon className="w-3.5 h-3.5 text-slate-400" />
                  Bukti Pembayaran (Receipt)
                </p>
                {selectedPayment.proofOfPayment ? (
                  <div className="relative flex-1 min-h-[180px] bg-slate-100 rounded-xl border border-slate-200 overflow-hidden flex items-center justify-center group">
                    <img
                      src={selectedPayment.proofOfPayment}
                      referrerPolicy="no-referrer"
                      alt="Proof of Payment"
                      className={`max-h-[220px] object-contain transition-transform duration-300 ${
                        zoomImage ? 'scale-150 cursor-zoom-out' : 'scale-100 cursor-zoom-in hover:scale-105'
                      }`}
                      onClick={() => setZoomImage(!zoomImage)}
                    />
                    <div className="absolute bottom-2 right-2 bg-slate-900/60 backdrop-blur-md text-[10px] text-white px-2 py-1 rounded-md font-bold uppercase pointer-events-none select-none">
                      Klik Gambar Untuk Zoom
                    </div>
                    <a 
                      href={selectedPayment.proofOfPayment} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="absolute top-2 right-2 bg-white/95 text-slate-800 p-1.5 rounded-lg shadow-sm hover:bg-slate-100 transition-colors"
                      title="Buka Gambar Di Tab Baru"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ) : (
                  <div className="flex-1 min-h-[180px] bg-slate-50 border border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center p-6 text-center text-slate-400">
                    <ImageIcon className="w-10 h-10 mb-2 text-slate-300" />
                    <p className="text-xs font-bold text-slate-500">Bukti Pembayaran Belum Diunggah</p>
                    <p className="text-[10px] text-slate-400 max-w-xs mt-1">
                      Customer belum menyertakan file gambar bukti pembayaran transfer/slip bank untuk transaksi ini.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Catatan / Verification Log */}
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-slate-400" />
                Catatan Verifikasi / Keterangan
              </p>
              <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl text-xs text-slate-600 leading-relaxed font-sans min-h-[50px] whitespace-pre-wrap">
                {selectedPayment.note || (
                  <span className="italic text-slate-400">Belum ada catatan atau memo verifikasi yang ditambahkan.</span>
                )}
              </div>
            </div>

            {/* Admin Verification Form */}
            {(selectedPayment.status === 'WAITING_VERIFICATION' || selectedPayment.status === 'PENDING') && (
              <div className="p-5 border border-blue-100 bg-blue-50/10 rounded-2xl space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    Keterangan / Memo Tambahan (Wajib diisi jika menolak pembayaran):
                  </label>
                  <textarea
                    rows={2}
                    value={actionNote}
                    onChange={(e) => setActionNote(e.target.value)}
                    placeholder="Contoh: Bukti transfer terverifikasi lunas, nominal sesuai... ATAU Berikan alasan penolakan detail..."
                    className="w-full bg-white border border-slate-200 focus:outline-none focus:border-blue-500 text-xs rounded-xl p-3 leading-relaxed placeholder-slate-400"
                  />
                </div>

                <div className="flex items-center gap-3 justify-end pt-1">
                  <Button
                    onClick={() => {
                      if (!actionNote.trim()) {
                        addToast('Harap berikan alasan penolakan pada kolom catatan!', 'error');
                        return;
                      }
                      setActionType('reject');
                      setConfirmOpen(true);
                    }}
                    variant="outline"
                    className="rounded-xl border-rose-200 text-rose-600 hover:bg-rose-50 hover:text-rose-700 h-10 px-4 text-xs font-bold"
                  >
                    <XCircle className="w-4 h-4 mr-1 shrink-0" />
                    Tolak Pembayaran (Reject)
                  </Button>
                  <Button
                    onClick={() => {
                      setActionType('approve');
                      setConfirmOpen(true);
                    }}
                    className="rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white h-10 px-4 text-xs font-bold"
                  >
                    <Check className="w-4 h-4 mr-1 shrink-0" />
                    Setujui Pembayaran (Approve & Lunas)
                  </Button>
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        onConfirm={handleActionConfirm}
        title={actionType === 'approve' ? 'Setujui Pembayaran ini?' : 'Tolak Pembayaran ini?'}
        description={
          actionType === 'approve'
            ? 'Menyetujui pembayaran akan otomatis merubah status pesanan terkait menjadi PAID (Lunas) serta mengunci data pembayaran.'
            : 'Menolak pembayaran akan menginstruksikan pelanggan untuk mengunggah bukti pembayaran ulang yang sah.'
        }
        confirmText={actionType === 'approve' ? 'Ya, Setujui' : 'Ya, Tolak'}
        cancelText="Batal"
        isLoading={submittingAction}
        type={actionType === 'approve' ? 'info' : 'danger'}
      />
    </div>
  );
}
