import { Link } from 'react-router-dom';
import { Button } from '../../components/ui/Button';

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white flex-1 flex items-center min-h-[600px]">
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?auto=format&fit=crop&q=80&w=2070" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10 max-w-7xl">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
              Elevate Your <br/>
              <span className="text-blue-500">Style.</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-8 max-w-lg leading-relaxed">
              Discover our premium collection of modern clothing designed for the contemporary lifestyle. Minimalist, elegant, and perfectly tailored.
            </p>
            <div className="flex gap-4">
              <Link to="/products">
                <Button size="lg" className="text-lg px-8">Shop Collection</Button>
              </Link>
              <Link to="/products">
                <Button variant="outline" size="lg" className="text-lg px-8 text-slate-900 bg-white border-slate-200 hover:bg-slate-100">
                  View Lookbook
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Section placeholder */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Featured Arrivals</h2>
            <p className="mt-4 text-lg text-slate-600">The latest premium essentials added to our collection.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Skeletons for now */}
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="group relative">
                <div className="aspect-h-4 aspect-w-3 bg-slate-100 rounded-lg overflow-hidden h-80">
                  <div className="w-full h-full bg-slate-200 animate-pulse"></div>
                </div>
                <div className="mt-4 flex justify-between">
                  <div>
                    <div className="text-sm text-slate-700 font-medium">
                      <div className="h-4 bg-slate-200 rounded w-24 animate-pulse"></div>
                    </div>
                    <div className="mt-1 text-sm text-slate-500">
                      <div className="h-3 bg-slate-200 rounded w-16 animate-pulse mt-2"></div>
                    </div>
                  </div>
                  <div className="text-sm font-medium text-slate-900">
                    <div className="h-4 bg-slate-200 rounded w-12 animate-pulse"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
