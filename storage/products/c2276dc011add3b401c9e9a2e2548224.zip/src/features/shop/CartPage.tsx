import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Minus, Plus, Trash2, ArrowRight, ShoppingBag, AlertCircle, RefreshCw } from 'lucide-react';
import { useCartStore } from '../../store/useCartStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useToastStore } from '../../store/useToastStore';
import { Button } from '../../components/ui/Button';
import ConfirmationDialog from '../../components/ui/ConfirmationDialog';
import { Skeleton } from '../../components/ui/Skeleton';
import api from '../../lib/axios';

export default function CartPage() {
  const {
    items,
    summary,
    isLoading,
    fetchCart,
    updateQuantity,
    removeItem,
    clearCart,
    toggleSelect,
    toggleSelectAll,
  } = useCartStore();

  const { isAuthenticated } = useAuthStore();
  const { addToast } = useToastStore();
  const navigate = useNavigate();

  const [isCheckingOut, setIsCheckingOut] = useState(false);

  // States for confirmation dialogs
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isClearConfirmOpen, setIsClearConfirmOpen] = useState(false);
  const [isDeletingItem, setIsDeletingItem] = useState(false);
  const [isClearingCart, setIsClearingCart] = useState(false);

  // Load the cart on component mount & when authentication changes
  useEffect(() => {
    fetchCart();
  }, [fetchCart, isAuthenticated]);

  const handleCheckout = () => {
    if (!isAuthenticated) {
      addToast('Please login to continue to checkout', 'info');
      navigate('/login?redirect=/checkout');
      return;
    }

    const selectedItems = items.filter(i => i.selected && i.isActive && i.hasEnoughStock);
    if (selectedItems.length === 0) {
      addToast('Please select at least one active, in-stock item for checkout', 'warning');
      return;
    }

    navigate('/checkout');
  };

  const handleRemoveConfirm = async () => {
    if (!deleteId) return;
    setIsDeletingItem(true);
    try {
      await removeItem(deleteId);
    } finally {
      setIsDeletingItem(false);
      setDeleteId(null);
    }
  };

  const handleClearConfirm = async () => {
    setIsClearingCart(true);
    try {
      await clearCart();
    } finally {
      setIsClearingCart(false);
      setIsClearConfirmOpen(false);
    }
  };

  const isAllSelected = items.length > 0 && items.every((i) => i.selected);
  const someSelected = items.length > 0 && items.some((i) => i.selected) && !isAllSelected;

  if (isLoading && items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-7xl">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight mb-8">Shopping Cart</h1>
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1 space-y-4">
            <Skeleton className="h-16 w-full rounded-xl" />
            <Skeleton className="h-24 w-full rounded-xl" />
            <Skeleton className="h-24 w-full rounded-xl" />
          </div>
          <div className="w-full lg:w-96 shrink-0">
            <Skeleton className="h-96 w-full rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-24 max-w-4xl text-center">
        <div className="w-24 h-24 bg-slate-50 border border-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingBag className="w-10 h-10 text-slate-400" />
        </div>
        <h2 className="text-2xl font-semibold text-slate-900 mb-2">Your shopping cart is empty</h2>
        <p className="text-slate-500 mb-8 max-w-md mx-auto">
          Explore our collection and find awesome products to add to your cart.
        </p>
        <Link to="/products">
          <Button size="lg" className="px-8 rounded-xl">
            Browse Products
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl" id="shopping-cart-container">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Shopping Cart</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage your items and select what you are ready to checkout.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => setIsClearConfirmOpen(true)}
          className="text-red-600 hover:text-red-700 hover:bg-red-50 border-slate-200 rounded-xl flex items-center gap-2 text-sm"
          id="clear-cart-button"
        >
          <Trash2 className="w-4 h-4" />
          Clear Cart
        </Button>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Cart Item Table / Responsive Cards */}
        <div className="flex-1 w-full bg-white rounded-2xl border border-slate-150 shadow-xs overflow-hidden">
          {/* Header Row (Desktop only) */}
          <div className="hidden md:grid grid-cols-12 gap-4 items-center bg-slate-50/75 border-b border-slate-100 px-6 py-4 text-xs font-semibold uppercase tracking-wider text-slate-500">
            <div className="col-span-1 flex items-center">
              <input
                type="checkbox"
                checked={isAllSelected}
                ref={(el) => {
                  if (el) el.indeterminate = someSelected;
                }}
                onChange={(e) => toggleSelectAll(e.target.checked)}
                className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 cursor-pointer"
                id="select-all-checkbox"
              />
            </div>
            <div className="col-span-5">Product Details</div>
            <div className="col-span-2 text-center">Quantity</div>
            <div className="col-span-2 text-right">Unit Price</div>
            <div className="col-span-2 text-right">Subtotal</div>
          </div>

          <div className="divide-y divide-slate-100">
            {items.map((item) => {
              const isAvailable = item.isActive && item.availableStock > 0;
              const hasStockWarning = item.quantity > item.availableStock;

              return (
                <div
                  key={item.id}
                  className={`flex flex-col md:grid md:grid-cols-12 gap-4 items-center px-6 py-5 transition-colors hover:bg-slate-50/50 ${
                    !isAvailable ? 'bg-slate-50/75 opacity-75' : ''
                  }`}
                  id={`cart-item-${item.id}`}
                >
                  {/* Select Checkbox */}
                  <div className="col-span-1 flex items-center justify-between md:justify-start w-full md:w-auto">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={item.selected && isAvailable}
                        disabled={!isAvailable}
                        onChange={(e) => toggleSelect(item.id, e.target.checked)}
                        className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 cursor-pointer disabled:bg-slate-100 disabled:cursor-not-allowed"
                        id={`select-checkbox-${item.id}`}
                      />
                      <span className="md:hidden text-xs font-medium text-slate-500 uppercase">
                        Select Item
                      </span>
                    </div>
                    {/* Trash Button for Mobile */}
                    <button
                      onClick={() => setDeleteId(item.id)}
                      className="md:hidden text-red-500 hover:text-red-700 p-2"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Product Visual & Name Details */}
                  <div className="col-span-5 flex gap-4 w-full">
                    <div className="w-20 h-20 bg-slate-50 border border-slate-100 rounded-xl overflow-hidden shrink-0 flex items-center justify-center">
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/assets/placeholder-product.png';
                        }}
                      />
                    </div>
                    <div className="flex flex-col justify-center min-w-0">
                      <span className="text-xs font-semibold uppercase tracking-wider text-blue-600">
                        {item.categoryName}
                      </span>
                      <Link
                        to={`/products/${item.slug}`}
                        className="font-semibold text-slate-900 hover:text-blue-600 transition-colors truncate mt-0.5 text-sm md:text-base"
                      >
                        {item.name}
                      </Link>

                      {item.variantName && (
                        <p className="text-xs text-slate-500 font-medium mt-1 bg-slate-100 rounded-md py-0.5 px-2 w-fit">
                          {item.variantName}
                        </p>
                      )}

                      <div className="flex flex-wrap gap-2 mt-2">
                        {!item.isActive && (
                          <span className="inline-flex items-center gap-1 rounded bg-red-50 px-1.5 py-0.5 text-2xs font-semibold text-red-700 border border-red-100">
                            <AlertCircle className="w-3 h-3" />
                            Inactive
                          </span>
                        )}
                        {item.isActive && item.availableStock === 0 && (
                          <span className="inline-flex items-center gap-1 rounded bg-red-50 px-1.5 py-0.5 text-2xs font-semibold text-red-700 border border-red-100">
                            <AlertCircle className="w-3 h-3" />
                            Out of Stock
                          </span>
                        )}
                        {item.isActive && item.availableStock > 0 && hasStockWarning && (
                          <span className="inline-flex items-center gap-1 rounded bg-amber-50 px-1.5 py-0.5 text-2xs font-semibold text-amber-700 border border-amber-100">
                            <AlertCircle className="w-3 h-3" />
                            Only {item.availableStock} in stock
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Quantity Actions */}
                  <div className="col-span-2 flex items-center justify-between md:justify-center w-full md:w-auto">
                    <span className="md:hidden text-sm font-medium text-slate-500">
                      Quantity:
                    </span>
                    <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl p-1">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        disabled={item.quantity <= 1 || !isAvailable}
                        className="p-1.5 hover:bg-white hover:shadow-xs rounded-lg text-slate-600 disabled:opacity-50 disabled:hover:bg-transparent transition-all"
                        id={`decrement-button-${item.id}`}
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-10 text-center text-sm font-bold text-slate-800">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        disabled={item.quantity >= item.availableStock || !isAvailable}
                        className="p-1.5 hover:bg-white hover:shadow-xs rounded-lg text-slate-600 disabled:opacity-50 disabled:hover:bg-transparent transition-all"
                        id={`increment-button-${item.id}`}
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Unit Pricing */}
                  <div className="col-span-2 text-right flex justify-between md:block w-full md:w-auto text-sm">
                    <span className="md:hidden text-slate-500">Unit Price:</span>
                    <div className="flex flex-col items-end">
                      {item.discountPrice !== null && item.discountPrice < item.originalPrice ? (
                        <>
                          <span className="font-bold text-slate-900">
                            Rp{item.discountPrice.toLocaleString('id-ID')}
                          </span>
                          <span className="text-2xs text-slate-400 line-through font-medium mt-0.5">
                            Rp{item.originalPrice.toLocaleString('id-ID')}
                          </span>
                        </>
                      ) : (
                        <span className="font-semibold text-slate-700">
                          Rp{item.originalPrice.toLocaleString('id-ID')}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Subtotals & Delete Desktop Row Button */}
                  <div className="col-span-2 text-right flex justify-between md:block w-full md:w-auto text-sm">
                    <span className="md:hidden text-slate-500">Total Price:</span>
                    <div className="flex items-center justify-end gap-3 w-full">
                      <span className="font-bold text-slate-900 md:text-base">
                        Rp{item.subtotal.toLocaleString('id-ID')}
                      </span>
                      {/* Delete Desktop Button */}
                      <button
                        onClick={() => setDeleteId(item.id)}
                        className="hidden md:block text-slate-400 hover:text-red-600 p-1.5 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        id={`delete-desktop-${item.id}`}
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Order Payment Checkout Summary Card */}
        <div className="w-full lg:w-96 shrink-0 sticky top-24">
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6">
            <h2 className="text-lg font-bold text-slate-900 border-b border-slate-200 pb-4 mb-5">
              Order Summary
            </h2>

            <div className="space-y-4 text-sm mb-6">
              <div className="flex justify-between text-slate-600 font-medium">
                <span>Selected Items</span>
                <span className="font-semibold text-slate-900">
                  {summary.selectedItemsCount} {summary.selectedItemsCount === 1 ? 'item' : 'items'}
                </span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Original Subtotal</span>
                <span className="font-semibold text-slate-900">
                  Rp{summary.originalSubtotal.toLocaleString('id-ID')}
                </span>
              </div>

              {summary.totalDiscount > 0 && (
                <div className="flex justify-between text-green-600 font-medium">
                  <span>Product Savings</span>
                  <span>-Rp{summary.totalDiscount.toLocaleString('id-ID')}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600">
                <span>Shipping Cost</span>
                <span className="font-medium text-slate-500">Free</span>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-between items-baseline">
                <span className="text-base font-bold text-slate-900">Estimated Total</span>
                <span className="text-2xl font-black text-blue-600">
                  Rp{summary.totalPayment.toLocaleString('id-ID')}
                </span>
              </div>
            </div>

            <Button
              className="w-full gap-2 py-6 text-base font-semibold rounded-xl cursor-pointer"
              onClick={handleCheckout}
              disabled={isCheckingOut || summary.selectedUniqueItems === 0}
              id="checkout-button"
            >
              {isCheckingOut ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Processing Order...
                </>
              ) : (
                <>
                  Checkout ({summary.selectedUniqueItems})
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </Button>

            {!isAuthenticated && (
              <p className="text-xs text-center text-slate-500 mt-4 leading-relaxed bg-blue-50/50 rounded-lg p-2.5 border border-blue-100/50">
                You are currently shopping as a guest. Please{' '}
                <Link to="/login?redirect=/cart" className="font-semibold text-blue-600 underline">
                  login
                </Link>{' '}
                to permanently persist your items and sync with your account.
              </p>
            )}

            {isAuthenticated && summary.selectedUniqueItems === 0 && (
              <p className="text-xs text-center text-amber-600 mt-4 leading-relaxed font-medium bg-amber-50 rounded-lg p-2.5 border border-amber-100">
                Please check the boxes next to the items you wish to purchase to enable checkout.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Dialog for single deletion */}
      <ConfirmationDialog
        isOpen={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={handleRemoveConfirm}
        title="Remove item from cart?"
        description="Are you sure you want to remove this product from your shopping cart?"
        confirmText="Remove"
        cancelText="Keep"
        isLoading={isDeletingItem}
        type="danger"
      />

      {/* Confirmation Dialog for clearing cart */}
      <ConfirmationDialog
        isOpen={isClearConfirmOpen}
        onClose={() => setIsClearConfirmOpen(false)}
        onConfirm={handleClearConfirm}
        title="Empty your shopping cart?"
        description="This action will remove all products currently in your cart. You cannot undo this change."
        confirmText="Clear All"
        cancelText="Cancel"
        isLoading={isClearingCart}
        type="danger"
      />
    </div>
  );
}
