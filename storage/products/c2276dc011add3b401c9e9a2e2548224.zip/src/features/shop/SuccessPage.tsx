import { useEffect, useState } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { CheckCircle, ShoppingBag, Receipt, ArrowRight, Clipboard, Copy, User } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { useToastStore } from '../../store/useToastStore';
import { Skeleton } from '../../components/ui/Skeleton';
import api from '../../lib/axios';

interface OrderItem {
  id: string;
  product: {
    name: string;
  };
  quantity: number;
  price: number;
}

interface OrderDetails {
  id: string;
  status: string;
  totalAmount: number;
  paymentMethod: string;
  shippingAddress: string;
  subtotal: number;
  discountAmount: number;
  shippingFee: number;
  taxAmount: number;
  createdAt: string;
  items: OrderItem[];
}

export default function SuccessPage() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');
  const navigate = useNavigate();
  const { addToast } = useToastStore();
  const [loading, setLoading] = useState<boolean>(true);
  const [order, setOrder] = useState<OrderDetails | null>(null);

  useEffect(() => {
    if (!orderId) {
      addToast('ID Pesanan tidak ditemukan', 'error');
      navigate('/');
      return;
    }

    const fetchOrder = async () => {
      setLoading(true);
      try {
        // Query the orders endpoint to find our newly created order
        const response = await api.get('/orders');
        if (response.data.success) {
          const list: OrderDetails[] = response.data.data || [];
          const found = list.find(o => o.id === orderId);
          if (found) {
            setOrder(found);
          }
        }
      } catch (err) {
        console.error('Failed to retrieve order receipt details:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();
  }, [orderId, navigate, addToast]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    addToast('ID Pesanan berhasil disalin ke clipboard!', 'success');
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-24 max-w-lg text-center">
        <Skeleton className="h-16 w-16 mx-auto rounded-full mb-6" />
        <Skeleton className="h-8 w-64 mx-auto rounded-lg mb-4" />
        <Skeleton className="h-4 w-48 mx-auto rounded-lg mb-8" />
        <Skeleton className="h-48 w-full rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16 max-w-2xl" id="checkout-success-container">
      <div className="bg-white border border-slate-150 rounded-3xl p-8 md:p-10 shadow-lg shadow-slate-100 text-center relative overflow-hidden">
        {/* Top green glow accent */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-green-500" />

        <div className="w-16 h-16 bg-green-100/80 border border-green-200 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-9 h-9 text-green-600 fill-green-50 animate-bounce" />
        </div>

        <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">Checkout Berhasil!</h1>
        <p className="text-slate-500 text-sm mt-2 max-w-md mx-auto">
          Terima kasih atas pesanan Anda. Kami telah menerima pembayaran Anda dan pesanan Anda sedang diproses.
        </p>

        {/* Short Receipt Summary Card */}
        {order && (
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 mt-8 text-left space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <Receipt className="w-4 h-4" />
                Rincian Transaksi
              </span>
              <button
                onClick={() => handleCopy(order.id)}
                className="text-2xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                title="Salin ID Pesanan"
              >
                Copy ID
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <p className="text-slate-400">ID Pesanan</p>
                <p className="font-mono font-bold text-slate-800 truncate mt-0.5" title={order.id}>{order.id}</p>
              </div>
              <div>
                <p className="text-slate-400">Tanggal Transaksi</p>
                <p className="font-bold text-slate-800 mt-0.5">
                  {new Date(order.createdAt).toLocaleDateString('id-ID', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>
              <div>
                <p className="text-slate-400">Metode Pembayaran</p>
                <p className="font-bold text-slate-800 mt-0.5 uppercase">{order.paymentMethod}</p>
              </div>
              <div>
                <p className="text-slate-400">Status Pembayaran</p>
                <p className="font-bold text-green-700 mt-0.5">LUNAS / BERHASIL</p>
              </div>
            </div>

            {/* Financial summaries */}
            <div className="border-t border-slate-200 pt-3 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal Produk</span>
                <span className="font-semibold text-slate-800">Rp{order.subtotal.toLocaleString('id-ID')}</span>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Potongan Voucher</span>
                  <span>-Rp{order.discountAmount.toLocaleString('id-ID')}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>Ongkos Kirim</span>
                <span className="font-semibold text-slate-800">Rp{order.shippingFee.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>PPN (11%)</span>
                <span className="font-semibold text-slate-800">Rp{order.taxAmount.toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between text-sm font-black text-slate-900 border-t border-dashed border-slate-200 pt-2">
                <span>Total Belanja</span>
                <span className="text-base text-blue-600">Rp{order.totalAmount.toLocaleString('id-ID')}</span>
              </div>
            </div>
          </div>
        )}

        {/* PAYMENT METHOD STEPS OR SPECIFICS */}
        {order && order.paymentMethod === 'TRANSFER' && (
          <div className="bg-blue-50/50 border border-blue-150 rounded-xl p-4 mt-5 text-left text-xs text-blue-800 space-y-1.5 leading-relaxed font-medium">
            <p className="font-bold text-blue-900">Opsi Bank Transfer Manual:</p>
            <p>Silakan lakukan transfer senilai <span className="font-black text-blue-600 text-sm">Rp{order.totalAmount.toLocaleString('id-ID')}</span> ke rekening berikut:</p>
            <div className="bg-white border border-blue-200 p-2.5 rounded-lg font-mono font-bold mt-1 text-slate-800 flex justify-between items-center">
              <span>BCA 123-456-7890 a/n Toko Bagus</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText('1234567890');
                  addToast('Nomor rekening disalin!', 'success');
                }}
                className="text-blue-600 hover:underline hover:text-blue-800 flex items-center gap-0.5 text-2xs"
              >
                Salin
              </button>
            </div>
          </div>
        )}

        {order && order.paymentMethod === 'QRIS' && (
          <div className="bg-emerald-50/50 border border-emerald-150 rounded-xl p-4 mt-5 text-left text-xs text-emerald-800 space-y-1.5 leading-relaxed font-medium">
            <p className="font-bold text-emerald-900 text-sm">Pembayaran QRIS Sukses:</p>
            <p>Sistem kami mendeteksi pembayaran QRIS berhasil terverifikasi otomatis. Pesanan Anda kini dikirim langsung ke bagian gudang untuk diproses.</p>
          </div>
        )}

        {/* Action Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-10">
          <Link to="/products">
            <Button variant="outline" className="w-full gap-2 py-5 font-semibold rounded-xl cursor-pointer">
              <ShoppingBag className="w-4 h-4" />
              Lanjut Belanja
            </Button>
          </Link>
          <Link to="/profile">
            <Button className="w-full gap-2 py-5 font-semibold rounded-xl cursor-pointer bg-blue-600 hover:bg-blue-700 text-white">
              Lihat Riwayat Pesanan
              <User className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
