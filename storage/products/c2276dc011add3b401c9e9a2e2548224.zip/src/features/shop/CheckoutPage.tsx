import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  MapPin,
  Truck,
  Ticket,
  CreditCard,
  CheckCircle,
  Plus,
  Trash2,
  ChevronRight,
  AlertCircle,
  ArrowLeft,
  Check,
  RefreshCw,
  ShoppingBag,
  Info,
  Calendar,
  Sparkles,
  User,
  Phone,
  Home,
  Tag,
  Percent
} from 'lucide-react';
import { useCartStore } from '../../store/useCartStore';
import { useToastStore } from '../../store/useToastStore';
import { useAuthStore } from '../../store/useAuthStore';
import { Button } from '../../components/ui/Button';
import ConfirmationDialog from '../../components/ui/ConfirmationDialog';
import { Skeleton } from '../../components/ui/Skeleton';
import api from '../../lib/axios';

// Types for Addresses managed in profile
interface Address {
  id: string;
  title: string;
  recipientName: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  postalCode: string;
  address: string;
  notes?: string | null;
  isDefault: boolean;
}

// Types for Checkout Preview Response
interface CheckoutItem {
  cartItemId: string;
  productId: string;
  name: string;
  slug: string;
  categoryName: string;
  imageUrl: string;
  variantId: string | null;
  variantName: string | null;
  quantity: number;
  originalPrice: number;
  discountPrice: number | null;
  price: number;
  subtotal: number;
  isAvailable: boolean;
  hasEnoughStock: boolean;
  availableStock: number;
}

interface CheckoutSummary {
  subtotal: number;
  discountAmount: number;
  shippingFee: number;
  taxAmount: number;
  grandTotal: number;
}

interface ShippingMethod {
  carrier: string;
  name: string;
  cost: number;
  etd: string;
}

interface Voucher {
  id: string;
  code: string;
  type: 'NOMINAL' | 'PERCENT';
  value: number;
  minPurchase: number;
  quota: number;
  usedCount: number;
  expiryDate: string | null;
  status: string;
}

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { addToast } = useToastStore();
  const { isAuthenticated } = useAuthStore();
  const { fetchCart } = useCartStore();

  // Active step of checkout: 1 = Pengiriman, 2 = Pembayaran, 3 = Konfirmasi & Review
  const [activeStep, setActiveStep] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Core checkout states
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string>('');
  const [shippingMethods, setShippingMethods] = useState<ShippingMethod[]>([]);
  const [selectedCarrier, setSelectedCarrier] = useState<string>('');
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [voucherCodeInput, setVoucherCodeInput] = useState<string>('');
  const [appliedVoucherCode, setAppliedVoucherCode] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'QRIS' | 'TRANSFER' | 'COD'>('TRANSFER');

  // Preview response state
  const [previewData, setPreviewData] = useState<{
    items: CheckoutItem[];
    summary: CheckoutSummary;
    address: Address | null;
    shipping: ShippingMethod | null;
    voucher: {
      id: string;
      code: string;
      type: string;
      value: number;
      discountAmount: number;
    } | null;
    voucherError: string | null;
    stockErrors: string[];
    isValid: boolean;
  } | null>(null);

  // Address creation/editing modal states
  const [isAddressFormOpen, setIsAddressFormOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);
  const [addressForm, setAddressForm] = useState({
    title: 'Alamat',
    recipientName: '',
    phone: '',
    province: '',
    city: '',
    district: '',
    postalCode: '',
    address: '',
    notes: '',
    isDefault: false,
  });

  // Dialog deletion states
  const [deleteAddressId, setDeleteAddressId] = useState<string | null>(null);
  const [isDeletingAddress, setIsDeletingAddress] = useState(false);

  // Redirect if not logged in
  useEffect(() => {
    if (!isAuthenticated) {
      addToast('Silakan login terlebih dahulu untuk mengakses checkout', 'warning');
      navigate('/login?redirect=/checkout');
    }
  }, [isAuthenticated, navigate, addToast]);

  // Load initial addresses, shipping methods, and active vouchers
  useEffect(() => {
    if (!isAuthenticated) return;

    const loadInitialData = async () => {
      setIsLoading(true);
      try {
        const [addrRes, shipRes, vouchRes] = await Promise.all([
          api.get('/profile/addresses'),
          api.get('/shipping'),
          api.get('/vouchers'),
        ]);

        if (addrRes.data.success) {
          const addrs = addrRes.data.data || [];
          setAddresses(addrs);
          // Auto-select default address
          const defAddr = addrs.find((a: Address) => a.isDefault);
          if (defAddr) {
            setSelectedAddressId(defAddr.id);
          } else if (addrs.length > 0) {
            setSelectedAddressId(addrs[0].id);
          }
        }

        if (shipRes.data.success) {
          const carriers = shipRes.data.data || [];
          setShippingMethods(carriers);
          // Set JNE or first carrier by default
          if (carriers.length > 0) {
            setSelectedCarrier(carriers[0].carrier);
          }
        }

        if (vouchRes.data.success) {
          setVouchers(vouchRes.data.data || []);
        }
      } catch (error: any) {
        console.error('Failed to load checkout details:', error);
        addToast(error.response?.data?.message || 'Gagal memuat data checkout', 'error');
      } finally {
        setIsLoading(false);
      }
    };

    loadInitialData();
  }, [isAuthenticated, addToast]);

  // Generate checkout preview reactively whenever selections modify
  useEffect(() => {
    if (!isAuthenticated || isLoading) return;

    const fetchPreview = async () => {
      try {
        const response = await api.post('/checkout/preview', {
          addressId: selectedAddressId || undefined,
          shippingCarrier: selectedCarrier || undefined,
          voucherCode: appliedVoucherCode || undefined,
        });

        if (response.data.success) {
          setPreviewData(response.data.data);
        }
      } catch (error: any) {
        console.error('Preview fetch error:', error);
        addToast(error.response?.data?.message || 'Gagal memperbarui kalkulasi checkout', 'error');
      }
    };

    const delayDebounceFn = setTimeout(() => {
      fetchPreview();
    }, 200);

    return () => clearTimeout(delayDebounceFn);
  }, [selectedAddressId, selectedCarrier, appliedVoucherCode, isAuthenticated, isLoading, addToast]);

  // Address Submit (Create/Update)
  const handleAddressSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !addressForm.recipientName ||
      !addressForm.phone ||
      !addressForm.province ||
      !addressForm.city ||
      !addressForm.district ||
      !addressForm.postalCode ||
      !addressForm.address
    ) {
      addToast('Silakan isi seluruh kolom alamat wajib', 'warning');
      return;
    }

    try {
      if (editingAddress) {
        const res = await api.put(`/profile/addresses/${editingAddress.id}`, addressForm);
        if (res.data.success) {
          addToast('Alamat berhasil diubah', 'success');
          // Reload addresses
          const addrRes = await api.get('/profile/addresses');
          setAddresses(addrRes.data.data || []);
          setIsAddressFormOpen(false);
          setEditingAddress(null);
        }
      } else {
        const res = await api.post('/profile/addresses', addressForm);
        if (res.data.success) {
          addToast('Alamat baru berhasil ditambahkan', 'success');
          // Reload addresses
          const addrRes = await api.get('/profile/addresses');
          const updatedAddrs = addrRes.data.data || [];
          setAddresses(updatedAddrs);
          // Set selected to newly created
          if (res.data.data?.id) {
            setSelectedAddressId(res.data.data.id);
          }
          setIsAddressFormOpen(false);
        }
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal menyimpan alamat', 'error');
    }
  };

  const handleEditAddress = (addr: Address) => {
    setEditingAddress(addr);
    setAddressForm({
      title: addr.title,
      recipientName: addr.recipientName,
      phone: addr.phone,
      province: addr.province,
      city: addr.city,
      district: addr.district,
      postalCode: addr.postalCode,
      address: addr.address,
      notes: addr.notes || '',
      isDefault: addr.isDefault,
    });
    setIsAddressFormOpen(true);
  };

  const handleDeleteAddressConfirm = async () => {
    if (!deleteAddressId) return;
    setIsDeletingAddress(true);
    try {
      await api.delete(`/profile/addresses/${deleteAddressId}`);
      addToast('Alamat berhasil dihapus', 'success');
      const addrRes = await api.get('/profile/addresses');
      const updated = addrRes.data.data || [];
      setAddresses(updated);
      if (selectedAddressId === deleteAddressId) {
        if (updated.length > 0) {
          setSelectedAddressId(updated[0].id);
        } else {
          setSelectedAddressId('');
        }
      }
    } catch (error: any) {
      addToast('Gagal menghapus alamat', 'error');
    } finally {
      setIsDeletingAddress(false);
      setDeleteAddressId(null);
    }
  };

  const handleApplyVoucher = () => {
    if (!voucherCodeInput.trim()) {
      addToast('Masukkan kode voucher terlebih dahulu', 'warning');
      return;
    }
    setAppliedVoucherCode(voucherCodeInput.trim().toUpperCase());
    addToast(`Memvalidasi kode voucher: ${voucherCodeInput.toUpperCase()}`, 'info');
  };

  const handleRemoveVoucher = () => {
    setAppliedVoucherCode('');
    setVoucherCodeInput('');
    addToast('Voucher dilepas', 'info');
  };

  const handleChooseVoucher = (code: string) => {
    setVoucherCodeInput(code);
    setAppliedVoucherCode(code);
    addToast(`Voucher ${code} dipilih`, 'success');
  };

  const executeOrderCheckout = async () => {
    if (!selectedAddressId) {
      addToast('Silakan pilih alamat pengiriman terlebih dahulu', 'warning');
      return;
    }
    if (!selectedCarrier) {
      addToast('Silakan pilih metode pengiriman terlebih dahulu', 'warning');
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await api.post('/checkout', {
        addressId: selectedAddressId,
        shippingCarrier: selectedCarrier,
        voucherCode: appliedVoucherCode || undefined,
        paymentMethod: paymentMethod,
      });

      if (response.data.success) {
        const orderId = response.data.data?.id;
        addToast('Checkout berhasil! Pesanan Anda telah dibuat.', 'success');
        await fetchCart(); // Sync frontend cart state
        navigate(`/checkout/success?orderId=${orderId}`);
      }
    } catch (error: any) {
      console.error('Final Checkout submission error:', error);
      const msg = error.response?.data?.message || 'Checkout gagal dilakukan';
      addToast(msg, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper step checkers
  const validateStep1 = () => {
    if (!selectedAddressId) {
      addToast('Silakan pilih alamat terlebih dahulu', 'warning');
      return false;
    }
    if (!selectedCarrier) {
      addToast('Silakan pilih kurir pengiriman terlebih dahulu', 'warning');
      return false;
    }
    if (previewData && !previewData.isValid) {
      addToast(`Selesaikan masalah stok sebelum lanjut: ${previewData.stockErrors.join(' ')}`, 'error');
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    if (previewData && appliedVoucherCode && previewData.voucherError) {
      addToast(`Voucher bermasalah: ${previewData.voucherError}`, 'error');
      return false;
    }
    return true;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-7xl">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight mb-8">Checkout</h1>
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1 space-y-6">
            <Skeleton className="h-40 w-full rounded-2xl" />
            <Skeleton className="h-48 w-full rounded-2xl" />
          </div>
          <div className="w-full lg:w-96 shrink-0">
            <Skeleton className="h-96 w-full rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl" id="checkout-module-container">
      {/* Visual Stepper */}
      <div className="max-w-4xl mx-auto mb-10">
        <div className="flex items-center justify-between relative">
          <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-slate-200 -z-10" />
          
          <button
            onClick={() => activeStep > 1 && setActiveStep(1)}
            disabled={activeStep === 1}
            className={`flex flex-col items-center gap-2 group cursor-pointer disabled:cursor-default`}
            id="step-1-indicator"
          >
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all duration-300 ${
                activeStep >= 1
                  ? 'bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-100'
                  : 'bg-white border-slate-300 text-slate-500'
              }`}
            >
              {activeStep > 1 ? <Check className="w-5 h-5" /> : '1'}
            </div>
            <span className={`text-xs font-semibold ${activeStep >= 1 ? 'text-blue-600' : 'text-slate-500'}`}>
              Pengiriman
            </span>
          </button>

          <button
            onClick={() => activeStep > 2 && setActiveStep(2)}
            disabled={activeStep <= 2}
            className="flex flex-col items-center gap-2 group cursor-pointer disabled:cursor-default"
            id="step-2-indicator"
          >
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all duration-300 ${
                activeStep >= 2
                  ? 'bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-100'
                  : 'bg-white border-slate-300 text-slate-500'
              }`}
            >
              {activeStep > 2 ? <Check className="w-5 h-5" /> : '2'}
            </div>
            <span className={`text-xs font-semibold ${activeStep >= 2 ? 'text-blue-600' : 'text-slate-500'}`}>
              Pembayaran & Voucher
            </span>
          </button>

          <div
            className="flex flex-col items-center gap-2"
            id="step-3-indicator"
          >
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all duration-300 ${
                activeStep === 3
                  ? 'bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-100'
                  : 'bg-white border-slate-300 text-slate-500'
              }`}
            >
              3
            </div>
            <span className={`text-xs font-semibold ${activeStep === 3 ? 'text-blue-600' : 'text-slate-500'}`}>
              Review & Konfirmasi
            </span>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        
        {/* LEFT COLUMN: Steps Modules */}
        <div className="flex-1 w-full space-y-6">
          
          {/* STEP 1: PENGIRIMAN */}
          {activeStep === 1 && (
            <div className="space-y-6" id="shipping-step-container">
              
              {/* ADDRESS SELECTOR */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-blue-600" />
                      Alamat Pengiriman
                    </h2>
                    <p className="text-xs text-slate-500 mt-1">Pilih alamat tujuan pengiriman pesanan Anda</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setEditingAddress(null);
                      setAddressForm({
                        title: 'Alamat',
                        recipientName: '',
                        phone: '',
                        province: '',
                        city: '',
                        district: '',
                        postalCode: '',
                        address: '',
                        notes: '',
                        isDefault: false,
                      });
                      setIsAddressFormOpen(true);
                    }}
                    className="rounded-xl flex items-center gap-1 text-xs font-semibold cursor-pointer"
                    id="add-address-button"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Alamat Baru
                  </Button>
                </div>

                {/* ADDRESS MODAL FORM */}
                {isAddressFormOpen && (
                  <form onSubmit={handleAddressSubmit} className="bg-slate-50 rounded-xl p-5 border border-slate-200 mb-6 space-y-4" id="address-form">
                    <h3 className="font-bold text-sm text-slate-800">
                      {editingAddress ? 'Edit Alamat Pengiriman' : 'Tambah Alamat Pengiriman Baru'}
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                          Label Alamat (cth: Rumah, Kantor)
                        </label>
                        <input
                          type="text"
                          value={addressForm.title}
                          onChange={(e) => setAddressForm({ ...addressForm, title: e.target.value })}
                          className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                          placeholder="cth: Rumah"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                          Nama Penerima
                        </label>
                        <input
                          type="text"
                          value={addressForm.recipientName}
                          onChange={(e) => setAddressForm({ ...addressForm, recipientName: e.target.value })}
                          className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                          placeholder="Nama Lengkap"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                          No. Telepon / HP
                        </label>
                        <input
                          type="text"
                          value={addressForm.phone}
                          onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
                          className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                          placeholder="cth: 0812XXXXXXXX"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                          Kode Pos
                        </label>
                        <input
                          type="text"
                          value={addressForm.postalCode}
                          onChange={(e) => setAddressForm({ ...addressForm, postalCode: e.target.value })}
                          className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                          placeholder="Kode Pos"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                          Provinsi
                        </label>
                        <input
                          type="text"
                          value={addressForm.province}
                          onChange={(e) => setAddressForm({ ...addressForm, province: e.target.value })}
                          className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                          placeholder="Provinsi"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                          Kota / Kabupaten
                        </label>
                        <input
                          type="text"
                          value={addressForm.city}
                          onChange={(e) => setAddressForm({ ...addressForm, city: e.target.value })}
                          className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                          placeholder="Kota / Kab"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                          Kecamatan
                        </label>
                        <input
                          type="text"
                          value={addressForm.district}
                          onChange={(e) => setAddressForm({ ...addressForm, district: e.target.value })}
                          className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                          placeholder="Kecamatan"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                        Alamat Lengkap
                      </label>
                      <textarea
                        value={addressForm.address}
                        onChange={(e) => setAddressForm({ ...addressForm, address: e.target.value })}
                        className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500 h-20 resize-none"
                        placeholder="Nama jalan, Gedung, No Rumah, RT/RW, dsb."
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-2xs uppercase tracking-wider font-bold text-slate-500 mb-1">
                        Catatan Pengiriman (Opsional)
                      </label>
                      <input
                        type="text"
                        value={addressForm.notes}
                        onChange={(e) => setAddressForm({ ...addressForm, notes: e.target.value })}
                        className="w-full text-sm rounded-lg border border-slate-200 bg-white px-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500"
                        placeholder="cth: Pagar hitam, warna cat rumah kuning"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="isDefaultCheckbox"
                        checked={addressForm.isDefault}
                        onChange={(e) => setAddressForm({ ...addressForm, isDefault: e.target.checked })}
                        className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 cursor-pointer"
                      />
                      <label htmlFor="isDefaultCheckbox" className="text-xs font-semibold text-slate-700 cursor-pointer">
                        Jadikan sebagai alamat default pengiriman
                      </label>
                    </div>

                    <div className="flex justify-end gap-3 pt-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setIsAddressFormOpen(false);
                          setEditingAddress(null);
                        }}
                        className="rounded-lg text-xs"
                      >
                        Batal
                      </Button>
                      <Button type="submit" className="rounded-lg text-xs">
                        {editingAddress ? 'Simpan Perubahan' : 'Simpan Alamat'}
                      </Button>
                    </div>
                  </form>
                )}

                {/* ADDRESS CARDS */}
                {addresses.length === 0 ? (
                  <div className="bg-blue-50 border border-blue-100 rounded-xl p-5 text-center">
                    <Info className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-blue-800">Belum ada alamat pengiriman</p>
                    <p className="text-xs text-blue-600 mt-1">Silakan tambahkan alamat pengiriman baru untuk melanjutkan checkout.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {addresses.map((addr) => {
                      const isSelected = selectedAddressId === addr.id;
                      return (
                        <div
                          key={addr.id}
                          onClick={() => setSelectedAddressId(addr.id)}
                          className={`border rounded-xl p-4 cursor-pointer relative transition-all duration-250 hover:bg-slate-50/50 flex flex-col justify-between ${
                            isSelected
                              ? 'border-blue-600 bg-blue-50/20 ring-1 ring-blue-500 shadow-sm'
                              : 'border-slate-200 bg-white'
                          }`}
                          id={`address-card-${addr.id}`}
                        >
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <span className="font-bold text-sm text-slate-800">{addr.title}</span>
                              {addr.isDefault && (
                                <span className="bg-blue-100 text-blue-800 text-3xs font-extrabold uppercase px-1.5 py-0.5 rounded">
                                  Default
                                </span>
                              )}
                            </div>
                            <div className="space-y-1.5 text-xs text-slate-600">
                              <p className="flex items-center gap-1 font-semibold text-slate-700">
                                <User className="w-3.5 h-3.5 text-slate-400" />
                                {addr.recipientName}
                              </p>
                              <p className="flex items-center gap-1 text-slate-500">
                                <Phone className="w-3.5 h-3.5 text-slate-400" />
                                {addr.phone}
                              </p>
                              <p className="mt-1 line-clamp-2 leading-relaxed text-slate-500 flex gap-1 items-start">
                                <Home className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                                {addr.address}, {addr.district}, {addr.city}, {addr.province} ({addr.postalCode})
                              </p>
                              {addr.notes && (
                                <p className="text-2xs italic bg-slate-100 rounded px-1.5 py-0.5 w-fit font-medium text-slate-500 mt-1">
                                  Catatan: {addr.notes}
                                </p>
                              )}
                            </div>
                          </div>

                          <div className="flex justify-end gap-3 border-t border-slate-100 pt-3 mt-3">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEditAddress(addr);
                              }}
                              className="text-2xs font-bold text-slate-600 hover:text-blue-600 flex items-center gap-0.5"
                            >
                              Edit
                            </button>
                            {!addr.isDefault && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeleteAddressId(addr.id);
                                }}
                                className="text-2xs font-bold text-red-500 hover:text-red-700 flex items-center gap-0.5"
                              >
                                Hapus
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* SHIPPING CARRIERS */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                    <Truck className="w-5 h-5 text-blue-600" />
                    Metode Pengiriman
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">Pilih kurir pengiriman yang paling sesuai untuk Anda</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  {shippingMethods.map((method) => {
                    const isSelected = selectedCarrier.toLowerCase() === method.carrier.toLowerCase();
                    return (
                      <div
                        key={method.carrier}
                        onClick={() => setSelectedCarrier(method.carrier)}
                        className={`border rounded-xl p-4 cursor-pointer flex items-center justify-between transition-all duration-200 ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50/20 ring-1 ring-blue-500 shadow-sm'
                            : 'border-slate-200 bg-white'
                        }`}
                        id={`shipping-carrier-${method.carrier}`}
                      >
                        <div className="flex flex-col">
                          <span className="font-bold text-sm text-slate-900 uppercase">{method.carrier}</span>
                          <span className="text-3xs font-semibold text-slate-400 uppercase tracking-wider mt-0.5">
                            {method.name}
                          </span>
                          <span className="text-xs font-semibold text-blue-600 mt-2">
                            Rp{method.cost.toLocaleString('id-ID')}
                          </span>
                        </div>
                        <div className="text-right flex flex-col items-end">
                          <span className="text-3xs font-extrabold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded uppercase">
                            Estimasi
                          </span>
                          <span className="text-xs font-bold text-slate-800 mt-1">{method.etd}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* NEXT STEP BUTTON */}
              <div className="flex justify-end">
                <Button
                  size="lg"
                  onClick={() => validateStep1() && setActiveStep(2)}
                  className="rounded-xl font-bold px-8 flex items-center gap-2 cursor-pointer"
                  id="go-to-payment-button"
                >
                  Lanjut ke Pembayaran
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>

            </div>
          )}

          {/* STEP 2: PEMBAYARAN & VOUCHER */}
          {activeStep === 2 && (
            <div className="space-y-6" id="payment-step-container">
              
              {/* PAYMENT METHODS */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-blue-600" />
                    Metode Pembayaran
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">Pilih salah satu opsi pembayaran aman kami</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  {/* TRANSFER METHOD */}
                  <div
                    onClick={() => setPaymentMethod('TRANSFER')}
                    className={`border rounded-xl p-4 cursor-pointer flex flex-col justify-between transition-all duration-200 h-28 ${
                      paymentMethod === 'TRANSFER'
                        ? 'border-blue-600 bg-blue-50/20 ring-1 ring-blue-500 shadow-sm'
                        : 'border-slate-200 bg-white'
                    }`}
                    id="payment-method-transfer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-800">Bank Transfer</span>
                      {paymentMethod === 'TRANSFER' && <CheckCircle className="w-5 h-5 text-blue-600 fill-blue-50" />}
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Kirim pembayaran manual atau virtual account bank utama Indonesia.
                    </p>
                  </div>

                  {/* QRIS METHOD */}
                  <div
                    onClick={() => setPaymentMethod('QRIS')}
                    className={`border rounded-xl p-4 cursor-pointer flex flex-col justify-between transition-all duration-200 h-28 ${
                      paymentMethod === 'QRIS'
                        ? 'border-blue-600 bg-blue-50/20 ring-1 ring-blue-500 shadow-sm'
                        : 'border-slate-200 bg-white'
                    }`}
                    id="payment-method-qris"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-800">QRIS (Gopay/OVO/Dana)</span>
                      {paymentMethod === 'QRIS' && <CheckCircle className="w-5 h-5 text-blue-600 fill-blue-50" />}
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Scan kode QR secara langsung menggunakan e-wallet favorit Anda.
                    </p>
                  </div>

                  {/* COD METHOD */}
                  <div
                    onClick={() => setPaymentMethod('COD')}
                    className={`border rounded-xl p-4 cursor-pointer flex flex-col justify-between transition-all duration-200 h-28 ${
                      paymentMethod === 'COD'
                        ? 'border-blue-600 bg-blue-50/20 ring-1 ring-blue-500 shadow-sm'
                        : 'border-slate-200 bg-white'
                    }`}
                    id="payment-method-cod"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-slate-800">COD (Bayar di Tempat)</span>
                      {paymentMethod === 'COD' && <CheckCircle className="w-5 h-5 text-blue-600 fill-blue-50" />}
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Bayar secara tunai ke kurir ketika paket kiriman sampai di rumah Anda.
                    </p>
                  </div>
                </div>
              </div>

              {/* VOUCHER APPLICATION */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                    <Ticket className="w-5 h-5 text-blue-600" />
                    Voucher Diskon Toko
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">Maksimal satu voucher diskon per transaksi checkout</p>
                </div>

                {/* Applied voucher code details banner */}
                {previewData?.voucher ? (
                  <div className="mt-5 bg-green-50 border border-green-200 rounded-xl p-4 flex items-center justify-between animate-fadeIn">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Check className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-green-700">Voucher Berhasil Dipasang</p>
                        <p className="font-bold text-sm text-slate-800 uppercase">
                          {previewData.voucher.code} (Hemat Rp{previewData.voucher.discountAmount.toLocaleString('id-ID')})
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={handleRemoveVoucher}
                      className="text-xs font-bold text-red-600 hover:text-red-700 hover:underline px-3 py-1 bg-white border border-red-200 rounded-lg"
                    >
                      Lepas
                    </button>
                  </div>
                ) : (
                  <div className="mt-5 flex gap-3">
                    <input
                      type="text"
                      value={voucherCodeInput}
                      onChange={(e) => setVoucherCodeInput(e.target.value)}
                      placeholder="Masukkan kode voucher belanja"
                      className="flex-1 text-sm rounded-xl border border-slate-250 bg-white px-4 py-2.5 text-slate-800 focus:outline-none focus:border-blue-500 uppercase font-bold"
                      id="voucher-input-field"
                    />
                    <Button
                      onClick={handleApplyVoucher}
                      className="rounded-xl px-6 font-semibold text-sm cursor-pointer"
                      id="apply-voucher-button"
                    >
                      Pasang
                    </Button>
                  </div>
                )}

                {/* Error message if voucher calculation failed */}
                {previewData?.voucherError && (
                  <div className="mt-3 bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-700 font-medium flex items-center gap-2 animate-fadeIn">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>Kode voucher tidak bisa dipakai: {previewData.voucherError}</span>
                  </div>
                )}

                {/* List of active vouchers to select */}
                {vouchers.length > 0 && (
                  <div className="mt-6 border-t border-slate-100 pt-5">
                    <h3 className="font-bold text-xs text-slate-500 uppercase tracking-wider mb-3">
                      Voucher yang tersedia untukmu:
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {vouchers.map((voucher) => {
                        const isExpired = voucher.expiryDate ? new Date(voucher.expiryDate) < new Date() : false;
                        const isApplicable = previewData && previewData.summary.subtotal >= voucher.minPurchase && !isExpired;

                        return (
                          <div
                            key={voucher.id}
                            onClick={() => isApplicable && handleChooseVoucher(voucher.code)}
                            className={`border rounded-xl p-3 flex items-center justify-between transition-all duration-200 ${
                              isApplicable
                                ? 'border-dashed border-blue-300 hover:border-blue-600 bg-blue-50/5 cursor-pointer'
                                : 'border-slate-200 opacity-60 bg-slate-50 cursor-not-allowed'
                            }`}
                            id={`voucher-selection-${voucher.code}`}
                          >
                            <div className="flex gap-2.5 items-center">
                              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${isApplicable ? 'bg-blue-100/50' : 'bg-slate-200'}`}>
                                {voucher.type === 'PERCENT' ? (
                                  <Percent className="w-4.5 h-4.5 text-blue-600" />
                                ) : (
                                  <Tag className="w-4.5 h-4.5 text-blue-600" />
                                )}
                              </div>
                              <div className="text-left">
                                <span className="font-bold text-xs text-slate-800 uppercase tracking-wide block">
                                  {voucher.code}
                                </span>
                                <span className="text-2xs text-slate-500 mt-0.5 block font-medium">
                                  {voucher.type === 'PERCENT' ? `Diskon ${voucher.value}%` : `Diskon Rp${voucher.value.toLocaleString('id-ID')}`}
                                  {voucher.minPurchase > 0 && ` (Min. Rp${voucher.minPurchase.toLocaleString('id-ID')})`}
                                </span>
                              </div>
                            </div>

                            <div className="text-right flex flex-col items-end">
                              <span className="text-3xs font-semibold text-slate-400">
                                {voucher.expiryDate ? `S/d ${new Date(voucher.expiryDate).toLocaleDateString('id-ID', { month: 'short', day: 'numeric', year: 'numeric' })}` : 'Tanpa Expired'}
                              </span>
                              {isApplicable ? (
                                <button
                                  type="button"
                                  className="text-2xs font-bold text-blue-600 hover:underline mt-1"
                                >
                                  Gunakan
                                </button>
                              ) : (
                                <span className="text-3xs text-red-500 font-semibold mt-1">
                                  Min Belanja Kurang
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* ACTION BUTTONS */}
              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setActiveStep(1)}
                  className="rounded-xl font-semibold flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Pengiriman
                </Button>
                <Button
                  size="lg"
                  onClick={() => validateStep2() && setActiveStep(3)}
                  className="rounded-xl font-bold px-8 flex items-center gap-2 cursor-pointer"
                  id="go-to-review-button"
                >
                  Lanjut ke Review Order
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>

            </div>
          )}

          {/* STEP 3: REVIEW & KONFIRMASI */}
          {activeStep === 3 && (
            <div className="space-y-6" id="review-step-container">
              
              {/* CART ITEMS REVIEW */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-blue-600" />
                  Daftar Produk yang Dibeli
                </h2>

                <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl overflow-hidden">
                  {previewData?.items.map((item) => (
                    <div
                      key={item.cartItemId}
                      className="flex gap-4 p-4 hover:bg-slate-50/50 transition-colors items-center"
                      id={`review-product-${item.productId}`}
                    >
                      <div className="w-16 h-16 bg-slate-50 border border-slate-100 rounded-lg overflow-hidden shrink-0 flex items-center justify-center">
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = '/assets/placeholder-product.png';
                          }}
                        />
                      </div>

                      <div className="flex-1 min-w-0">
                        <span className="text-3xs uppercase tracking-wider font-extrabold text-blue-600">
                          {item.categoryName}
                        </span>
                        <h4 className="font-semibold text-slate-800 text-sm truncate mt-0.5">{item.name}</h4>
                        {item.variantName && (
                          <span className="inline-block text-3xs font-semibold bg-slate-100 px-2 py-0.5 rounded text-slate-500 mt-1">
                            {item.variantName}
                          </span>
                        )}
                        <p className="text-2xs text-slate-400 font-medium mt-1">
                          {item.quantity} x Rp{item.price.toLocaleString('id-ID')}
                        </p>
                      </div>

                      <div className="text-right">
                        <span className="font-bold text-slate-900 text-sm">
                          Rp{item.subtotal.toLocaleString('id-ID')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* INFO RECAPS */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* ADDRESS RECAP */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-blue-600" />
                      Alamat Pengiriman
                    </h3>
                    <button
                      onClick={() => setActiveStep(1)}
                      className="text-2xs font-bold text-blue-600 hover:underline"
                    >
                      Ubah
                    </button>
                  </div>
                  {previewData?.address ? (
                    <div className="text-xs text-slate-600 space-y-1 bg-slate-50/50 border border-slate-100 rounded-xl p-4">
                      <p className="font-bold text-slate-800">{previewData.address.recipientName} ({previewData.address.title})</p>
                      <p className="text-slate-500">{previewData.address.phone}</p>
                      <p className="text-slate-500 mt-1.5 leading-relaxed">
                        {previewData.address.address}, {previewData.address.district}, {previewData.address.city}, {previewData.address.province} ({previewData.address.postalCode})
                      </p>
                    </div>
                  ) : (
                    <p className="text-xs text-red-500 italic">Belum memilih alamat pengiriman</p>
                  )}
                </div>

                {/* SHIPPING / PAYMENT RECAP */}
                <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                      <Truck className="w-4 h-4 text-blue-600" />
                      Pengiriman & Pembayaran
                    </h3>
                    <button
                      onClick={() => setActiveStep(2)}
                      className="text-2xs font-bold text-blue-600 hover:underline"
                    >
                      Ubah
                    </button>
                  </div>
                  <div className="bg-slate-50/50 border border-slate-100 rounded-xl p-4 space-y-3.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Kurir Pengiriman:</span>
                      <span className="font-bold text-slate-800 uppercase bg-blue-100/30 text-blue-800 py-0.5 px-2 rounded">
                        {previewData?.shipping?.carrier} ({previewData?.shipping?.name}) - {previewData?.shipping?.etd}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-500">Metode Pembayaran:</span>
                      <span className="font-bold text-slate-800 uppercase bg-emerald-100/30 text-emerald-800 py-0.5 px-2 rounded">
                        {paymentMethod}
                      </span>
                    </div>
                  </div>
                </div>

              </div>

              {/* ACTION BUTTONS */}
              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setActiveStep(2)}
                  className="rounded-xl font-semibold flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Pembayaran
                </Button>
              </div>

            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Order Summary Card */}
        <div className="w-full lg:w-96 shrink-0 sticky top-24">
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-xs">
            <h2 className="text-lg font-bold text-slate-900 border-b border-slate-200 pb-4 mb-5">
              Ringkasan Belanja
            </h2>

            <div className="space-y-4 text-sm mb-6">
              {/* Items pricing subtotal */}
              <div className="flex justify-between text-slate-600">
                <span>Total Harga Produk</span>
                <span className="font-semibold text-slate-900">
                  Rp{(previewData?.summary.subtotal || 0).toLocaleString('id-ID')}
                </span>
              </div>

              {/* Voucher discounts (if any) */}
              {previewData?.summary.discountAmount && previewData?.summary.discountAmount > 0 ? (
                <div className="flex justify-between text-green-600 font-semibold bg-green-100/20 px-2 py-1 rounded">
                  <span className="flex items-center gap-1.5 text-xs">
                    <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                    Diskon Voucher
                  </span>
                  <span>-Rp{previewData.summary.discountAmount.toLocaleString('id-ID')}</span>
                </div>
              ) : null}

              {/* Delivery cost */}
              <div className="flex justify-between text-slate-600">
                <span>Biaya Ongkos Kirim</span>
                <span className="font-semibold text-slate-900">
                  {selectedCarrier ? `Rp${(previewData?.summary.shippingFee || 0).toLocaleString('id-ID')}` : 'Pilih Kurir'}
                </span>
              </div>

              {/* Indonesian VAT (PPN 11%) */}
              <div className="flex justify-between text-slate-500">
                <span className="flex items-center gap-1 text-xs">
                  PPN (11% standard)
                  <span title="PPN 11% dari Total Belanja setelah diskon">
                    <Info className="w-3 h-3 text-slate-400" />
                  </span>
                </span>
                <span className="font-semibold text-slate-600">
                  Rp{(previewData?.summary.taxAmount || 0).toLocaleString('id-ID')}
                </span>
              </div>

              {/* Grand Total Payment */}
              <div className="pt-4 border-t border-slate-250 flex justify-between items-baseline">
                <span className="text-base font-bold text-slate-900">Total Pembayaran</span>
                <span className="text-2xl font-black text-blue-600">
                  Rp{(previewData?.summary.grandTotal || 0).toLocaleString('id-ID')}
                </span>
              </div>
            </div>

            {/* ERROR STATEMENTS IN REVIEW */}
            {previewData && !previewData.isValid && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 mb-5 space-y-1.5 animate-fadeIn">
                <p className="text-xs font-bold text-red-800 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" />
                  Stok Produk Mengalami Perubahan!
                </p>
                <ul className="text-3xs text-red-600 font-medium list-disc list-inside space-y-1 pl-1">
                  {previewData.stockErrors.map((err, idx) => (
                    <li key={idx}>{err}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* DYNAMIC CHECKOUT ACTION BUTTON */}
            {activeStep < 3 ? (
              <Button
                className="w-full gap-2 py-6 text-base font-semibold rounded-xl cursor-pointer"
                onClick={() => {
                  if (activeStep === 1) {
                    if (validateStep1()) setActiveStep(2);
                  } else if (activeStep === 2) {
                    if (validateStep2()) setActiveStep(3);
                  }
                }}
                disabled={previewData && !previewData.isValid}
              >
                Lanjut ke Langkah Berikutnya
                <ChevronRight className="w-4.5 h-4.5" />
              </Button>
            ) : (
              <Button
                className="w-full gap-2 py-6 text-base font-extrabold rounded-xl bg-blue-600 hover:bg-blue-700 cursor-pointer text-white shadow-lg shadow-blue-100"
                onClick={executeOrderCheckout}
                disabled={isSubmitting || (previewData && !previewData.isValid)}
                id="place-order-button"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4.5 h-4.5 animate-spin" />
                    Membuat Pesanan...
                  </>
                ) : (
                  <>
                    Buat Pesanan Sekarang
                    <CheckCircle className="w-4.5 h-4.5" />
                  </>
                )}
              </Button>
            )}

            {/* GUEST WARNING / EMPTY FEEDBACK */}
            {previewData && previewData.items.length === 0 && (
              <p className="text-xs text-center text-red-500 mt-4 leading-relaxed font-bold bg-red-50 rounded-lg p-2.5 border border-red-100">
                Tidak ada produk aktif dalam keranjang yang dipilih. Silakan kembali ke Keranjang belanja.
              </p>
            )}
          </div>
        </div>

      </div>

      {/* CONFIRMATION DIALOG FOR ADDRESS DELETION */}
      <ConfirmationDialog
        isOpen={deleteAddressId !== null}
        onClose={() => setDeleteAddressId(null)}
        onConfirm={handleDeleteAddressConfirm}
        title="Hapus alamat pengiriman?"
        description="Apakah Anda yakin ingin menghapus alamat pengiriman ini secara permanen dari daftar alamat Anda?"
        confirmText="Hapus Alamat"
        cancelText="Batal"
        isLoading={isDeletingAddress}
        type="danger"
      />
    </div>
  );
}
