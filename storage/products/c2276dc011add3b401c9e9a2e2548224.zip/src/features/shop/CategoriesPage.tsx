import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Tag, Shirt, Sparkles, Footprints, Compass, ChevronRight } from 'lucide-react';
import api from '../../lib/axios';

interface Category {
  id: string;
  name: string;
  slug: string;
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await api.get('/categories');
      if (response.data.success) {
        setCategories(response.data.data);
      }
    } catch (error) {
      console.error('Failed to fetch categories', error);
    } finally {
      setLoading(false);
    }
  };

  // Helper function to assign elegant icons to categories dynamically based on name
  const getCategoryIcon = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes('shirt') || lower.includes('clothing') || lower.includes('apparel') || lower.includes('baju') || lower.includes('pakaian')) {
      return <Shirt className="w-8 h-8 text-blue-600" />;
    }
    if (lower.includes('shoe') || lower.includes('footwear') || lower.includes('sepatu')) {
      return <Footprints className="w-8 h-8 text-indigo-600" />;
    }
    if (lower.includes('access') || lower.includes('jewelry') || lower.includes('bag') || lower.includes('tas')) {
      return <Sparkles className="w-8 h-8 text-amber-600" />;
    }
    return <Tag className="w-8 h-8 text-emerald-600" />;
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      <div className="text-center md:text-left mb-12">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Shop by Category</h1>
        <p className="mt-2 text-slate-500">Explore curated products across our signature apparel categories.</p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white border border-slate-100 rounded-xl p-6 h-40 animate-pulse">
              <div className="w-12 h-12 bg-slate-200 rounded-lg mb-4"></div>
              <div className="h-5 bg-slate-200 rounded w-1/2 mb-2"></div>
              <div className="h-4 bg-slate-200 rounded w-1/3"></div>
            </div>
          ))}
        </div>
      ) : categories.length === 0 ? (
        <div className="text-center py-24 text-slate-500 max-w-md mx-auto">
          <Compass className="w-12 h-12 mx-auto text-slate-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-900">No categories found</h3>
          <p className="mt-1">We haven't defined any product categories yet. Check back soon!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => navigate(`/products?categoryId=${category.id}`)}
              className="group bg-white border border-slate-200 hover:border-blue-500 hover:shadow-md transition-all duration-300 rounded-xl p-6 flex items-start gap-4 text-left cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <div className="p-3 bg-slate-50 group-hover:bg-blue-50 rounded-lg transition-colors shrink-0">
                {getCategoryIcon(category.name)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors truncate">
                  {category.name}
                </h3>
                <p className="text-sm text-slate-500 mt-1">
                  View apparel collection
                </p>
                <div className="flex items-center gap-1 text-sm font-semibold text-blue-600 mt-4 opacity-0 group-hover:opacity-100 group-focus:opacity-100 transition-opacity">
                  Browse products
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
