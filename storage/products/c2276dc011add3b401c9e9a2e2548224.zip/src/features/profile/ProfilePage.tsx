import { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { 
  User, Lock, MapPin, Plus, Trash2, Edit, Check, Globe, 
  Phone, Calendar, Users, Eye, EyeOff, Save, Trash,
  ShoppingBag, XCircle, RefreshCw, Copy, ChevronDown, ChevronUp, Clock, Receipt, CheckCircle, Package, CreditCard, X, Image as ImageIcon
} from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import api from '../../lib/axios';
import { useAuthStore } from '../../store/useAuthStore';
import { useToastStore } from '../../store/useToastStore';
import Modal from '../../components/ui/Modal';
import ConfirmationDialog from '../../components/ui/ConfirmationDialog';
import { Skeleton } from '../../components/ui/Skeleton';

interface Address {
  id: string;
  title: string;
  recipientName: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  postalCode: string;
  address: string;
  notes: string | null;
  isDefault: boolean;
}

export default function ProfilePage() {
  const { user, token, login, isAuthenticated } = useAuthStore();
  const { addToast } = useToastStore();

  const [activeTab, setActiveTab] = useState<'profile' | 'addresses' | 'orders'>('profile');
  const [loading, setLoading] = useState(true);

  // Profile Form States
  const [profileData, setProfileData] = useState({
    name: '',
    email: '',
    phone: '',
    dob: '',
    gender: '',
    avatar: '',
    password: '',
  });
  const [profileErrors, setProfileErrors] = useState<Record<string, string>>({});
  const [updatingProfile, setUpdatingProfile] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Address States
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loadingAddresses, setLoadingAddresses] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);

  // Address Form State
  const [addressData, setAddressData] = useState({
    title: 'Alamat',
    recipientName: '',
    phone: '',
    province: '',
    city: '',
    district: '',
    postalCode: '',
    address: '',
    notes: '',
    isDefault: false,
  });
  const [addressErrors, setAddressErrors] = useState<Record<string, string>>({});
  const [submittingAddress, setSubmittingAddress] = useState(false);

  // Customer Orders States
  const [customerOrders, setCustomerOrders] = useState<any[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [copiedOrderId, setCopiedOrderId] = useState<string | null>(null);

  // Customer Payment States
  const [uploadingProofMap, setUploadingProofMap] = useState<Record<string, boolean>>({});
  const [selectedProofFilesMap, setSelectedProofFilesMap] = useState<Record<string, File | null>>({});
  const [proofPreviewsMap, setProofPreviewsMap] = useState<Record<string, string | null>>({});
  const [selectedPaymentMethodMap, setSelectedPaymentMethodMap] = useState<Record<string, string>>({});
  const [customerNotesMap, setCustomerNotesMap] = useState<Record<string, string>>({});

  const handleFileChange = (orderId: string, file: File | null) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      addToast('File terlalu besar! Maksimal ukuran file adalah 5MB.', 'error');
      return;
    }
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      addToast('Format file tidak didukung! Gunakan format JPG, JPEG, PNG, atau WEBP.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setProofPreviewsMap(prev => ({ ...prev, [orderId]: reader.result as string }));
    };
    reader.readAsDataURL(file);
    setSelectedProofFilesMap(prev => ({ ...prev, [orderId]: file }));
  };

  const handleUploadAndSubmitPayment = async (orderId: string, amount: number) => {
    const file = selectedProofFilesMap[orderId];
    if (!file) {
      addToast('Silakan pilih atau unggah bukti transfer terlebih dahulu!', 'error');
      return;
    }

    setUploadingProofMap(prev => ({ ...prev, [orderId]: true }));
    try {
      const formData = new FormData();
      formData.append('file', file);

      const uploadResponse = await api.post('/payments/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      if (!uploadResponse.data.success) {
        throw new Error('Gagal mengunggah file bukti pembayaran');
      }

      const proofUrl = uploadResponse.data.data.url;
      const paymentMethod = selectedPaymentMethodMap[orderId] || 'BANK_TRANSFER';
      const customerNote = customerNotesMap[orderId] || '';

      const createResponse = await api.post('/payments', {
        orderId,
        amount,
        paymentMethod,
        proofOfPayment: proofUrl,
        note: customerNote,
      });

      if (createResponse.data.success) {
        addToast('Bukti pembayaran berhasil diunggah! Menunggu verifikasi admin.', 'success');
        setSelectedProofFilesMap(prev => ({ ...prev, [orderId]: null }));
        setProofPreviewsMap(prev => ({ ...prev, [orderId]: null }));
        fetchCustomerOrders();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal memproses pembayaran Anda', 'error');
    } finally {
      setUploadingProofMap(prev => ({ ...prev, [orderId]: false }));
    }
  };

  useEffect(() => {
    if (isAuthenticated && user) {
      fetchProfile();
      fetchAddresses();
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated && user && activeTab === 'orders') {
      fetchCustomerOrders();
    }
  }, [isAuthenticated, activeTab]);

  const fetchCustomerOrders = async () => {
    setLoadingOrders(true);
    try {
      const response = await api.get('/orders');
      if (response.data.success) {
        setCustomerOrders(response.data.data);
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal mengambil riwayat pesanan', 'error');
    } finally {
      setLoadingOrders(false);
    }
  };

  const handleCancelCustomerOrder = async (orderId: string) => {
    const confirmCancel = window.confirm('Apakah Anda yakin ingin membatalkan pesanan ini? Stok produk akan dikembalikan.');
    if (!confirmCancel) return;

    try {
      const response = await api.patch(`/orders/${orderId}/cancel`, {
        note: 'Dibatalkan oleh Pelanggan.'
      });
      if (response.data.success) {
        addToast('Pesanan berhasil dibatalkan', 'success');
        fetchCustomerOrders();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Gagal membatalkan pesanan', 'error');
    }
  };

  const handleCopyCustomerOrderId = (orderId: string) => {
    navigator.clipboard.writeText(orderId);
    setCopiedOrderId(orderId);
    addToast('ID Pesanan disalin ke clipboard', 'success');
    setTimeout(() => setCopiedOrderId(null), 2500);
  };

  const getCustomerStatusBadge = (status: string) => {
    switch (status.toUpperCase()) {
      case 'PENDING':
        return { bg: 'bg-amber-50 text-amber-700 border-amber-200', label: 'Menunggu Konfirmasi' };
      case 'WAITING_PAYMENT':
        return { bg: 'bg-yellow-50 text-yellow-700 border-yellow-200', label: 'Menunggu Pembayaran' };
      case 'PAID':
        return { bg: 'bg-blue-50 text-blue-700 border-blue-200', label: 'Pembayaran Diterima' };
      case 'PROCESSING':
        return { bg: 'bg-indigo-50 text-indigo-700 border-indigo-200', label: 'Diproses' };
      case 'PACKING':
        return { bg: 'bg-purple-50 text-purple-700 border-purple-200', label: 'Dikemas' };
      case 'SHIPPED':
        return { bg: 'bg-sky-50 text-sky-700 border-sky-200', label: 'Dikirim' };
      case 'DELIVERED':
        return { bg: 'bg-teal-50 text-teal-700 border-teal-200', label: 'Sampai Tujuan' };
      case 'COMPLETED':
        return { bg: 'bg-green-50 text-green-700 border-green-200', label: 'Selesai' };
      case 'CANCELLED':
        return { bg: 'bg-rose-50 text-rose-700 border-rose-200', label: 'Dibatalkan' };
      case 'REFUND':
        return { bg: 'bg-red-50 text-red-700 border-red-200', label: 'Refund' };
      default:
        return { bg: 'bg-slate-50 text-slate-700 border-slate-200', label: status };
    }
  };

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const fetchProfile = async () => {
    setLoading(true);
    try {
      const response = await api.get('/profile');
      if (response.data.success) {
        const p = response.data.data;
        setProfileData({
          name: p.name || '',
          email: p.email || '',
          phone: p.phone || '',
          dob: p.dob || '',
          gender: p.gender || '',
          avatar: p.avatar || '',
          password: '',
        });
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to fetch profile details', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchAddresses = async () => {
    setLoadingAddresses(true);
    try {
      const response = await api.get('/profile/addresses');
      if (response.data.success) {
        setAddresses(response.data.data);
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to fetch addresses', 'error');
    } finally {
      setLoadingAddresses(false);
    }
  };

  // Profile Handlers
  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
    if (profileErrors[name]) {
      setProfileErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateProfileForm = () => {
    const errors: Record<string, string> = {};
    if (!profileData.name || profileData.name.length < 3) {
      errors.name = 'Name must be at least 3 characters';
    }
    if (!profileData.email || !/\S+@\S+\.\S+/.test(profileData.email)) {
      errors.email = 'Invalid email address';
    }
    if (profileData.phone && profileData.phone.length < 8) {
      errors.phone = 'Phone number must be at least 8 digits';
    }
    if (profileData.password && profileData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }
    if (profileData.dob && !/^\d{4}-\d{2}-\d{2}$/.test(profileData.dob)) {
      errors.dob = 'Date of birth must be in YYYY-MM-DD format';
    }

    setProfileErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateProfileForm()) return;

    setUpdatingProfile(true);
    try {
      const payload: any = {
        name: profileData.name,
        email: profileData.email,
        phone: profileData.phone || null,
        dob: profileData.dob || null,
        gender: profileData.gender || null,
        avatar: profileData.avatar || null,
      };

      if (profileData.password) {
        payload.password = profileData.password;
      }

      const response = await api.put('/profile', payload);
      if (response.data.success) {
        addToast('Profile updated successfully', 'success');
        
        // Sync the header and AuthStore state with new name/email/role
        if (user && token) {
          login({
            id: user.id,
            name: response.data.data.name,
            email: response.data.data.email,
            role: user.role,
          }, token);
        }
        
        // Clear password input field after successful save
        setProfileData(prev => ({ ...prev, password: '' }));
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to update profile', 'error');
    } finally {
      setUpdatingProfile(false);
    }
  };

  // Address Form Handlers
  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    setAddressData(prev => ({ 
      ...prev, 
      [name]: type === 'checkbox' ? checked : value 
    }));
    if (addressErrors[name]) {
      setAddressErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateAddressForm = () => {
    const errors: Record<string, string> = {};
    if (!addressData.title || addressData.title.length < 2) {
      errors.title = 'Label/Title is required (e.g. Rumah)';
    }
    if (!addressData.recipientName || addressData.recipientName.length < 2) {
      errors.recipientName = 'Recipient name is required';
    }
    if (!addressData.phone || addressData.phone.length < 8) {
      errors.phone = 'Valid phone number is required (min 8 digits)';
    }
    if (!addressData.province) errors.province = 'Province is required';
    if (!addressData.city) errors.city = 'City is required';
    if (!addressData.district) errors.district = 'District is required';
    if (!addressData.postalCode || addressData.postalCode.length < 3) {
      errors.postalCode = 'Postal code must be at least 3 digits';
    }
    if (!addressData.address || addressData.address.length < 5) {
      errors.address = 'Full address details must be at least 5 characters';
    }

    setAddressErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleOpenCreateAddress = () => {
    setSelectedAddress(null);
    setAddressData({
      title: 'Alamat',
      recipientName: '',
      phone: '',
      province: '',
      city: '',
      district: '',
      postalCode: '',
      address: '',
      notes: '',
      isDefault: addresses.length === 0, // Auto default if first address
    });
    setAddressErrors({});
    setIsAddressModalOpen(true);
  };

  const handleOpenEditAddress = (address: Address) => {
    setSelectedAddress(address);
    setAddressData({
      title: address.title,
      recipientName: address.recipientName,
      phone: address.phone,
      province: address.province,
      city: address.city,
      district: address.district,
      postalCode: address.postalCode,
      address: address.address,
      notes: address.notes || '',
      isDefault: address.isDefault,
    });
    setAddressErrors({});
    setIsAddressModalOpen(true);
  };

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateAddressForm()) return;

    setSubmittingAddress(true);
    try {
      if (selectedAddress) {
        // Edit Mode
        const response = await api.put(`/profile/addresses/${selectedAddress.id}`, {
          ...addressData,
          notes: addressData.notes || undefined,
        });
        if (response.data.success) {
          addToast('Address updated successfully', 'success');
          setIsAddressModalOpen(false);
          fetchAddresses();
        }
      } else {
        // Create Mode
        const response = await api.post('/profile/addresses', {
          ...addressData,
          notes: addressData.notes || undefined,
        });
        if (response.data.success) {
          addToast('New address saved successfully', 'success');
          setIsAddressModalOpen(false);
          fetchAddresses();
        }
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to save address', 'error');
    } finally {
      setSubmittingAddress(false);
    }
  };

  const handleOpenDeleteAddress = (address: Address) => {
    setSelectedAddress(address);
    setIsConfirmDeleteOpen(true);
  };

  const handleDeleteAddressConfirm = async () => {
    if (!selectedAddress) return;
    setSubmittingAddress(true);
    try {
      await api.delete(`/profile/addresses/${selectedAddress.id}`);
      addToast('Address deleted successfully', 'success');
      setIsConfirmDeleteOpen(false);
      fetchAddresses();
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to delete address', 'error');
    } finally {
      setSubmittingAddress(false);
    }
  };

  const handleSetDefaultAddress = async (address: Address) => {
    if (address.isDefault) return;
    try {
      const response = await api.put(`/profile/addresses/${address.id}`, {
        ...address,
        isDefault: true
      });
      if (response.data.success) {
        addToast('Default address updated successfully', 'success');
        fetchAddresses();
      }
    } catch (error: any) {
      addToast(error.response?.data?.message || 'Failed to set default address', 'error');
    }
  };

  return (
    <div className="container mx-auto max-w-5xl py-8 px-4 sm:px-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 font-sans">My Personal Settings</h1>
          <p className="text-sm text-slate-500 mt-1">Manage your account profile details, security password, and shipping address book.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Left Column Navigation Tabs */}
        <div className="md:col-span-1 space-y-2">
          <button
            onClick={() => setActiveTab('profile')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'profile'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-100'
                : 'bg-white text-slate-600 border border-slate-200/60 hover:bg-slate-50'
            }`}
          >
            <User className="w-4 h-4 shrink-0" />
            Profile Details
          </button>
          <button
            onClick={() => setActiveTab('addresses')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'addresses'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-100'
                : 'bg-white text-slate-600 border border-slate-200/60 hover:bg-slate-50'
            }`}
          >
            <MapPin className="w-4 h-4 shrink-0" />
            Saved Addresses
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
              activeTab === 'orders'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-100'
                : 'bg-white text-slate-600 border border-slate-200/60 hover:bg-slate-50'
            }`}
          >
            <ShoppingBag className="w-4 h-4 shrink-0" />
            Riwayat Pesanan
          </button>
        </div>

        {/* Right Column Content Areas */}
        <div className="md:col-span-3">
          {activeTab === 'profile' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 sm:p-8">
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2 mb-6">
                <User className="w-5 h-5 text-blue-600" />
                Profile Information
              </h2>

              {loading ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-4 animate-pulse">
                    <div className="w-12 h-12 bg-slate-100 rounded-full" />
                    <div className="h-4 bg-slate-100 rounded w-1/4" />
                  </div>
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <form onSubmit={handleUpdateProfile} className="space-y-6">
                  {/* Photo Profile and Avatar */}
                  <div className="flex flex-col sm:flex-row items-center gap-6 pb-6 border-b border-slate-100">
                    {profileData.avatar ? (
                      <img 
                        src={profileData.avatar} 
                        alt="Profile avatar" 
                        className="w-20 h-20 rounded-full object-cover border-2 border-slate-100 shadow-sm"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-20 h-20 rounded-full bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-3xl uppercase border-2 border-slate-100">
                        {profileData.name.charAt(0)}
                      </div>
                    )}
                    <div className="space-y-1.5 flex-1 w-full">
                      <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Avatar / Image URL</label>
                      <Input
                        name="avatar"
                        className="rounded-xl border-slate-200 bg-slate-50/50"
                        placeholder="Paste profile picture URL..."
                        value={profileData.avatar}
                        onChange={handleProfileChange}
                      />
                    </div>
                  </div>

                  {/* Form fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Full Name *</label>
                      <Input
                        name="name"
                        className={`rounded-xl h-11 border-slate-200 ${profileErrors.name ? 'border-rose-500 focus:ring-rose-200' : ''}`}
                        value={profileData.name}
                        onChange={handleProfileChange}
                        required
                      />
                      {profileErrors.name && <p className="text-xs text-rose-500">{profileErrors.name}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Email Address *</label>
                      <Input
                        name="email"
                        type="email"
                        className={`rounded-xl h-11 border-slate-200 ${profileErrors.email ? 'border-rose-500 focus:ring-rose-200' : ''}`}
                        value={profileData.email}
                        onChange={handleProfileChange}
                        required
                      />
                      {profileErrors.email && <p className="text-xs text-rose-500">{profileErrors.email}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Phone Number (HP)</label>
                      <div className="relative">
                        <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <Input
                          name="phone"
                          className={`pl-10 rounded-xl h-11 border-slate-200 ${profileErrors.phone ? 'border-rose-500 focus:ring-rose-200' : ''}`}
                          placeholder="e.g. 0812345678"
                          value={profileData.phone}
                          onChange={handleProfileChange}
                        />
                      </div>
                      {profileErrors.phone && <p className="text-xs text-rose-500">{profileErrors.phone}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Date of Birth (Tanggal Lahir)</label>
                      <div className="relative">
                        <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <Input
                          name="dob"
                          type="date"
                          className={`pl-10 rounded-xl h-11 border-slate-200 ${profileErrors.dob ? 'border-rose-500 focus:ring-rose-200' : ''}`}
                          value={profileData.dob}
                          onChange={handleProfileChange}
                        />
                      </div>
                      {profileErrors.dob && <p className="text-xs text-rose-500">{profileErrors.dob}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Gender (Jenis Kelamin)</label>
                      <div className="relative">
                        <Users className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <select
                          name="gender"
                          className="pl-10 bg-white border border-slate-200 rounded-xl px-3 text-sm text-slate-700 h-11 w-full focus:ring-1 focus:ring-blue-500"
                          value={profileData.gender}
                          onChange={handleProfileChange}
                        >
                          <option value="">Select Gender</option>
                          <option value="MALE">Male</option>
                          <option value="FEMALE">Female</option>
                          <option value="OTHER">Other</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Update Password (Security)</label>
                      <div className="relative">
                        <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <Input
                          name="password"
                          type={showPassword ? 'text' : 'password'}
                          className={`pl-10 pr-10 rounded-xl h-11 border-slate-200 ${profileErrors.password ? 'border-rose-500 focus:ring-rose-200' : ''}`}
                          placeholder="Enter new password to change"
                          value={profileData.password}
                          onChange={handleProfileChange}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      {profileErrors.password && <p className="text-xs text-rose-500">{profileErrors.password}</p>}
                    </div>
                  </div>

                  <div className="pt-6 border-t border-slate-50 flex justify-end">
                    <Button type="submit" disabled={updatingProfile} className="rounded-xl px-6 h-11 flex items-center gap-2 font-semibold">
                      <Save className="w-4 h-4" />
                      {updatingProfile ? 'Saving Details...' : 'Save Profile Changes'}
                    </Button>
                  </div>
                </form>
              )}
            </div>
          )}

          {activeTab === 'addresses' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-blue-600" />
                  Shipping Address Book
                </h2>
                <Button 
                  onClick={handleOpenCreateAddress}
                  className="rounded-xl flex items-center gap-1.5 text-xs font-semibold h-9 px-3"
                  size="sm"
                >
                  <Plus className="w-4 h-4" />
                  Add New Address
                </Button>
              </div>

              {loadingAddresses ? (
                <div className="space-y-4">
                  <Skeleton className="h-28 w-full rounded-2xl animate-pulse" />
                  <Skeleton className="h-28 w-full rounded-2xl animate-pulse" />
                </div>
              ) : addresses.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <MapPin className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-600 font-semibold">No Saved Shipping Address Found</p>
                  <p className="text-slate-400 text-xs mt-1 max-w-sm mx-auto">Add a shipping address to ensure faster processing times during your order checkouts.</p>
                  <Button onClick={handleOpenCreateAddress} className="rounded-xl mt-4 font-semibold">
                    Add First Address
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {addresses.map((addr) => (
                    <div 
                      key={addr.id} 
                      className={`p-5 rounded-2xl border transition-all ${
                        addr.isDefault 
                          ? 'bg-blue-50/25 border-blue-200 shadow-sm' 
                          : 'bg-white border-slate-100 hover:border-slate-200 hover:shadow-xs'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-800 text-base">{addr.title}</span>
                          {addr.isDefault ? (
                            <span className="text-[10px] bg-blue-100 text-blue-700 font-bold px-2 py-0.5 rounded-md uppercase tracking-wider">Default Address</span>
                          ) : (
                            <button
                              onClick={() => handleSetDefaultAddress(addr)}
                              className="text-xs text-blue-600 hover:text-blue-700 font-medium hover:underline transition-all"
                            >
                              Set as Default
                            </button>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5 self-end sm:self-auto">
                          <button
                            onClick={() => handleOpenEditAddress(addr)}
                            className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-700 transition-colors"
                            title="Edit Address"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleOpenDeleteAddress(addr)}
                            className="p-1.5 hover:bg-rose-50 rounded-lg text-rose-500 hover:text-rose-700 transition-colors"
                            title="Delete Address"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="mt-3 space-y-1 text-sm text-slate-600">
                        <p className="font-bold text-slate-800 flex items-center gap-1.5">
                          {addr.recipientName}
                          <span className="text-xs font-normal text-slate-400 font-mono">| {addr.phone}</span>
                        </p>
                        <p className="leading-relaxed">
                          {addr.address}, Kec. {addr.district}, Kota {addr.city}, Prov. {addr.province} - {addr.postalCode}
                        </p>
                        {addr.notes && (
                          <div className="mt-2 inline-flex items-center gap-1.5 bg-amber-50 px-2.5 py-1 rounded-lg text-xs font-medium text-amber-700">
                            <span className="font-semibold uppercase tracking-wider text-[10px] bg-amber-200 text-amber-800 px-1 rounded">Catatan:</span>
                            {addr.notes}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-blue-600" />
                  Riwayat Belanja Saya
                </h2>
                <Button 
                  onClick={fetchCustomerOrders}
                  variant="outline"
                  className="rounded-xl flex items-center gap-1.5 text-xs font-semibold h-9 px-3 border-slate-200"
                  size="sm"
                  disabled={loadingOrders}
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingOrders ? 'animate-spin text-blue-500' : ''}`} />
                  Refresh
                </Button>
              </div>

              {loadingOrders ? (
                <div className="space-y-4">
                  <Skeleton className="h-28 w-full rounded-2xl animate-pulse" />
                  <Skeleton className="h-28 w-full rounded-2xl animate-pulse" />
                </div>
              ) : customerOrders.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-600 font-semibold">Belum Ada Riwayat Pesanan</p>
                  <p className="text-slate-400 text-xs mt-1 max-w-sm mx-auto">Anda belum pernah melakukan pemesanan produk di toko kami. Mulai belanja sekarang untuk melihat riwayat belanja Anda di sini!</p>
                  <Button onClick={() => window.location.href = '/products'} className="rounded-xl mt-4 font-semibold">
                    Belanja Sekarang
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {customerOrders.map((order) => {
                    const isExpanded = expandedOrderId === order.id;
                    const badge = getCustomerStatusBadge(order.status);
                    return (
                      <div 
                        key={order.id} 
                        className={`border rounded-2xl overflow-hidden transition-all duration-300 ${
                          isExpanded 
                            ? 'border-blue-150 bg-slate-50/20 shadow-xs' 
                            : 'border-slate-100 bg-white hover:border-slate-200'
                        }`}
                      >
                        {/* Order Summary Row */}
                        <div 
                          onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                          className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
                        >
                          <div className="space-y-1.5">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-mono text-xs font-semibold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200/50">
                                {order.id.slice(0, 8)}...
                              </span>
                              <span className="text-xs text-slate-400">
                                {new Date(order.createdAt).toLocaleDateString('id-ID', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric'
                                })}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 font-bold">
                              Total: <span className="text-sm text-blue-600 font-black">Rp{order.totalAmount.toLocaleString('id-ID')}</span> ({order.items.length} item)
                            </p>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${badge.bg}`}>
                              <span className="w-1.5 h-1.5 rounded-full bg-current shrink-0" />
                              {badge.label}
                            </span>
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                          </div>
                        </div>

                        {/* Order Expanded Details Drawer */}
                        {isExpanded && (
                          <div className="border-t border-slate-100 p-5 bg-white space-y-5 animate-slide-down">
                            {/* Items ordered */}
                            <div className="space-y-2">
                              <p className="text-2xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                                <Receipt className="w-3.5 h-3.5" />
                                Rincian Item Belanjaan
                              </p>
                              <div className="divide-y divide-slate-100 border border-slate-100 rounded-xl px-4 py-1.5 bg-slate-50/10">
                                {order.items.map((item: any) => (
                                  <div key={item.id} className="py-2.5 flex justify-between items-center gap-4 text-xs text-slate-600">
                                    <div>
                                      <p className="font-bold text-slate-800">{item.product.name}</p>
                                      {item.variant && (
                                        <p className="text-2xs text-slate-400 mt-0.5">
                                          Varian: {[item.variant.size, item.variant.color].filter(Boolean).join(' - ')}
                                        </p>
                                      )}
                                      <p className="text-2xs text-slate-400 font-mono mt-0.5">
                                        {item.quantity} x Rp{item.price.toLocaleString('id-ID')}
                                      </p>
                                    </div>
                                    <span className="font-black text-slate-900">
                                      Rp{(item.quantity * item.price).toLocaleString('id-ID')}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Address details & Shipping Fee */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
                              {/* Shipping address details */}
                              <div className="space-y-2">
                                <p className="text-2xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                                  <MapPin className="w-3.5 h-3.5" />
                                  Alamat Pengiriman
                                </p>
                                <div className="p-3 border border-slate-100 bg-slate-50/20 rounded-xl text-slate-600 leading-relaxed font-sans whitespace-pre-line">
                                  {order.shippingAddress}
                                  {order.shippingCarrier && (
                                    <p className="mt-2 text-2xs text-slate-400 font-semibold uppercase tracking-wider">
                                      Kurir: <span className="font-bold text-slate-700">{order.shippingCarrier}</span>
                                    </p>
                                  )}
                                </div>
                              </div>

                              {/* Breakdown calculations */}
                              <div className="space-y-2">
                                <p className="text-2xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                                  <Receipt className="w-3.5 h-3.5" />
                                  Rangkuman Biaya
                                </p>
                                <div className="p-3 border border-slate-100 bg-slate-50/20 rounded-xl space-y-2 text-slate-600">
                                  <div className="flex justify-between">
                                    <span>Subtotal Belanja</span>
                                    <span className="font-semibold text-slate-800">Rp{order.subtotal.toLocaleString('id-ID')}</span>
                                  </div>
                                  {order.discountAmount > 0 && (
                                    <div className="flex justify-between text-rose-600">
                                      <span>Potongan Voucher</span>
                                      <span className="font-semibold">- Rp{order.discountAmount.toLocaleString('id-ID')}</span>
                                    </div>
                                  )}
                                  <div className="flex justify-between">
                                    <span>Ongkos Kirim</span>
                                    <span className="font-semibold text-slate-800">Rp{order.shippingFee.toLocaleString('id-ID')}</span>
                                  </div>
                                  {order.taxAmount > 0 && (
                                    <div className="flex justify-between">
                                      <span>Pajak (PPN 11%)</span>
                                      <span className="font-semibold text-slate-800">Rp{order.taxAmount.toLocaleString('id-ID')}</span>
                                    </div>
                                  )}
                                  <div className="border-t border-slate-100 pt-2 flex justify-between font-bold text-sm text-slate-800">
                                    <span>Total Bayar</span>
                                    <span className="text-blue-600 font-black">Rp{order.totalAmount.toLocaleString('id-ID')}</span>
                                  </div>
                                  <div className="flex justify-between text-[10px] font-bold uppercase tracking-wider bg-slate-100 px-2 py-1 rounded mt-1">
                                    <span>Status Pembayaran:</span>
                                    <span className={order.paymentStatus === 'PAID' ? 'text-green-600' : 'text-amber-600'}>
                                      {order.paymentStatus === 'PAID' ? 'LUNAS' : order.paymentStatus}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Tracking Status History / Timeline */}
                            <div className="space-y-2">
                              <p className="text-2xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                                <Clock className="w-3.5 h-3.5" />
                                Status Pelacakan Paket
                              </p>
                              <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/10 space-y-3 relative pl-6 before:absolute before:left-4 before:top-1.5 before:bottom-1.5 before:w-0.5 before:bg-slate-150">
                                {order.timeline && order.timeline.length > 0 ? (
                                  order.timeline.map((log: any, idx: number) => {
                                    const isLatest = idx === order.timeline.length - 1;
                                    const logBadge = getCustomerStatusBadge(log.status);
                                    return (
                                      <div key={log.id} className="relative space-y-0.5 text-xs">
                                        <span className={`absolute -left-[14px] top-1.5 w-2 h-2 rounded-full border bg-white ${
                                          isLatest ? 'border-blue-500 bg-blue-100' : 'border-slate-300'
                                        }`} />
                                        <div className="flex justify-between items-center gap-2">
                                          <span className={`font-bold ${isLatest ? 'text-blue-600' : 'text-slate-700'}`}>
                                            {logBadge.label}
                                          </span>
                                          <span className="font-mono text-[10px] text-slate-400">
                                            {new Date(log.createdAt).toLocaleString('id-ID', {
                                              day: 'numeric',
                                              month: 'short',
                                              hour: '2-digit',
                                              minute: '2-digit'
                                            })}
                                          </span>
                                        </div>
                                        {log.note && (
                                          <p className="text-2xs text-slate-400 leading-snug">{log.note}</p>
                                        )}
                                      </div>
                                    );
                                  })
                                ) : (
                                  <p className="text-2xs text-slate-400 italic">Belum ada pembaruan pelacakan log.</p>
                                )}
                              </div>
                            </div>

                            {/* Payment Section */}
                            <div className="border-t border-slate-100 pt-5 space-y-4">
                              <p className="text-2xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                                <CreditCard className="w-3.5 h-3.5 text-blue-600" />
                                Informasi Pembayaran & Pelunasan
                              </p>

                              {order.paymentStatus === 'PAID' ? (
                                <div className="p-4 bg-emerald-50 border border-emerald-150 rounded-2xl flex items-start gap-3">
                                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                                  <div>
                                    <h4 className="text-sm font-bold text-emerald-800">Pembayaran Terverifikasi Lunas</h4>
                                    <p className="text-xs text-emerald-600 leading-relaxed mt-1">
                                      Terima kasih! Pembayaran Anda sebesar <span className="font-bold">Rp{order.totalAmount.toLocaleString('id-ID')}</span> telah kami terima dan verifikasi dengan sukses. Pesanan Anda saat ini sedang diproses.
                                    </p>
                                  </div>
                                </div>
                              ) : order.paymentStatus === 'WAITING_VERIFICATION' ? (
                                <div className="p-4 bg-blue-50 border border-blue-150 rounded-2xl flex items-start gap-3">
                                  <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5 animate-pulse" />
                                  <div>
                                    <h4 className="text-sm font-bold text-blue-800">Menunggu Verifikasi Pembayaran</h4>
                                    <p className="text-xs text-blue-600 leading-relaxed mt-1">
                                      Bukti transfer Anda telah berhasil dikirimkan dan saat ini sedang dalam proses verifikasi manual oleh tim admin kami. Proses verifikasi biasanya memakan waktu kurang dari 15 menit. Mohon tunggu sejenak!
                                    </p>
                                  </div>
                                </div>
                              ) : (
                                <div className="p-5 border border-slate-200 rounded-2xl bg-slate-50/20 space-y-5">
                                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                                    <div className="space-y-0.5">
                                      <span className="text-xs text-slate-500 font-bold uppercase tracking-wider text-[10px]">Pilih Metode Pembayaran:</span>
                                      <div className="flex flex-wrap gap-2 mt-1.5">
                                        {['BANK_TRANSFER', 'QRIS', 'EWALLET'].map((m) => (
                                          <button
                                            key={m}
                                            type="button"
                                            onClick={() => setSelectedPaymentMethodMap(prev => ({ ...prev, [order.id]: m }))}
                                            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${
                                              (selectedPaymentMethodMap[order.id] || 'BANK_TRANSFER') === m
                                                ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                                            }`}
                                          >
                                            {m === 'BANK_TRANSFER' ? 'Transfer Bank' : m === 'QRIS' ? 'QRIS' : 'E-Wallet'}
                                          </button>
                                        ))}
                                      </div>
                                    </div>
                                    <div className="text-left sm:text-right">
                                      <p className="text-xs text-slate-500 font-medium">Total yang harus dibayar:</p>
                                      <p className="text-lg font-black text-blue-600">Rp{order.totalAmount.toLocaleString('id-ID')}</p>
                                    </div>
                                  </div>

                                  {/* Payment method specific display */}
                                  {(selectedPaymentMethodMap[order.id] || 'BANK_TRANSFER') === 'BANK_TRANSFER' && (
                                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2.5 text-xs">
                                      <p className="font-bold text-slate-700">Instruksi Transfer Bank:</p>
                                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div className="space-y-1">
                                          <p className="text-slate-500">Nama Bank:</p>
                                          <p className="font-extrabold text-slate-800 text-sm">Bank Central Asia (BCA)</p>
                                        </div>
                                        <div className="space-y-1">
                                          <p className="text-slate-500">Nomor Rekening:</p>
                                          <p className="font-mono font-extrabold text-blue-600 text-sm flex items-center gap-1">
                                            8080-999-111
                                            <button 
                                              onClick={() => {
                                                navigator.clipboard.writeText('8080999111');
                                                addToast('Nomor Rekening disalin', 'success');
                                              }}
                                              className="text-slate-400 hover:text-blue-500"
                                            >
                                              <Copy className="w-3.5 h-3.5" />
                                            </button>
                                          </p>
                                        </div>
                                        <div className="space-y-1">
                                          <p className="text-slate-500">Nama Pemilik Rekening:</p>
                                          <p className="font-extrabold text-slate-800">PT Luxe Store Indonesia</p>
                                        </div>
                                        <div className="space-y-1">
                                          <p className="text-slate-500">Jumlah Transfer Pas:</p>
                                          <p className="font-extrabold text-slate-800 text-sm">Rp{order.totalAmount.toLocaleString('id-ID')}</p>
                                        </div>
                                      </div>
                                    </div>
                                  )}

                                  {(selectedPaymentMethodMap[order.id] || 'BANK_TRANSFER') === 'QRIS' && (
                                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 flex flex-col sm:flex-row items-center gap-5 text-xs">
                                      <div className="w-32 h-32 bg-white rounded-lg p-2 border border-slate-200/50 shadow-xs flex items-center justify-center shrink-0">
                                        <img
                                          src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=LuxeStorePOS-Payment-Simulation"
                                          referrerPolicy="no-referrer"
                                          alt="QRIS Code"
                                          className="w-full h-full object-contain"
                                        />
                                      </div>
                                      <div className="space-y-1.5 leading-relaxed text-slate-600">
                                        <p className="font-extrabold text-slate-800 text-sm">Pembayaran via QRIS (Otomatis):</p>
                                        <p>1. Pindai kode QR di samping menggunakan aplikasi e-wallet Anda (GoPay, OVO, ShopeePay, DANA) atau m-banking.</p>
                                        <p>2. Masukkan nominal tagihan tepat sebesar <span className="font-black text-slate-800">Rp{order.totalAmount.toLocaleString('id-ID')}</span>.</p>
                                        <p>3. Ambil screenshot bukti transfer sukses, lalu unggah di bawah.</p>
                                      </div>
                                    </div>
                                  )}

                                  {(selectedPaymentMethodMap[order.id] || 'BANK_TRANSFER') === 'EWALLET' && (
                                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2.5 text-xs text-slate-600">
                                      <p className="font-bold text-slate-700">Instruksi Transfer E-Wallet:</p>
                                      <p>Silakan kirimkan transfer saldo GoPay atau OVO Anda ke nomor handphone merchant kami di bawah ini:</p>
                                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-white border border-slate-100 rounded-lg">
                                        <div>
                                          <p className="text-slate-500">Nomor HP / Merchant No:</p>
                                          <p className="font-mono font-extrabold text-slate-800 text-sm">0812-3456-7890</p>
                                        </div>
                                        <div>
                                          <p className="text-slate-500">Atas Nama Merchant:</p>
                                          <p className="font-extrabold text-slate-800">LuxeStore POS Indonesia</p>
                                        </div>
                                      </div>
                                      <p className="text-[10px] text-slate-400">Harap sertakan ID Pesanan Anda <span className="font-mono font-semibold">{order.id.slice(0, 8)}</span> pada kolom catatan di aplikasi e-wallet Anda.</p>
                                    </div>
                                  )}

                                  {/* Upload Section */}
                                  <div className="space-y-3">
                                    <div className="space-y-1">
                                      <label className="text-xs font-bold text-slate-700 block">
                                        Unggah Foto / Screenshot Bukti Transfer Anda (Format JPG/PNG/WEBP, Maks. 5MB) *
                                      </label>
                                      <div className="flex flex-col sm:flex-row items-center gap-4">
                                        <div className="relative w-full sm:w-1/2">
                                          <input
                                            type="file"
                                            id={`file-upload-${order.id}`}
                                            accept="image/*"
                                            className="hidden"
                                            onChange={(e) => handleFileChange(order.id, e.target.files?.[0] || null)}
                                          />
                                          <label
                                            htmlFor={`file-upload-${order.id}`}
                                            className="h-28 border border-dashed border-slate-300 rounded-xl bg-slate-50 hover:bg-slate-100/50 hover:border-blue-400 transition-all flex flex-col items-center justify-center p-4 cursor-pointer text-center w-full"
                                          >
                                            <ImageIcon className="w-8 h-8 text-slate-400 mb-1" />
                                            <span className="text-xs font-bold text-slate-600">
                                              {selectedProofFilesMap[order.id] ? 'Ganti File Bukti' : 'Pilih File Bukti Pembayaran'}
                                            </span>
                                            <span className="text-[10px] text-slate-400 mt-0.5">Drag-and-drop atau klik untuk browse</span>
                                          </label>
                                        </div>

                                        {proofPreviewsMap[order.id] && (
                                          <div className="w-full sm:w-1/2 h-28 border border-slate-200 rounded-xl overflow-hidden relative flex items-center justify-center bg-slate-100">
                                            <img
                                              src={proofPreviewsMap[order.id]!}
                                              alt="Preview"
                                              className="max-h-24 object-contain"
                                            />
                                            <button
                                              type="button"
                                              onClick={() => {
                                                setSelectedProofFilesMap(prev => ({ ...prev, [order.id]: null }));
                                                setProofPreviewsMap(prev => ({ ...prev, [order.id]: null }));
                                              }}
                                              className="absolute top-1.5 right-1.5 bg-rose-500 text-white p-1 rounded-full shadow-sm hover:bg-rose-600 transition-colors"
                                              title="Hapus Bukti"
                                            >
                                              <X className="w-3.5 h-3.5" />
                                            </button>
                                          </div>
                                        )}
                                      </div>
                                    </div>

                                    {/* Customer Note */}
                                    <div className="space-y-1">
                                      <label className="text-xs font-bold text-slate-700 block">
                                        Catatan / Keterangan Pembayaran (Opsional):
                                      </label>
                                      <input
                                        type="text"
                                        value={customerNotesMap[order.id] || ''}
                                        onChange={(e) => setCustomerNotesMap(prev => ({ ...prev, [order.id]: e.target.value }))}
                                        placeholder="Contoh: Transfer via rekening Mandiri atas nama Budi"
                                        className="w-full bg-white border border-slate-200 focus:outline-none focus:border-blue-500 text-xs rounded-xl h-10 px-3.5 text-slate-700"
                                      />
                                    </div>

                                    <Button
                                      onClick={() => handleUploadAndSubmitPayment(order.id, order.totalAmount)}
                                      disabled={!selectedProofFilesMap[order.id] || uploadingProofMap[order.id]}
                                      className="w-full rounded-xl bg-blue-600 hover:bg-blue-700 font-bold h-11 text-xs"
                                    >
                                      {uploadingProofMap[order.id] ? (
                                        <>
                                          <RefreshCw className="w-4 h-4 mr-1.5 animate-spin shrink-0" />
                                          Mengunggah & Mengirim Bukti...
                                        </>
                                      ) : (
                                        'Konfirmasi & Kirim Bukti Pembayaran'
                                      )}
                                    </Button>
                                  </div>
                                </div>
                              )}
                            </div>

                            {/* Action Buttons (Copy ID, Cancel Order) */}
                            <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row gap-3 justify-between items-center text-xs">
                              <button
                                onClick={() => handleCopyCustomerOrderId(order.id)}
                                className="text-slate-400 hover:text-blue-500 flex items-center gap-1.5 font-semibold"
                              >
                                {copiedOrderId === order.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                                Salin ID Pesanan Lengkap
                              </button>

                              {(order.status === 'PENDING' || order.status === 'WAITING_PAYMENT') && (
                                <Button
                                  variant="outline"
                                  onClick={() => handleCancelCustomerOrder(order.id)}
                                  className="rounded-xl border-rose-200 text-rose-600 hover:bg-rose-50 hover:text-rose-700 font-bold px-4 py-2 h-9 text-xs flex items-center gap-1.5 w-full sm:w-auto justify-center"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  Batalkan Pesanan Ini
                                </Button>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* --- ADD / EDIT ADDRESS MODAL --- */}
      <Modal 
        isOpen={isAddressModalOpen} 
        onClose={() => setIsAddressModalOpen(false)} 
        title={selectedAddress ? 'Edit Shipping Address' : 'Add New Shipping Address'} 
        size="lg"
      >
        <form onSubmit={handleSaveAddress} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Address Label (Title) *</label>
              <Input
                name="title"
                className={`rounded-xl ${addressErrors.title ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="e.g. Rumah, Kantor"
                value={addressData.title}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.title && <p className="text-xs text-rose-500">{addressErrors.title}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Recipient Name (Nama Penerima) *</label>
              <Input
                name="recipientName"
                className={`rounded-xl ${addressErrors.recipientName ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="e.g. Jane Doe"
                value={addressData.recipientName}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.recipientName && <p className="text-xs text-rose-500">{addressErrors.recipientName}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Recipient No HP *</label>
              <Input
                name="phone"
                className={`rounded-xl ${addressErrors.phone ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="e.g. 0812345678"
                value={addressData.phone}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.phone && <p className="text-xs text-rose-500">{addressErrors.phone}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Province (Provinsi) *</label>
              <Input
                name="province"
                className={`rounded-xl ${addressErrors.province ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="e.g. Jawa Barat"
                value={addressData.province}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.province && <p className="text-xs text-rose-500">{addressErrors.province}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">City / Regency (Kota/Kabupaten) *</label>
              <Input
                name="city"
                className={`rounded-xl ${addressErrors.city ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="e.g. Bandung"
                value={addressData.city}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.city && <p className="text-xs text-rose-500">{addressErrors.city}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">District (Kecamatan) *</label>
              <Input
                name="district"
                className={`rounded-xl ${addressErrors.district ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="e.g. Coblong"
                value={addressData.district}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.district && <p className="text-xs text-rose-500">{addressErrors.district}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Postal Code (Kode Pos) *</label>
              <Input
                name="postalCode"
                className={`rounded-xl ${addressErrors.postalCode ? 'border-rose-500' : 'border-slate-200'}`}
                placeholder="e.g. 40135"
                value={addressData.postalCode}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.postalCode && <p className="text-xs text-rose-500">{addressErrors.postalCode}</p>}
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Full Street Address (Alamat Lengkap) *</label>
              <textarea
                name="address"
                className={`w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 min-h-20 focus:ring-1 focus:ring-blue-500 ${
                  addressErrors.address ? 'border-rose-500' : ''
                }`}
                placeholder="e.g. Jl. Dago Elok No 15"
                value={addressData.address}
                onChange={handleAddressChange}
                required
              />
              {addressErrors.address && <p className="text-xs text-rose-500">{addressErrors.address}</p>}
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Notes / Catatan (Optional)</label>
              <Input
                name="notes"
                className="rounded-xl border-slate-200"
                placeholder="e.g. Pagar hitam, samping warung kopi"
                value={addressData.notes}
                onChange={handleAddressChange}
              />
            </div>

            <div className="md:col-span-2 flex items-center gap-2 pt-2">
              <input
                id="isDefault"
                name="isDefault"
                type="checkbox"
                className="w-4 h-4 text-blue-600 border-slate-200 rounded-md focus:ring-blue-500 cursor-pointer"
                checked={addressData.isDefault}
                onChange={handleAddressChange}
                disabled={selectedAddress?.isDefault} // Cannot unset default directly if it's already default
              />
              <label htmlFor="isDefault" className="text-xs font-semibold text-slate-600 uppercase tracking-wider cursor-pointer select-none">
                Set as Default shipping address
              </label>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <Button type="button" variant="outline" onClick={() => setIsAddressModalOpen(false)} disabled={submittingAddress} className="rounded-xl">
              Cancel
            </Button>
            <Button type="submit" disabled={submittingAddress} className="rounded-xl min-w-28">
              {submittingAddress ? 'Saving Address...' : 'Save Address'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* --- CONFIRM DELETE ADDRESS DIALOG --- */}
      <ConfirmationDialog
        isOpen={isConfirmDeleteOpen}
        onClose={() => setIsConfirmDeleteOpen(false)}
        onConfirm={handleDeleteAddressConfirm}
        title="Delete Saved Shipping Address"
        description={`Are you sure you want to permanently delete address "${selectedAddress?.title}"? This cannot be undone.`}
        confirmText="Delete"
        cancelText="Cancel"
        isLoading={submittingAddress}
        type="danger"
      />
    </div>
  );
}
