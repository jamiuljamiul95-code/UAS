import { Outlet, Link, Navigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Users, 
  Settings, 
  LogOut,
  Menu,
  ClipboardList,
  Tags,
  CreditCard
} from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { Button } from '../ui/Button';

export default function DashboardLayout() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Check roles (only allow non-customer roles here for now)
  if (user?.role === 'CUSTOMER') {
    return <Navigate to="/" replace />;
  }

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'POS', path: '/dashboard/pos', icon: ShoppingCart },
    { name: 'Orders', path: '/dashboard/orders', icon: ClipboardList },
    { name: 'Payments', path: '/dashboard/payments', icon: CreditCard },
    { name: 'Products', path: '/dashboard/products', icon: Package },
    { name: 'Categories', path: '/dashboard/categories', icon: Tags },
    { name: 'Users', path: '/dashboard/users', icon: Users, role: ['OWNER', 'ADMIN'] },
    { name: 'Settings', path: '/dashboard/settings', icon: Settings, role: ['OWNER', 'ADMIN'] },
  ];

  return (
    <div className="min-h-screen bg-slate-100 flex font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col fixed inset-y-0 z-10 transition-transform transform -translate-x-full md:translate-x-0 md:relative">
        <div className="h-16 flex items-center px-6 bg-slate-950 text-white font-bold text-xl tracking-tight gap-2">
          <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center">L</div>
          <span>LuxeStore POS</span>
        </div>
        
        <div className="px-6 py-4 border-b border-slate-800">
          <div className="text-sm font-medium text-white">{user?.name}</div>
          <div className="text-xs text-slate-500 uppercase tracking-wider mt-1">{user?.role}</div>
        </div>

        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            if (item.role && !item.role.includes(user?.role || '')) return null;
            
            const isActive = location.pathname === item.path || location.pathname.startsWith(item.path + '/');
            const Icon = item.icon;
            
            return (
              <Link
                key={item.name}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                  isActive 
                    ? 'bg-blue-600 text-white' 
                    : 'hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.name}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <Button 
            variant="ghost" 
            className="w-full justify-start gap-3 text-slate-300 hover:text-white hover:bg-slate-800"
            onClick={logout}
          >
            <LogOut className="w-5 h-5" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" className="md:hidden">
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex-1" />
          <div className="flex items-center gap-4">
            <div className="text-sm font-medium text-slate-700 hidden sm:block">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-slate-50 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
