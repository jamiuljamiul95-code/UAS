import { useEffect, useState } from 'react';
import { Outlet, Link, NavLink } from 'react-router-dom';
import { ShoppingBag, LogIn, User, LogOut, ShoppingCart, Menu, X } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { useCartStore } from '../../store/useCartStore';
import { Button } from '../ui/Button';

export default function MainLayout() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const { items, fetchCart } = useCartStore();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const cartItemCount = items.reduce((total, item) => total + item.quantity, 0);

  useEffect(() => {
    fetchCart();
  }, [fetchCart, isAuthenticated]);

  const getNavLinkClass = ({ isActive }: { isActive: boolean }) =>
    `transition-colors duration-200 hover:text-blue-600 py-1 ${
      isActive ? 'text-blue-600 font-semibold border-b-2 border-blue-600' : 'text-slate-600'
    }`;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between max-w-7xl">
          <Link to="/" className="flex items-center gap-2 font-bold text-xl tracking-tight">
            <ShoppingBag className="w-6 h-6 text-blue-600" />
            <span>Luxe<span className="text-blue-600">Store</span></span>
          </Link>
          
          <nav className="hidden md:flex gap-6 items-center font-medium">
            <NavLink to="/" className={getNavLinkClass}>Home</NavLink>
            <NavLink to="/products" className={getNavLinkClass}>Shop</NavLink>
            <NavLink to="/categories" className={getNavLinkClass}>Categories</NavLink>
            <NavLink to="/about" className={getNavLinkClass}>About</NavLink>
            <NavLink to="/contact" className={getNavLinkClass}>Contact</NavLink>
          </nav>

          <div className="flex items-center gap-2 md:gap-4">
            <Link to="/cart" className="relative p-2 text-slate-600 hover:text-blue-600 transition-colors mr-1">
              <ShoppingCart className="w-5 h-5" />
              {cartItemCount > 0 && (
                <span className="absolute top-0 right-0 w-4 h-4 bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center rounded-full">
                  {cartItemCount}
                </span>
              )}
            </Link>

            <div className="hidden md:flex items-center gap-4">
              {isAuthenticated ? (
                <div className="flex items-center gap-4">
                  <Link to={['OWNER', 'ADMIN', 'STAFF', 'CASHIER'].includes(user?.role || '') ? '/dashboard' : '/profile'}>
                    <Button variant="ghost" size="sm" className="gap-2">
                      <User className="w-4 h-4" />
                      {user?.name}
                    </Button>
                  </Link>
                  <Button variant="outline" size="sm" onClick={logout} className="gap-2 text-red-600 hover:text-red-700">
                    <LogOut className="w-4 h-4" />
                    Logout
                  </Button>
                </div>
              ) : (
                <>
                  <Link to="/login">
                    <Button variant="ghost" size="sm" className="gap-2">
                      <LogIn className="w-4 h-4" />
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/register">
                    <Button size="sm">Sign Up</Button>
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 hover:text-blue-600 transition-colors focus:outline-none"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-4 animate-in fade-in duration-200">
            <nav className="flex flex-col gap-1">
              <NavLink 
                to="/" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Home
              </NavLink>
              <NavLink 
                to="/products" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Shop
              </NavLink>
              <NavLink 
                to="/categories" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Categories
              </NavLink>
              <NavLink 
                to="/about" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                About
              </NavLink>
              <NavLink 
                to="/contact" 
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) => `block py-2 text-base font-medium hover:text-blue-600 transition-colors rounded-md px-3 ${isActive ? 'text-blue-600 bg-slate-50 font-semibold' : 'text-slate-600'}`}
              >
                Contact
              </NavLink>
            </nav>
            
            <div className="pt-4 border-t border-slate-100 flex flex-col gap-2">
              {isAuthenticated ? (
                <div className="flex flex-col gap-3 px-3">
                  <div className="flex items-center gap-2 text-slate-700 font-medium">
                    <User className="w-5 h-5 text-slate-400" />
                    <span className="truncate">{user?.name}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full uppercase ml-auto font-semibold">{user?.role}</span>
                  </div>
                  <Link 
                    to={['OWNER', 'ADMIN', 'STAFF', 'CASHIER'].includes(user?.role || '') ? '/dashboard' : '/profile'}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="w-full"
                  >
                    <Button variant="outline" size="sm" className="w-full justify-center">
                      Dashboard / Profile
                    </Button>
                  </Link>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => {
                      logout();
                      setIsMobileMenuOpen(false);
                    }} 
                    className="w-full justify-center text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col gap-2 px-3">
                  <Link to="/login" onClick={() => setIsMobileMenuOpen(false)} className="w-full">
                    <Button variant="ghost" size="sm" className="w-full justify-center">
                      <LogIn className="w-4 h-4 mr-2" />
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/register" onClick={() => setIsMobileMenuOpen(false)} className="w-full">
                    <Button size="sm" className="w-full justify-center">
                      Sign Up
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      <main>
        <Outlet />
      </main>

      <footer className="bg-slate-900 text-slate-300 py-12 mt-20">
        <div className="container mx-auto px-4 max-w-7xl grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white font-bold text-xl mb-4 flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-blue-500" />
              LuxeStore
            </h3>
            <p className="text-sm">Premium clothing POS and E-Commerce platform for modern fashion businesses.</p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Shop</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/products" className="hover:text-white transition-colors">All Products</Link></li>
              <li><Link to="/categories" className="hover:text-white transition-colors">Categories</Link></li>
              <li><Link to="/sales" className="hover:text-white transition-colors">Sales & Offers</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link to="/faq" className="hover:text-white transition-colors">FAQ</Link></li>
              <li><Link to="/shipping" className="hover:text-white transition-colors">Shipping & Returns</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}
