/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './components/layout/MainLayout';
import DashboardLayout from './components/layout/DashboardLayout';
import HomePage from './features/home/HomePage';
import ShopProductsPage from './features/shop/ShopProductsPage';
import ProductDetailPage from './features/shop/ProductDetailPage';
import CartPage from './features/shop/CartPage';
import CategoriesPage from './features/shop/CategoriesPage';
import DashboardPage from './features/dashboard/DashboardPage';
import LoginPage from './features/auth/LoginPage';
import RegisterPage from './features/auth/RegisterPage';
import ProductsPage from './features/dashboard/products/ProductsPage';
import DashboardCategoriesPage from './features/dashboard/categories/CategoriesPage';
import PosPage from './features/dashboard/pos/PosPage';
import OrdersPage from './features/dashboard/orders/OrdersPage';
import UsersPage from './features/dashboard/users/UsersPage';
import PaymentsPage from './features/dashboard/payments/PaymentsPage';
import ProfilePage from './features/profile/ProfilePage';
import CheckoutPage from './features/shop/CheckoutPage';
import SuccessPage from './features/shop/SuccessPage';

import ToastContainer from './components/ui/ToastContainer';

function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-4xl min-h-[60vh] flex flex-col justify-center">
      <h1 className="text-4xl font-bold tracking-tight text-slate-900 mb-6 text-center">About LuxeStore</h1>
      <p className="text-lg text-slate-600 leading-relaxed mb-6 text-center">
        LuxeStore is a premier boutique destination offering curated high-end fashion, clothing, and lifestyle essentials for the contemporary individual.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 text-center">
        <div className="p-6 bg-white rounded-xl shadow-sm border border-slate-100">
          <h3 className="font-semibold text-slate-900 mb-2">Premium Quality</h3>
          <p className="text-sm text-slate-500">Carefully selected materials and meticulous craftsmanship define our collection.</p>
        </div>
        <div className="p-6 bg-white rounded-xl shadow-sm border border-slate-100">
          <h3 className="font-semibold text-slate-900 mb-2">Modern Minimalist</h3>
          <p className="text-sm text-slate-500">Timeless pieces that seamlessly blend simplicity with sophisticated luxury.</p>
        </div>
        <div className="p-6 bg-white rounded-xl shadow-sm border border-slate-100">
          <h3 className="font-semibold text-slate-900 mb-2">Sustainable Fashion</h3>
          <p className="text-sm text-slate-500">We partner with conscious manufacturers to deliver style with integrity.</p>
        </div>
      </div>
    </div>
  );
}

function ContactPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate contact form submission
    const form = e.currentTarget as HTMLFormElement;
    form.reset();
    alert('Thank you! Your message has been sent successfully.');
  };

  return (
    <div className="container mx-auto px-4 py-16 max-w-md min-h-[60vh] flex flex-col justify-center">
      <h1 className="text-4xl font-bold tracking-tight text-slate-900 mb-4 text-center">Contact Us</h1>
      <p className="text-slate-600 text-center mb-8">
        Have questions about our collection or an order? Get in touch with our support team.
      </p>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-8 rounded-xl shadow-sm border border-slate-100">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
          <input type="text" required className="w-full px-3 py-2 border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
          <input type="email" required className="w-full px-3 py-2 border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Message</label>
          <textarea rows={4} required className="w-full px-3 py-2 border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
        </div>
        <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-md transition-colors">
          Send Message
        </button>
      </form>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastContainer />
      <Routes>
        {/* Public / Customer Routes */}
        <Route path="/" element={<MainLayout />}>
          <Route index element={<HomePage />} />
          <Route path="products" element={<ShopProductsPage />} />
          <Route path="products/:slug" element={<ProductDetailPage />} />
          <Route path="cart" element={<CartPage />} />
          <Route path="checkout" element={<CheckoutPage />} />
          <Route path="checkout/success" element={<SuccessPage />} />
          <Route path="login" element={<LoginPage />} />
          <Route path="register" element={<RegisterPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="categories" element={<CategoriesPage />} />
          <Route path="about" element={<AboutPage />} />
          <Route path="contact" element={<ContactPage />} />
          {/* Add other public routes here */}
        </Route>

        {/* Dashboard / Admin / Staff / Owner Routes */}
        <Route path="/dashboard" element={<DashboardLayout />}>
          <Route index element={<DashboardPage />} />
          <Route path="pos" element={<PosPage />} />
          <Route path="products" element={<ProductsPage />} />
          <Route path="categories" element={<DashboardCategoriesPage />} />
          <Route path="orders" element={<OrdersPage />} />
          <Route path="payments" element={<PaymentsPage />} />
          <Route path="users" element={<UsersPage />} />
          {/* Add other dashboard routes here */}
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
