import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import api from '../lib/axios';
import { useAuthStore } from './useAuthStore';
import { useToastStore } from './useToastStore';

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  slug: string;
  categoryName: string;
  imageUrl: string;
  variantId: string | null;
  variantName: string | null;
  sku: string;
  originalPrice: number;
  discountPrice: number | null;
  price: number; // Final price
  quantity: number;
  subtotal: number;
  originalSubtotal: number;
  savings: number;
  selected: boolean;
  availableStock: number;
  hasEnoughStock: boolean;
  isActive: boolean;
}

export interface CartSummary {
  totalItemsCount: number;
  totalUniqueItems: number;
  selectedItemsCount: number;
  selectedUniqueItems: number;
  originalSubtotal: number;
  subtotal: number;
  totalDiscount: number;
  totalPayment: number;
}

interface CartState {
  items: CartItem[];
  summary: CartSummary;
  isLoading: boolean;
  error: string | null;
  
  fetchCart: () => Promise<void>;
  addItem: (productId: string, quantity: number, variantId?: string | null, productInfoForLocal?: any) => Promise<void>;
  removeItem: (id: string) => Promise<void>;
  updateQuantity: (id: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  toggleSelect: (id: string, selected: boolean) => Promise<void>;
  toggleSelectAll: (selected: boolean) => Promise<void>;
  syncLocalCart: () => Promise<void>;
}

const initialSummary: CartSummary = {
  totalItemsCount: 0,
  totalUniqueItems: 0,
  selectedItemsCount: 0,
  selectedUniqueItems: 0,
  originalSubtotal: 0,
  subtotal: 0,
  totalDiscount: 0,
  totalPayment: 0,
};

// Local storage calculations helper for unauthenticated sessions
const calculateLocalSummary = (items: CartItem[]): CartSummary => {
  let totalItemsCount = 0;
  let selectedItemsCount = 0;
  let selectedUniqueItems = 0;
  let originalSubtotal = 0;
  let subtotal = 0;

  items.forEach((item) => {
    totalItemsCount += item.quantity;
    if (item.selected) {
      selectedItemsCount += item.quantity;
      selectedUniqueItems += 1;
      originalSubtotal += item.originalPrice * item.quantity;
      subtotal += item.price * item.quantity;
    }
  });

  return {
    totalItemsCount,
    totalUniqueItems: items.length,
    selectedItemsCount,
    selectedUniqueItems,
    originalSubtotal,
    subtotal,
    totalDiscount: originalSubtotal - subtotal,
    totalPayment: subtotal,
  };
};

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      summary: initialSummary,
      isLoading: false,
      error: null,

      fetchCart: async () => {
        const { isAuthenticated } = useAuthStore.getState();
        if (!isAuthenticated) {
          // Unauthenticated: Keep current local items, recalculate summary
          const localItems = get().items;
          set({ summary: calculateLocalSummary(localItems) });
          return;
        }

        set({ isLoading: true, error: null });
        try {
          const response = await api.get('/cart');
          if (response.data.success) {
            set({
              items: response.data.data.items,
              summary: response.data.data.summary,
              isLoading: false,
            });
          }
        } catch (error: any) {
          console.error('Fetch cart failed:', error);
          set({
            error: error.response?.data?.message || 'Failed to retrieve cart items',
            isLoading: false,
          });
        }
      },

      addItem: async (productId, quantity, variantId = null, productInfoForLocal = null) => {
        const { isAuthenticated } = useAuthStore.getState();
        const toast = useToastStore.getState();

        if (isAuthenticated) {
          set({ isLoading: true, error: null });
          try {
            const response = await api.post('/cart', { productId, variantId, quantity });
            if (response.data.success) {
              set({
                items: response.data.data.items,
                summary: response.data.data.summary,
                isLoading: false,
              });
              toast.addToast('Item successfully added to cart', 'success');
            }
          } catch (error: any) {
            const errorMsg = error.response?.data?.message || 'Failed to add item to cart';
            toast.addToast(errorMsg, 'error');
            set({ error: errorMsg, isLoading: false });
            throw error;
          }
        } else {
          // Local fallback
          if (!productInfoForLocal) {
            toast.addToast('Failed to add item to cart locally: missing details', 'error');
            return;
          }

          const localItems = [...get().items];
          const existingIndex = localItems.findIndex(
            (i) => i.productId === productId && i.variantId === variantId
          );

          const availableStock = variantId
            ? (productInfoForLocal.variants?.find((v: any) => v.id === variantId)?.stock ?? 0)
            : (productInfoForLocal.stock ?? 0);

          if (existingIndex > -1) {
            const existingItem = localItems[existingIndex];
            const targetQty = existingItem.quantity + quantity;
            if (targetQty > availableStock) {
              toast.addToast(`Cannot add. Exceeds available stock limit of ${availableStock}.`, 'error');
              return;
            }
            existingItem.quantity = targetQty;
            existingItem.subtotal = existingItem.price * targetQty;
            existingItem.originalSubtotal = existingItem.originalPrice * targetQty;
            existingItem.savings = existingItem.originalSubtotal - existingItem.subtotal;
          } else {
            if (quantity > availableStock) {
              toast.addToast(`Cannot add. Exceeds available stock limit of ${availableStock}.`, 'error');
              return;
            }

            const originalPrice = productInfoForLocal.price;
            const discountPrice = productInfoForLocal.discountPrice;
            const price = discountPrice !== null && discountPrice < originalPrice ? discountPrice : originalPrice;

            // Generate a display name for the variant
            let variantName: string | null = null;
            let sku = productInfoForLocal.sku;
            if (variantId && productInfoForLocal.variants) {
              const variant = productInfoForLocal.variants.find((v: any) => v.id === variantId);
              if (variant) {
                const parts = [];
                if (variant.color) parts.push(`Color: ${variant.color}`);
                if (variant.size) parts.push(`Size: ${variant.size}`);
                variantName = parts.length > 0 ? parts.join(', ') : 'Default Variant';
                if (variant.sku) sku = variant.sku;
              }
            }

            const mainImage = productInfoForLocal.images?.find((img: any) => img.isMain) || productInfoForLocal.images?.[0];
            const imageUrl = mainImage ? mainImage.url : '/assets/placeholder-product.png';

            const newItem: CartItem = {
              id: `${productId}-${variantId || 'na'}`,
              productId,
              name: productInfoForLocal.name,
              slug: productInfoForLocal.slug,
              categoryName: productInfoForLocal.category?.name || 'Uncategorized',
              imageUrl,
              variantId,
              variantName,
              sku,
              originalPrice,
              discountPrice,
              price,
              quantity,
              subtotal: price * quantity,
              originalSubtotal: originalPrice * quantity,
              savings: (originalPrice - price) * quantity,
              selected: true,
              availableStock,
              hasEnoughStock: true,
              isActive: productInfoForLocal.status === 'ACTIVE',
            };

            localItems.push(newItem);
          }

          set({
            items: localItems,
            summary: calculateLocalSummary(localItems),
          });
          toast.addToast('Item successfully added to local cart', 'success');
        }
      },

      removeItem: async (id) => {
        const { isAuthenticated } = useAuthStore.getState();
        const toast = useToastStore.getState();

        if (isAuthenticated) {
          set({ isLoading: true, error: null });
          try {
            const response = await api.delete(`/cart/${id}`);
            if (response.data.success) {
              set({
                items: response.data.data.items,
                summary: response.data.data.summary,
                isLoading: false,
              });
              toast.addToast('Item successfully removed from cart', 'success');
            }
          } catch (error: any) {
            const errorMsg = error.response?.data?.message || 'Failed to remove item';
            toast.addToast(errorMsg, 'error');
            set({ error: errorMsg, isLoading: false });
          }
        } else {
          const localItems = get().items.filter((i) => i.id !== id);
          set({
            items: localItems,
            summary: calculateLocalSummary(localItems),
          });
          toast.addToast('Item removed from local cart', 'success');
        }
      },

      updateQuantity: async (id, quantity) => {
        const { isAuthenticated } = useAuthStore.getState();
        const toast = useToastStore.getState();

        if (quantity < 1) return;

        if (isAuthenticated) {
          set({ isLoading: true, error: null });
          try {
            const response = await api.put(`/cart/${id}`, { quantity });
            if (response.data.success) {
              set({
                items: response.data.data.items,
                summary: response.data.data.summary,
                isLoading: false,
              });
            }
          } catch (error: any) {
            const errorMsg = error.response?.data?.message || 'Failed to update quantity';
            toast.addToast(errorMsg, 'error');
            set({ error: errorMsg, isLoading: false });
          }
        } else {
          const localItems = get().items.map((item) => {
            if (item.id === id) {
              if (quantity > item.availableStock) {
                toast.addToast(`Only ${item.availableStock} items are available in stock`, 'error');
                return item;
              }
              const updatedItem = { ...item, quantity };
              updatedItem.subtotal = updatedItem.price * quantity;
              updatedItem.originalSubtotal = updatedItem.originalPrice * quantity;
              updatedItem.savings = updatedItem.originalSubtotal - updatedItem.subtotal;
              return updatedItem;
            }
            return item;
          });

          set({
            items: localItems,
            summary: calculateLocalSummary(localItems),
          });
        }
      },

      clearCart: async () => {
        const { isAuthenticated } = useAuthStore.getState();
        const toast = useToastStore.getState();

        if (isAuthenticated) {
          set({ isLoading: true, error: null });
          try {
            const response = await api.delete('/cart');
            if (response.data.success) {
              set({
                items: response.data.data.items,
                summary: response.data.data.summary,
                isLoading: false,
              });
              toast.addToast('Shopping cart successfully cleared', 'success');
            }
          } catch (error: any) {
            const errorMsg = error.response?.data?.message || 'Failed to clear shopping cart';
            toast.addToast(errorMsg, 'error');
            set({ error: errorMsg, isLoading: false });
          }
        } else {
          set({
            items: [],
            summary: initialSummary,
          });
          toast.addToast('Local shopping cart cleared', 'success');
        }
      },

      toggleSelect: async (id, selected) => {
        const { isAuthenticated } = useAuthStore.getState();
        const toast = useToastStore.getState();

        if (isAuthenticated) {
          try {
            const response = await api.patch('/cart/select', { id, selected });
            if (response.data.success) {
              set({
                items: response.data.data.items,
                summary: response.data.data.summary,
              });
            }
          } catch (error: any) {
            const errorMsg = error.response?.data?.message || 'Failed to update item selection';
            toast.addToast(errorMsg, 'error');
          }
        } else {
          const localItems = get().items.map((item) =>
            item.id === id ? { ...item, selected } : item
          );
          set({
            items: localItems,
            summary: calculateLocalSummary(localItems),
          });
        }
      },

      toggleSelectAll: async (selected) => {
        const { isAuthenticated } = useAuthStore.getState();
        const toast = useToastStore.getState();

        if (isAuthenticated) {
          try {
            const response = await api.patch('/cart/select', { all: true, selected });
            if (response.data.success) {
              set({
                items: response.data.data.items,
                summary: response.data.data.summary,
              });
            }
          } catch (error: any) {
            const errorMsg = error.response?.data?.message || 'Failed to update selection';
            toast.addToast(errorMsg, 'error');
          }
        } else {
          const localItems = get().items.map((item) => ({ ...item, selected }));
          set({
            items: localItems,
            summary: calculateLocalSummary(localItems),
          });
        }
      },

      syncLocalCart: async () => {
        const { isAuthenticated } = useAuthStore.getState();
        const localItems = get().items;

        if (!isAuthenticated || localItems.length === 0) return;

        console.log('Synchronizing local cart with backend server...');
        try {
          // Sequential migration of local cart items to the server
          for (const item of localItems) {
            try {
              await api.post('/cart', {
                productId: item.productId,
                variantId: item.variantId,
                quantity: item.quantity,
              });
            } catch (err) {
              console.error(`Failed to sync item ${item.name}:`, err);
            }
          }

          // Fetch fresh integrated cart from the server
          const response = await api.get('/cart');
          if (response.data.success) {
            set({
              items: response.data.data.items,
              summary: response.data.data.summary,
            });
          }
        } catch (error) {
          console.error('Unified cart synchronization failure:', error);
        }
      },
    }),
    {
      name: 'cart-storage',
      // Only persist local items, do not persist loading or server-specific errors
      partialize: (state) => ({ items: state.items, summary: state.summary }),
    }
  )
);
